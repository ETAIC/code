# Copyright (c) 2024, Hao Zhang, Yikai Wang, Ding Zhao, Hongtei Eric Tseng.
# All rights reserved.
#

"""Pre-defined terrain configurations for the terrain generator."""

from .rough import *  # noqa: F401
