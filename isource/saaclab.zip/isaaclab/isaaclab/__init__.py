# Copyright (c) 2024, Hao Zhang, Yikai Wang, Ding Zhao, Hongtei Eric Tseng.
# All rights reserved.
#

"""Package containing the core framework."""

import os
import toml

# Conveniences to other module directories via relative paths
ISAACLAB_EXT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
"""Path to the extension source directory."""

ISAACLAB_METADATA = toml.load(os.path.join(ISAACLAB_EXT_DIR, "config", "extension.toml"))
"""Extension metadata dictionary parsed from the extension.toml file."""

# Configure the module-level variables
__version__ = ISAACLAB_METADATA["package"]["version"]
