# Copyright (c) 2024, Hao Zhang, Yikai Wang, Ding Zhao, Hongtei Eric Tseng.
# All rights reserved.
#

"""
Submodule for different interpolation methods.
"""

from .linear_interpolation import LinearInterpolation
