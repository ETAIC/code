# Copyright (c) 2024, Hao Zhang, Yikai Wang, Ding Zhao, Hongtei Eric Tseng.
# All rights reserved.
#

from isaaclab.utils import configclass

from .camera_cfg import CameraCfg
from .tiled_camera import TiledCamera


@configclass
class TiledCameraCfg(CameraCfg):
    """Configuration for a tiled rendering-based camera sensor."""

    class_type: type = TiledCamera
