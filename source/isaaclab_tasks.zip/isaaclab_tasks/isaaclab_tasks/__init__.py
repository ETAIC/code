import os
import toml

ISAACLAB_TASKS_EXT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
ISAACLAB_TASKS_METADATA = toml.load(os.path.join(ISAACLAB_TASKS_EXT_DIR, "config", "extension.toml"))
__version__ = ISAACLAB_TASKS_METADATA["package"]["version"]

from .utils import import_packages

_BLACKLIST_PKGS = ["utils", ".mdp", "pick_place"]
import_packages(__name__, _BLACKLIST_PKGS)
