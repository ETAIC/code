# Copyright (c) 2024, Hao Zhang, Yikai Wang, Ding Zhao, Hongtei Eric Tseng.
from __future__ import annotations

import copy
import torch
import numpy as np
import sys
import math
import os

current_file_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_file_dir
for _ in range(5):
    wbc_integration_path = os.path.join(project_root, 'wbc_integration')
    if os.path.exists(wbc_integration_path) and os.path.exists(os.path.join(wbc_integration_path, 'whole_body_controller.py')):
        if wbc_integration_path not in sys.path:
            sys.path.insert(0, wbc_integration_path)
        break
    parent = os.path.dirname(project_root)
    if parent == project_root:
        break
    project_root = parent
else:
    possible_paths = [
        '/home/marl/ICML/IsaacLab-HALPO-Lyapunov/wbc_integration',
        os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(current_file_dir))))), 'wbc_integration'),
    ]
    for path in possible_paths:
        if os.path.exists(path) and os.path.exists(os.path.join(path, 'whole_body_controller.py')):
            if path not in sys.path:
                sys.path.insert(0, path)
            break

try:
    from whole_body_controller import WholeBodyController
except ImportError:
    WholeBodyController = None

import isaacsim.core.utils.torch as torch_utils
from isaacsim.core.utils.torch.rotations import compute_heading_and_up, compute_rot, quat_conjugate

import isaaclab.envs.mdp as mdp
import isaaclab.sim as sim_utils
from isaaclab.assets import Articulation, ArticulationCfg, RigidObject, RigidObjectCfg
from isaaclab.envs import DirectMARLEnv, DirectMARLEnvCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.markers import VisualizationMarkers, VisualizationMarkersCfg
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.sensors import ContactSensor, ContactSensorCfg, RayCasterCfg, patterns
from isaaclab.sim import SimulationCfg
from isaaclab.terrains import TerrainImporterCfg
from isaaclab.utils import configclass
from isaaclab.utils.assets import ISAAC_NUCLEUS_DIR
from isaaclab.utils.math import quat_from_angle_axis
import collections
from collections import deque
from copy import deepcopy
from typing import Optional, Dict, Any

from isaaclab_assets.robots.anymal import ANYMAL_C_CFG
from isaaclab_assets.robots.g1_29dof import G1_29DOF_CFG
from isaaclab.terrains.config.rough import ROUGH_TERRAINS_CFG

from isaaclab_tasks.utils.custom_trajectory import get_short_term_goal
from .lead_follow_controller import LeadFollowController



def normalize_angle(x):
    return torch.atan2(torch.sin(x), torch.cos(x))

def quat_to_euler_angles_torch(q: torch.Tensor) -> torch.Tensor:
    
    w, x, y, z = q[..., 0], q[..., 1], q[..., 2], q[..., 3]
    t0 = +2.0 * (w * x + y * z)
    t1 = +1.0 - 2.0 * (x * x + y * y)
    roll = torch.atan2(t0, t1)
    t2 = +2.0 * (w * y - z * x)
    t2 = torch.clamp(t2, -1.0, 1.0)
    pitch = torch.asin(t2)
    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (y * y + z * z)
    yaw = torch.atan2(t3, t4)
    return torch.stack((roll, pitch, yaw), dim=-1)


def randomize_rigid_body_material_0(env, env_ids, asset_cfg, static_friction_range, dynamic_friction_range, restitution_range, num_buckets):
    pass

def randomize_rigid_body_material_1(env, env_ids, asset_cfg, static_friction_range, dynamic_friction_range, restitution_range, num_buckets):
    pass


@configclass
class EventCfg:
    pass


@configclass
class HalpoCoordinationEnvCfg(DirectMARLEnvCfg):
    episode_length_s = 15.0
    decimation = 4
    action_space = 11
    action_spaces = {"robot_0": 11, "robot_1": 11}
    observation_spaces = {"robot_0": 192, "robot_1": 192}
    state_space = 192
    state_spaces = {f"robot_{i}": 192 for i in range(2)}
    possible_agents = ["robot_0", "robot_1"]
    sim: SimulationCfg = SimulationCfg(
        dt=1 / 200,
        render_interval=4,
        physics_material=sim_utils.RigidBodyMaterialCfg(
            friction_combine_mode="multiply",
            restitution_combine_mode="multiply",
            static_friction=1.0,
            dynamic_friction=1.0,
            restitution=0.0,
        ),
    )
    terrain = TerrainImporterCfg(
        prim_path="/World/ground",
        terrain_type="plane",
        collision_group=-1,
        physics_material=sim_utils.RigidBodyMaterialCfg(
            friction_combine_mode="multiply",
            restitution_combine_mode="multiply",
            static_friction=1.0,
            dynamic_friction=1.0,
            restitution=0.0,
        ),
        debug_vis=False,
    )
    scene: InteractiveSceneCfg = InteractiveSceneCfg(num_envs=32, env_spacing=6.0, replicate_physics=True)
    events: Optional[EventCfg] = None
    robot_0: ArticulationCfg = deepcopy(G1_29DOF_CFG)
    robot_0.prim_path = "/World/envs/env_.*/Robot_0"
    contact_sensor_0: ContactSensorCfg = ContactSensorCfg(
        prim_path="/World/envs/env_.*/Robot_0/.*", history_length=3, update_period=0.005, track_air_time=True
    )
    robot_0.init_state.rot = (1, 0.0, 0.0, 0.0)
    robot_0.init_state.pos = (0.0, 0.5, 0.795)
    robot_1: ArticulationCfg = deepcopy(G1_29DOF_CFG)
    robot_1.prim_path = "/World/envs/env_.*/Robot_1"
    robot_1.init_state.rot = (1, 0.0, 0.0, 0.0)
    robot_1.init_state.pos = (0.0, -0.5, 0.795)
    circle_radius = 5.0
    robot_pos = (0.0, 1.0, 1.0)
    circle_center = (robot_pos[0], robot_pos[1] + 3.0, robot_pos[2])
    box_init_pos = (circle_center[0], circle_center[1] + circle_radius, 0.6)
    cfg_rec_prism = RigidObjectCfg(
        prim_path="/World/envs/env_.*/Object",
        spawn=sim_utils.CuboidCfg(
            size=(0.22, 2.0, 0.05),
            rigid_props=sim_utils.RigidBodyPropertiesCfg(),
            mass_props=sim_utils.MassPropertiesCfg(mass=2.0),
            collision_props=sim_utils.CollisionPropertiesCfg(),
        physics_material=sim_utils.RigidBodyMaterialCfg(
            friction_combine_mode="multiply",
            restitution_combine_mode="multiply",
            static_friction=1.5,
            dynamic_friction=1.2,
            restitution=0.0,
        ),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.6, 0.4, 0.2)),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(pos=(0.15, -0.03, 0.92), rot=(1.0, 0.0, 0.0, 0.0)),
    )
    flat_orientation_reward_scale = 0.0
    formation_consistency_reward_scale = 2.0
    height_maintenance_reward_scale = 1.0
    goal_reaching_reward_scale = 0.0
    curriculum_enabled = False
    curriculum_start_scale = 0.5
    curriculum_end_scale = 1.0
    curriculum_start_steps = 10000000/24
    curriculum_end_steps = 20000000/24
    termination_height = 0.15
    angular_velocity_scale: float = 0.25
    dof_vel_scale: float = 0.1
    g1_action_scale = 1.0
    anymal_min_z_pos = 0.3
    g1_min_z_pos = 0.6
    joint_gears: list = [
        50.0
        for _ in range(29)
    ]
    wrist_roll_enable = True
    wrist_roll_left_target = -1.57079632679
    wrist_roll_right_target = 1.57079632679
    shoulder_yaw_enable = True
    shoulder_yaw_left_target = 0.25
    shoulder_yaw_right_target = -0.25
    shoulder_roll_enable = True
    shoulder_roll_left_target = 0.2
    shoulder_roll_right_target = -0.2


class HalpoCoordination(DirectMARLEnv):
    def __init__(self, cfg: HalpoCoordinationEnvCfg, render_mode: str | None = None, **kwargs):
        super().__init__(cfg, render_mode, **kwargs)
        
        self._device = self.device

        if WholeBodyController is not None:
            self.wbc_controller_0 = WholeBodyController(device=self.device)
            self.wbc_controller_1 = WholeBodyController(device=self.device)
        else:
            self.wbc_controller_0 = None
            self.wbc_controller_1 = None

        self.manual_high_level_cmd_mode = False
        
        
        self.enable_pi_controller = False
        self.use_pi_only = False
        
        self.lead_follow_controller = LeadFollowController(self.num_envs, self.device)
        


        self.halpo_action_interval = 40

        self.clip_ranges = torch.tensor([
            (3, 3), (3, 3), (3, 3), (3, 3), (3, 3),
            (3, 3), (3, 3), (3, 3), (3, 3)
        ], device=self._device, dtype=torch.float32)

        self.high_level_cmd = {}
        for env_idx in range(self.num_envs):
            self.high_level_cmd[(env_idx, "robot_0")] = np.zeros(11, dtype=np.float64)
            self.high_level_cmd[(env_idx, "robot_1")] = np.zeros(11, dtype=np.float64)
            
        
        from collections import deque
        self.wbc_n_proprio = 93
        self.extra_history_len = 25
        self.history_len = 10

        self.proprio_history_buf = {}
        self.extra_history_buf = {}
        for env_idx in range(self.num_envs):
            for robot_id in ["robot_0", "robot_1"]:
                self.proprio_history_buf[(env_idx, robot_id)] = deque([np.zeros(self.wbc_n_proprio) for _ in range(self.history_len)], maxlen=self.history_len)
                self.extra_history_buf[(env_idx, robot_id)] = deque([np.zeros(self.wbc_n_proprio) for _ in range(self.extra_history_len)], maxlen=self.extra_history_len)
        
        self.last_action = {}
        for env_idx in range(self.num_envs):
            for robot_id in ["robot_0", "robot_1"]:
                self.last_action[(env_idx, robot_id)] = np.zeros(23, dtype=np.float32)
        
        self.gait_cycle = {}
        for env_idx in range(self.num_envs):
            for robot_id in ["robot_0", "robot_1"]:
                self.gait_cycle[(env_idx, robot_id)] = np.array([0.25, 0.25])
        
        self.in_place_stand_flag = {}
        for env_idx in range(self.num_envs):
            for robot_id in ["robot_0", "robot_1"]:
                self.in_place_stand_flag[(env_idx, robot_id)] = True
        
        self.last_action_buffer = {}
        for env_idx in range(self.num_envs):
            for robot_id in ["robot_0", "robot_1"]:
                self.last_action_buffer[(env_idx, robot_id)] = np.zeros(23, dtype=np.float32)

        self.MUJOCO_PHYS_NAMES = ["left_hip_pitch_joint", "left_hip_roll_joint", "left_hip_yaw_joint", "left_knee_joint", "left_ankle_pitch_joint", "left_ankle_roll_joint", "right_hip_pitch_joint", "right_hip_roll_joint", "right_hip_yaw_joint", "right_knee_joint", "right_ankle_pitch_joint", "right_ankle_roll_joint", "waist_yaw_joint", "waist_roll_joint", "waist_pitch_joint", "left_shoulder_pitch_joint", "left_shoulder_roll_joint", "left_shoulder_yaw_joint", "left_elbow_joint", "right_shoulder_pitch_joint", "right_shoulder_roll_joint", "right_shoulder_yaw_joint", "right_elbow_joint"]
        self.PHYS_23_NAMES = ["left_hip_pitch_joint", "right_hip_pitch_joint", "waist_yaw_joint", "left_hip_roll_joint", "right_hip_roll_joint", "waist_roll_joint", "left_hip_yaw_joint", "right_hip_yaw_joint", "waist_pitch_joint", "left_knee_joint", "right_knee_joint", "left_shoulder_pitch_joint", "right_shoulder_pitch_joint", "left_ankle_pitch_joint", "right_ankle_pitch_joint", "left_shoulder_roll_joint", "right_shoulder_roll_joint", "left_ankle_roll_joint", "right_ankle_roll_joint", "left_shoulder_yaw_joint", "right_shoulder_yaw_joint", "left_elbow_joint", "right_elbow_joint"]
        self.WBC_23_NAMES = self.MUJOCO_PHYS_NAMES
        
        self.isaac_to_mujoco_idx = [self.PHYS_23_NAMES.index(name) for name in self.MUJOCO_PHYS_NAMES]
        mujoco_to_isaac_map = {name: i for i, name in enumerate(self.MUJOCO_PHYS_NAMES)}
        self.mujoco_to_isaac_idx = [mujoco_to_isaac_map.get(name) for name in self.PHYS_23_NAMES]

        self.old_last_action = {}
        self.old_proprio_history_buf = {}
        self.old_extra_history_buf = {}
        self.old_gait_cycle = {}
        self.old_high_level_cmd = {}
        self.old_in_place_stand_flag = {}
        for env_idx in range(self.num_envs):
            for robot_id in ["robot_0", "robot_1"]:
                self.old_last_action[(env_idx, robot_id)] = np.zeros(23, dtype=np.float32)
                self.old_proprio_history_buf[(env_idx, robot_id)] = deque([np.zeros(self.wbc_n_proprio) for _ in range(self.history_len)], maxlen=self.history_len)
                self.old_extra_history_buf[(env_idx, robot_id)] = deque([np.zeros(self.wbc_n_proprio) for _ in range(self.extra_history_len)], maxlen=self.extra_history_len)
                self.old_gait_cycle[(env_idx, robot_id)] = np.array([0.25, 0.25])
                self.old_high_level_cmd[(env_idx, robot_id)] = self.high_level_cmd[(env_idx, robot_id)].copy()
                self.old_in_place_stand_flag[(env_idx, robot_id)] = True

        self._setup_wbc_system()
        self._astar_path = None
        self._observation_history = {robot_id: deque([torch.zeros(52, device=self.device) for _ in range(3)], maxlen=3) for robot_id in ["robot_0", "robot_1"]}

    def calculate_lyapunov_value(self, state, action):
        
        alpha = getattr(self, "scpo_alpha", 1.0)
        beta = getattr(self, "scpo_beta", 1.0)
        gamma = getattr(self, "scpo_gamma", 1e-3)
        k_phi = getattr(self, "scpo_k_phi", 0.1)

        box_pos = self.object.data.root_com_pos_w
        stick_center = box_pos[:, :3]
        if hasattr(self, "_fixed_long_goals"):
            goal_center = self._fixed_long_goals[:, :3]
        else:
            goal_center = stick_center.detach().clone()

        box_quat = self.object.data.root_com_quat_w
        stick_length = 2.0
        local_v1 = torch.tensor([stick_length/2, 0.0, 0.0], device=self.device, dtype=torch.float32)
        local_v2 = torch.tensor([-stick_length/2, 0.0, 0.0], device=self.device, dtype=torch.float32)
        w, x, y, z = box_quat[:, 0], box_quat[:, 1], box_quat[:, 2], box_quat[:, 3]
        rot = torch.stack([
            torch.stack([1 - 2*y*y - 2*z*z, 2*x*y - 2*w*z, 2*x*z + 2*w*y], dim=1),
            torch.stack([2*x*y + 2*w*z, 1 - 2*x*x - 2*z*z, 2*y*z - 2*w*x], dim=1),
            torch.stack([2*x*z - 2*w*y, 2*y*z + 2*w*x, 1 - 2*x*x - 2*y*y], dim=1)
        ], dim=1)
        world_v1 = torch.bmm(rot, local_v1.unsqueeze(1).expand(self.num_envs, 3, 1)).squeeze(-1) + box_pos
        world_v2 = torch.bmm(rot, local_v2.unsqueeze(1).expand(self.num_envs, 3, 1)).squeeze(-1) + box_pos
        stick_dir = world_v1[:, :2] - world_v2[:, :2]
        stick_phi = torch.atan2(stick_dir[:, 1], stick_dir[:, 0])
        if hasattr(self, "_target_angles"):
            goal_phi = self._target_angles
        else:
            goal_phi = stick_phi.detach().clone()
        dphi = torch.remainder(stick_phi - goal_phi + torch.pi, 2 * torch.pi) - torch.pi

        pos_err_sq = torch.sum((stick_center[:, :2] - goal_center[:, :2]) ** 2, dim=1)
        phi_err_sq = (dphi ** 2)
        V_task = pos_err_sq + k_phi * phi_err_sq

        def get_z(robot_key: str) -> torch.Tensor:
            try:
                body_indices, _ = self.robots[robot_key].find_bodies("right_rubber_hand")
                if len(body_indices) > 0:
                    z_vals = self.robots[robot_key].data.body_com_pos_w[:, body_indices[0], 2]
                    return z_vals
            except Exception:
                pass
            return self.robots[robot_key].data.root_state_w[:, 2]

        z0 = get_z("robot_0")
        z1 = get_z("robot_1")
        V_coop = (z0 - z1) ** 2

        V_eff = torch.zeros(self.num_envs, device=self.device)
        if isinstance(action, dict):
            for key in ["robot_0", "robot_1"]:
                if key in action:
                    a = action[key]
                    if isinstance(a, np.ndarray):
                        a = torch.from_numpy(a).to(self.device, dtype=torch.float32)
                    if a.dim() == 1:
                        a = a.unsqueeze(0).expand(self.num_envs, -1)
                    V_eff = V_eff + torch.sum(a * a, dim=1)
        else:
            a = action
            if isinstance(a, np.ndarray):
                a = torch.from_numpy(a).to(self.device, dtype=torch.float32)
            if a.dim() == 1:
                a = a.unsqueeze(0).expand(self.num_envs, -1)
            V_eff = V_eff + torch.sum(a * a, dim=1)

        V = alpha * V_task + beta * V_coop + gamma * V_eff
        return V


    def compute_pi_control(self, env_idx, robot_id):
        robot_pos = self.robots[robot_id].data.root_pos_w[env_idx, :2]
        robot_yaw = self.robots[robot_id].data.root_quat_w[env_idx]
        robot_yaw = self.lead_follow_controller.quat_to_yaw(robot_yaw)

        target_center = self._fixed_long_goals[env_idx, :2]
        target_angle = self._target_angles[env_idx]

        robot0_pos = None
        robot0_yaw = None
        robot0_yaw_rate = None
        robot0_vel = None
        if robot_id == "robot_1":
            robot0_pos = self.robots["robot_0"].data.root_pos_w[env_idx, :2]
            robot0_quat = self.robots["robot_0"].data.root_quat_w[env_idx]
            robot0_yaw = self.lead_follow_controller.quat_to_yaw(robot0_quat)
            robot0_ang_vel = self.robots["robot_0"].data.root_com_ang_vel_w[env_idx]
            robot0_yaw_rate = robot0_ang_vel[2].item()
            robot0_vel = self.robots["robot_0"].data.root_com_lin_vel_w[env_idx, :2]

        dt = self.cfg.sim.dt * self.cfg.decimation
        control_output = self.lead_follow_controller.compute_control(
            env_idx, robot_id, robot_pos, robot_yaw, target_center, target_angle,
            robot0_pos, robot0_yaw, robot0_yaw_rate, robot0_vel, dt
        )



        return control_output

    def _compute_formation_control(self, env_idx, robot_id, p0, p1, yaw0, yaw1, world_vertex1, world_vertex2):
        return torch.zeros(3, device=self.device)
    
    def _compute_goal_control(self, env_idx, robot_id, p0, p1, world_vertex1, world_vertex2):
        return torch.zeros(3, device=self.device)

    def _setup_wbc_system(self):
        self.old_MUJOCO_PHYS_NAMES = [
            "left_hip_pitch_joint", "left_hip_roll_joint", "left_hip_yaw_joint", "left_knee_joint", "left_ankle_pitch_joint", "left_ankle_roll_joint",
            "right_hip_pitch_joint", "right_hip_roll_joint", "right_hip_yaw_joint", "right_knee_joint", "right_ankle_pitch_joint", "right_ankle_roll_joint",
            "waist_yaw_joint", "waist_roll_joint", "waist_pitch_joint",
            "left_shoulder_pitch_joint", "left_shoulder_roll_joint", "left_shoulder_yaw_joint", "left_elbow_joint",
            "right_shoulder_pitch_joint", "right_shoulder_roll_joint", "right_shoulder_yaw_joint", "right_elbow_joint"
        ]
        self.old_PHYS_23_NAMES = [
            "left_hip_pitch_joint", "right_hip_pitch_joint", "waist_yaw_joint",
            "left_hip_roll_joint", "right_hip_roll_joint", "waist_roll_joint",
            "left_hip_yaw_joint", "right_hip_yaw_joint", "waist_pitch_joint",
            "left_knee_joint", "right_knee_joint", "left_shoulder_pitch_joint",
            "right_shoulder_pitch_joint", "left_ankle_pitch_joint", "right_ankle_pitch_joint",
            "left_shoulder_roll_joint", "right_shoulder_roll_joint", "left_ankle_roll_joint",
            "right_ankle_roll_joint", "left_shoulder_yaw_joint", "right_shoulder_yaw_joint",
            "left_elbow_joint", "right_elbow_joint"
        ]
        self.old_isaac_to_mujoco_idx = [self.old_PHYS_23_NAMES.index(name) for name in self.old_MUJOCO_PHYS_NAMES]
        self.old_WBC_23_NAMES = self.old_MUJOCO_PHYS_NAMES
        self.old_WBC_23_DEFAULT = np.array([
            -0.1, 0.0, 0.0, 0.3, -0.2, 0.0,
            -0.1, 0.0, 0.0, 0.3, -0.2, 0.0,
            0.0, 0.0, 0.0,
            0.5, 0.0, 0.2, 0.3,
            0.5, 0.0, -0.2, 0.3,
        ], dtype=np.float32)
        self.old_wbc_dict = {name: val for name, val in zip(self.old_WBC_23_NAMES, self.old_WBC_23_DEFAULT)}
        self.old_default_dof_pos = np.array([self.old_wbc_dict[name] for name in self.old_PHYS_23_NAMES], dtype=np.float32)
        self.WBC_23_DEFAULT = np.array([-0.1, 0.0, 0.0, 0.3, -0.2, 0.0, -0.1, 0.0, 0.0, 0.3, -0.2, 0.0, 0.0, 0.0, 0.0, 0.5, 0.0, 0.462, 0.65, 0.5, 0.0, -0.462, 0.65], dtype=np.float32)
        self.wbc_dict = {name: val for name, val in zip(self.WBC_23_NAMES, self.WBC_23_DEFAULT)}
        self.default_dof_pos = np.array([self.wbc_dict[name] for name in self.PHYS_23_NAMES], dtype=np.float32)
        self.action_scale = 0.25
        self.scales_ang_vel = 0.25
        self.scales_dof_vel = 0.05
        self._n_demo_dof = 8
        self.n_priv = 3
        self.gait_freq = 1.3*2
        self.demo_obs_template = np.zeros((8 + 3 + 3 + 3,))
        self.demo_obs_template[: self._n_demo_dof] = self.default_dof_pos[15:23]
        self.demo_obs_template[self._n_demo_dof + 6 : self._n_demo_dof + 9] = 0.75
        self._commands = torch.zeros(self.num_envs, 3, device=self._device, dtype=torch.float32)
        self.targets = torch.zeros(self.num_envs, 3, device=self._device, dtype=torch.float32)
        self.potentials = torch.zeros(self.num_envs, device=self._device, dtype=torch.float32)
        self.prev_potentials = torch.zeros(self.num_envs, device=self._device, dtype=torch.float32)
        self.inv_start_rot = torch.zeros(self.num_envs, 4, device=self._device, dtype=torch.float32)
        self.basis_vec0 = torch.zeros(self.num_envs, 3, device=self._device, dtype=torch.float32)
        self.basis_vec1 = torch.zeros(self.num_envs, 3, device=self._device, dtype=torch.float32)
        self._episode_sums = {}
        self.previous_actions = {}
        for robot_id in ["robot_0", "robot_1"]:
            self.previous_actions[robot_id] = torch.zeros((self.num_envs, 3), device=self._device, dtype=torch.float32)
        self.halpo_control_step = 0
        self.processed_actions = {}
        for env_idx in range(self.num_envs):
            for robot_id in ["robot_0", "robot_1"]:
                self.processed_actions[(env_idx, robot_id)] = np.zeros(23, dtype=np.float32)
        max_len = getattr(self.cfg, 'max_episode_length', None)
        if max_len is not None:
            self._max_episode_length = max_len
        else:
            seconds_per_env_step_val = self.cfg.sim.dt * self.cfg.decimation
            self._max_episode_length = math.ceil(self.cfg.episode_length_s / seconds_per_env_step_val)



    def to_numpy(self, x):
        if isinstance(x, torch.Tensor):
            return x.detach().cpu().numpy()
        return x


    def get_wbc_observation(self, robot_id, env_idx=0):
        self._update_dynamic_short_goals()

        self_pos_w = self.robots[robot_id].data.root_pos_w[env_idx].cpu().numpy()
        self_lin_vel_w = self.robots[robot_id].data.root_com_lin_vel_w[env_idx].cpu().numpy()
        self_quat_w = self.robots[robot_id].data.root_link_quat_w[env_idx].cpu().numpy()
        self_rpy = quat_to_euler_angles_torch(torch.tensor(self_quat_w, dtype=torch.float32).unsqueeze(0)).cpu().numpy()[0]
        self_yaw = self_rpy[2]

        other_id = "robot_1" if robot_id == "robot_0" else "robot_0"
        other_pos_w = self.robots[other_id].data.root_pos_w[env_idx].cpu().numpy()
        other_lin_vel_w = self.robots[other_id].data.root_com_lin_vel_w[env_idx].cpu().numpy()
        other_quat_w = self.robots[other_id].data.root_link_quat_w[env_idx].cpu().numpy()
        other_rpy = quat_to_euler_angles_torch(torch.tensor(other_quat_w, dtype=torch.float32).unsqueeze(0)).cpu().numpy()[0]
        other_yaw = other_rpy[2]

        box_pos_w = self.object.data.root_com_pos_w[env_idx].cpu().numpy()
        box_quat_w = self.object.data.root_com_quat_w[env_idx].cpu().numpy()
        
        stick_length = 2.0
        stick_width = 0.06
        stick_height = 0.06
        
local_vertex1 = np.array([stick_length/2, 0, 0], dtype=np.float32)
local_vertex2 = np.array([-stick_length/2, 0, 0], dtype=np.float32)
        
        w, x, y, z = box_quat_w
        rot_matrix = np.array([
            [1 - 2*y*y - 2*z*z, 2*x*y - 2*w*z, 2*x*z + 2*w*y],
            [2*x*y + 2*w*z, 1 - 2*x*x - 2*z*z, 2*y*z - 2*w*x],
            [2*x*z - 2*w*y, 2*y*z + 2*w*x, 1 - 2*x*x - 2*y*y],
        ], dtype=np.float32)
        
        world_vertex1 = rot_matrix @ local_vertex1 + box_pos_w
        world_vertex2 = rot_matrix @ local_vertex2 + box_pos_w

        if hasattr(self, '_fixed_long_goals') and hasattr(self, '_target_angles'):
            target_pos = self._fixed_long_goals[env_idx].cpu().numpy()
            target_angle = self._target_angles[env_idx].cpu().numpy()
            
            cos_angle = np.cos(target_angle)
            sin_angle = np.sin(target_angle)
            target_vertex1 = np.array([
                target_pos[0] + stick_length/2 * cos_angle,
                target_pos[1] + stick_length/2 * sin_angle,
                0.0
            ], dtype=np.float32)
            target_vertex2 = np.array([
                target_pos[0] - stick_length/2 * cos_angle,
                target_pos[1] - stick_length/2 * sin_angle,
                0.0
            ], dtype=np.float32)
        else:
            target_vertex1 = world_vertex1.copy()
            target_vertex2 = world_vertex2.copy()

        obs_list = [
self_pos_w[0], self_pos_w[1],
self_lin_vel_w[0], self_lin_vel_w[1],
            
self_yaw,
            
other_pos_w[0], other_pos_w[1],
other_lin_vel_w[0], other_lin_vel_w[1],
            
other_yaw,
            
world_vertex1[0], world_vertex1[1],
world_vertex2[0], world_vertex2[1],
            
target_vertex1[0], target_vertex1[1],
target_vertex2[0], target_vertex2[1],
        ]

        obs = np.asarray(obs_list, dtype=np.float32)
        return obs, None

    def get_wbc_observation_old_complete(self, robot_id, env_idx=0):
        def to_cpu_numpy(x):
            if isinstance(x, torch.Tensor):
                return x.detach().cpu().numpy()
            return x

        dof_pos = to_cpu_numpy(self.robots[robot_id].data.joint_pos[env_idx, :23])
        dof_vel = to_cpu_numpy(self.robots[robot_id].data.joint_vel[env_idx, :23])
        root_quat = to_cpu_numpy(self.robots[robot_id].data.root_link_quat_w[env_idx])
        root_ang_vel = to_cpu_numpy(self.robots[robot_id].data.root_com_ang_vel_w[env_idx])

        def quat_to_euler_original(quat):
            w, x, y, z = quat
            roll = math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
            pitch = math.asin(2 * (w * y - z * x))
            yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))
            return np.array([roll, pitch, yaw])

        rpy = quat_to_euler_original(root_quat)
high_level_cmd = self.old_high_level_cmd[(env_idx, robot_id)]
        target_yaw = high_level_cmd[1]

        self.old_in_place_stand_flag[(env_idx, robot_id)] = (np.abs(high_level_cmd[0]) < 0.1) and (np.abs(high_level_cmd[2]) < 0.1)

        dyaw = rpy[2] - target_yaw
        dyaw = np.remainder(dyaw + np.pi, 2 * np.pi) - np.pi
        if self.old_in_place_stand_flag[(env_idx, robot_id)]:
            target_yaw = rpy[2]
        
        if robot_id == "robot_0":
dyaw = np.clip(dyaw, -0.05, 0.05)
        elif robot_id == "robot_1":
dyaw = np.clip(dyaw, -0.15, 0.15)

        gait_obs = np.sin(self.old_gait_cycle[(env_idx, robot_id)] * 2 * np.pi)

        dof_pos_mujoco_order = dof_pos[self.old_isaac_to_mujoco_idx]
        adapter_input = np.concatenate([np.zeros(4), dof_pos_mujoco_order[15:]])
        adapter_input[0] = 0.75 + high_level_cmd[3]
        adapter_input[1] = high_level_cmd[4]
        adapter_input[2] = high_level_cmd[5]
        adapter_input[3] = high_level_cmd[6]
        adapter_input_tensor = torch.tensor(adapter_input, device=self.device, dtype=torch.float32).unsqueeze(0)
        with torch.no_grad():
            adapter_output = torch.zeros(15, device=self.device, dtype=torch.float32).unsqueeze(0)

        dof_pos_error = dof_pos - self.old_default_dof_pos[:23]
        dof_pos_error_mujoco_order = dof_pos_error[self.old_isaac_to_mujoco_idx]
        dof_vel_mujoco_order = dof_vel[self.old_isaac_to_mujoco_idx]
        last_action_mujoco_order = self.old_last_action[(env_idx, robot_id)][self.old_isaac_to_mujoco_idx]

        obs_prop = np.concatenate([
            root_ang_vel * self.scales_ang_vel,
            rpy[:2],
            np.array([np.sin(dyaw), np.cos(dyaw)]),
            dof_pos_error_mujoco_order,
            dof_vel_mujoco_order * self.scales_dof_vel,
            last_action_mujoco_order,
            gait_obs,
            adapter_output.cpu().numpy().squeeze(),
        ])

        obs_demo = np.zeros(17, dtype=np.float32)
        obs_demo[:self._n_demo_dof] = dof_pos_mujoco_order[15:]
        obs_demo[self._n_demo_dof] = high_level_cmd[0]
        obs_demo[self._n_demo_dof+1] = high_level_cmd[2]
        obs_demo[self._n_demo_dof+3] = high_level_cmd[4]
        obs_demo[self._n_demo_dof+4] = high_level_cmd[5]
        obs_demo[self._n_demo_dof+5] = high_level_cmd[6]
        obs_demo[self._n_demo_dof+6:self._n_demo_dof+9] = 0.75 + high_level_cmd[3]

        obs_priv = np.zeros((self.n_priv,), dtype=np.float32)

        self.old_proprio_history_buf[(env_idx, robot_id)].append(obs_prop.astype(np.float64))
        obs_hist = np.array(self.old_proprio_history_buf[(env_idx, robot_id)]).flatten()
        self.old_extra_history_buf[(env_idx, robot_id)].append(obs_prop.astype(np.float64))

        obs = np.concatenate((obs_prop, obs_demo, obs_priv, obs_hist))
        return obs, obs_prop

    def update_old_last_action(self, robot_id, wbc_action_15, env_idx=0):
        if not hasattr(self, 'old_last_action'):
            self.old_last_action = {(e, rid): np.zeros(23, dtype=np.float32) for e in range(self.num_envs) for rid in ["robot_0", "robot_1"]}
        dof_pos = self.to_numpy(self.robots[robot_id].data.joint_pos[env_idx, :23])
        dof_pos_mujoco_order = dof_pos[self.old_isaac_to_mujoco_idx]
        default_dof_pos_mujoco_order = self.old_default_dof_pos[self.old_isaac_to_mujoco_idx]
        arm_pos_delta_scaled = (dof_pos_mujoco_order[15:] - default_dof_pos_mujoco_order[15:]) / self.action_scale
        last_action_23_mujoco_order = np.concatenate([wbc_action_15, arm_pos_delta_scaled])
        mujoco_to_isaac_map = {name: i for i, name in enumerate(self.old_MUJOCO_PHYS_NAMES)}
        self.old_last_action[(env_idx, robot_id)] = np.array([last_action_23_mujoco_order[mujoco_to_isaac_map.get(name)] for name in self.old_PHYS_23_NAMES])

    def _old_pre_physics_step(self, robot_id, env_idx=0, update_gait=False):
        if not hasattr(self, 'old_wbc_control_step'):
            self.old_wbc_control_step = 0
        self.old_wbc_control_step += 1
        
        high_level_cmd = self.old_high_level_cmd[(env_idx, robot_id)]
        

        
        if self.old_in_place_stand_flag[(env_idx, robot_id)]:
            self.old_gait_cycle[(env_idx, robot_id)] = np.array([0.25, 0.25])
        else:
            self.old_gait_cycle[(env_idx, robot_id)] = np.remainder(self.old_gait_cycle[(env_idx, robot_id)] + self.cfg.sim.dt * self.cfg.decimation * self.gait_freq, 1.0)
            if (np.abs(self.old_gait_cycle[(env_idx, robot_id)][0] - 0.25) < 0.05) and (np.abs(self.old_gait_cycle[(env_idx, robot_id)][1] - 0.25) < 0.05):
                self.old_gait_cycle[(env_idx, robot_id)] = np.array([0.25, 0.75])
        obs_old, obs_prop_old = self.get_wbc_observation_old_complete(robot_id, env_idx)
        obs_old_tensor = torch.from_numpy(obs_old).float().unsqueeze(0).to(self.device)
        extra_hist_old = np.array(self.old_extra_history_buf[(env_idx, robot_id)]).flatten()
        extra_hist_old_tensor = torch.from_numpy(extra_hist_old).float().unsqueeze(0).to(self.device)
        with torch.no_grad():
            wbc_action_15_old = np.zeros(15, dtype=np.float32)
        self.update_old_last_action(robot_id, wbc_action_15_old, env_idx)
        wbc_action_23_delta = np.concatenate([wbc_action_15_old, np.zeros(8, dtype=wbc_action_15_old.dtype)])
        old_wbc_dict = {name: val for name, val in zip(self.old_WBC_23_NAMES, wbc_action_23_delta)}
        wbc_action_23_delta_phys = np.array([old_wbc_dict.get(name) for name in self.old_PHYS_23_NAMES], dtype=np.float32)
        base = self.old_default_dof_pos.copy()
        wbc_action_23_final_old = base + wbc_action_23_delta_phys * self.action_scale
        left_shoulder_pitch = np.clip(self.old_high_level_cmd[(env_idx, robot_id)][7], -1.6, 0)
        right_shoulder_pitch = np.clip(self.old_high_level_cmd[(env_idx, robot_id)][8], -1.6, 0)
        l_idx = self.old_PHYS_23_NAMES.index('left_shoulder_pitch_joint')
        r_idx = self.old_PHYS_23_NAMES.index('right_shoulder_pitch_joint')
        wbc_action_23_final_old[l_idx] = self.old_default_dof_pos[l_idx] + left_shoulder_pitch
        wbc_action_23_final_old[r_idx] = self.old_default_dof_pos[r_idx] + right_shoulder_pitch
        if update_gait:
            self.gait_cycle[(env_idx, robot_id)] = self.old_gait_cycle[(env_idx, robot_id)].copy()
            self.last_action[(env_idx, robot_id)] = self.old_last_action[(env_idx, robot_id)].copy()
            self.processed_actions[(env_idx, robot_id)] = wbc_action_23_final_old.copy()
        return wbc_action_15_old, wbc_action_23_final_old

    def _pre_physics_step(self, actions: Optional[dict[str, Any]] = None):
        self.halpo_control_step += 1
        
        if hasattr(self, '_reset_step_counters'):
            self._reset_step_counters += 1
        
        if actions is not None and not self.manual_high_level_cmd_mode:
            self.set_high_level_cmd_from_halpo(actions)
            for robot_id in self.robots.keys():
                self.previous_actions[robot_id] = actions[robot_id].clone()
        
        for env_idx in range(self.num_envs):
            for robot_id in self.robots.keys():
                halpo_action_15_old, halpo_action_23_final_old = self._old_pre_physics_step(robot_id, env_idx, update_gait=True)
                self.gait_cycle[(env_idx, robot_id)] = self.old_gait_cycle[(env_idx, robot_id)].copy() if hasattr(self, 'old_gait_cycle') and (env_idx, robot_id) in self.old_gait_cycle else np.array([0.25, 0.25])
                self.last_action[(env_idx, robot_id)] = self.old_last_action[(env_idx, robot_id)].copy() if hasattr(self, 'old_last_action') and (env_idx, robot_id) in self.old_last_action else np.zeros(23, dtype=np.float32)
                self.processed_actions[(env_idx, robot_id)] = halpo_action_23_final_old.copy()
        
        self._update_dynamic_short_goals()
        
        self._draw_markers_with_fixed_goals()

    def _reset_idx(self, env_ids: torch.Tensor):
        if env_ids is None:
            env_ids = torch.arange(self.num_envs, device=self.device)

        for robot in self.robots.values():
            default_root_state = robot.data.default_root_state[env_ids].clone()
            default_root_state[:, :3] += self._terrain.env_origins[env_ids]
            robot.write_root_state_to_sim(default_root_state, env_ids)
            joint_pos = robot.data.default_joint_pos[env_ids]
            joint_vel = robot.data.default_joint_vel[env_ids]
            robot.write_joint_state_to_sim(joint_pos, joint_vel, None, env_ids)
        
        if hasattr(self, "object"):
            default_root_state_obj = self.object.data.default_root_state[env_ids].clone()
            default_root_state_obj[:, :3] += self._terrain.env_origins[env_ids]
            self.object.write_root_state_to_sim(default_root_state_obj, env_ids)
        
        env_ids_list = env_ids.tolist() if isinstance(env_ids, torch.Tensor) else env_ids

        for env_idx in env_ids_list:
            for robot_id in self.robots.keys():
                self.gait_cycle[(env_idx, robot_id)] = np.array([0.25, 0.25])
                if hasattr(self, '_pending_halpo_cmd') and (env_idx, robot_id) in self._pending_halpo_cmd:
                    cmd = self._pending_halpo_cmd[(env_idx, robot_id)]
                    self.high_level_cmd[(env_idx, robot_id)] = cmd
                    self.old_high_level_cmd[(env_idx, robot_id)] = cmd.copy()
                high_level_cmd = self.high_level_cmd[(env_idx, robot_id)]
                self.in_place_stand_flag[(env_idx, robot_id)] = (np.abs(high_level_cmd[0]) < 0.1) and (np.abs(high_level_cmd[2]) < 0.1)
                self.last_action[(env_idx, robot_id)] = np.zeros(23, dtype=np.float32)
                self.last_action_buffer[(env_idx, robot_id)] = np.zeros(23, dtype=np.float32)
                self.proprio_history_buf[(env_idx, robot_id)] = deque([np.zeros(self.wbc_n_proprio) for _ in range(self.history_len)], maxlen=self.history_len)
                self.extra_history_buf[(env_idx, robot_id)] = deque([np.zeros(self.wbc_n_proprio) for _ in range(self.extra_history_len)], maxlen=self.extra_history_len)
                if not hasattr(self, 'processed_actions'):
                    self.processed_actions = {}
                self.processed_actions[(env_idx, robot_id)] = np.zeros(23, dtype=np.float32)

        if not hasattr(self, 'potentials'):
            self.potentials = torch.zeros(self.num_envs, device=self.device, dtype=torch.float32)
        if not hasattr(self, 'prev_potentials'):
            self.prev_potentials = torch.zeros(self.num_envs, device=self.device, dtype=torch.float32)
        if not hasattr(self, '_episode_sums'):
            self._episode_sums = {}
        
        self.potentials[env_ids] = 0.0
        self.prev_potentials[env_ids] = 0.0
        
        for key in self._episode_sums.keys():
            self._episode_sums[key][env_ids] = 0.0
        
        self.episode_length_buf[env_ids] = 0
        self.halpo_control_step = 0
        
        if not hasattr(self, '_reset_step_counters'):
            self._reset_step_counters = torch.zeros(self.num_envs, device=self.device, dtype=torch.int32)
        self._reset_step_counters[env_ids] = 0

        for robot_id in self.robots.keys():
            self.previous_actions[robot_id][env_ids] = 0.0

        self._generate_fixed_target_goals(env_ids)


    def _generate_fixed_target_goals(self, env_ids: torch.Tensor):
        from isaaclab_tasks.utils.custom_trajectory import get_long_goal, astar_path_planning
        
        box_pos = self.object.data.body_com_pos_w.squeeze(1).clone()
        env_origins = self.scene.env_origins
        
        long_goal = get_long_goal(box_pos, env_origins, step=0, device=self.device)
        
        if not hasattr(self, '_fixed_long_goals'):
            self._fixed_long_goals = torch.zeros((self.num_envs, 3), device=self.device)
        
        if not hasattr(self, '_target_angles'):
            self._target_angles = torch.rand(self.num_envs, device=self.device) * 2 * torch.pi - torch.pi
        
        self._fixed_long_goals[env_ids] = long_goal[env_ids]
        self._target_angles[env_ids] = torch.rand(len(env_ids), device=self.device) * 2 * torch.pi - torch.pi
        
        start_pos = box_pos[env_ids]
        goal_pos = long_goal[env_ids]
        if not hasattr(self, '_astar_path') or self._astar_path is None:
            self._astar_path = torch.zeros((self.num_envs, 5, 2), device=self.device)
        self._astar_path[env_ids] = astar_path_planning(start_pos, goal_pos, device=self.device)

    def _update_dynamic_short_goals(self):
        from isaaclab_tasks.utils.custom_trajectory import get_short_term_goal
        
        box_pos = self.object.data.body_com_pos_w.squeeze(1).clone()
        
        if not hasattr(self, '_fixed_long_goals') or not hasattr(self, '_target_angles'):
            return
        
        short_goal = (box_pos + self._fixed_long_goals) / 2
        
        if not hasattr(self, '_current_short_goals'):
            self._current_short_goals = torch.zeros((self.num_envs, 3), device=self.device)
        if not hasattr(self, '_current_commands'):
            self._current_commands = torch.zeros((self.num_envs, 3), device=self.device)
        
        self._current_short_goals[:] = short_goal
        
        box_to_goal = self._current_short_goals - box_pos
push_direction = box_to_goal[:, :2]
        
        push_direction_norm = torch.norm(push_direction, dim=1, keepdim=True)
        push_direction = push_direction / (push_direction_norm + 1e-8)
        push_speed = torch.clamp(push_direction_norm, 0.1, 1.0)
        push_direction = push_direction * push_speed
        
self._current_commands[:, 0] = push_direction[:, 0]
self._current_commands[:, 1] = push_direction[:, 1]
self._current_commands[:, 2] = 0.0


    def set_high_level_cmd_from_halpo(self, actions: dict[str, Any]):
        if not hasattr(self, '_pending_halpo_cmd') or self._pending_halpo_cmd is None:
            self._pending_halpo_cmd = {}
        
        box_pos = self.object.data.root_com_pos_w.cpu().numpy()
        
        for env_idx in range(self.num_envs):
            robot1_pos = self.robots["robot_1"].data.root_pos_w[env_idx, :2]
            self.lead_follow_controller.robot1_positions[env_idx] = robot1_pos
        
        for robot_id in ["robot_0", "robot_1"]:
            halpo_output = actions[robot_id]
            if isinstance(halpo_output, torch.Tensor):
                halpo_output = halpo_output.detach().cpu().numpy()
            
            for env_idx in range(self.num_envs):
                current_cmd = self.high_level_cmd.get((env_idx, robot_id), np.zeros(11, dtype=np.float32))
                
                if self.use_pi_only:
                    halpo_output_zero = np.zeros_like(halpo_output[env_idx] if halpo_output.ndim > 1 else halpo_output)
                else:
                    halpo_output_zero = halpo_output[env_idx] if halpo_output.ndim > 1 else halpo_output
                
                new_cmd = np.zeros(11, dtype=np.float32)
                new_cmd[0:3] = halpo_output_zero[0:3]
                new_cmd[3:5] = halpo_output_zero[3:5]
                new_cmd[5:11] = halpo_output_zero[5:11]
                
                new_cmd[0:3] = np.clip(new_cmd[0:3], -1.0, 1.0)
                new_cmd[3:5] = np.clip(new_cmd[3:5], -1.0, 1.0)
                new_cmd[5:11] = np.clip(new_cmd[5:11], -1.0, 1.0)
                
                self.high_level_cmd[(env_idx, robot_id)] = new_cmd
                self.old_high_level_cmd[(env_idx, robot_id)] = new_cmd.copy()
                self._pending_halpo_cmd[(env_idx, robot_id)] = new_cmd.copy()

    def _setup_scene(self):
        self.num_robots = sum(1 for key in self.cfg.__dict__.keys() if "robot_" in key)
        self.robots = {}
        self.contact_sensors = {}
        self.height_scanners = {}
        self.my_visualizer = define_markers()
        self.object = RigidObject(getattr(self.cfg, "cfg_rec_prism"))

        self.scene.rigid_objects["object"] = self.object

        for i in range(self.num_robots):
            robot_id = f"robot_{i}"
            if robot_id in self.cfg.__dict__:
                self.robots[f"robot_{i}"] = Articulation(self.cfg.__dict__["robot_" + str(i)])
                self.scene.articulations[f"robot_{i}"] = self.robots[f"robot_{i}"]

            contact_sensor_id = "contact_sensor_" + str(i)

            if contact_sensor_id in self.cfg.__dict__:
                self.contact_sensors[f"robot_{i}"] = ContactSensor(self.cfg.__dict__["contact_sensor_" + str(i)])
                self.scene.sensors[f"robot_{i}"] = self.contact_sensors[f"robot_{i}"]


        terrain_cfg = getattr(self.cfg, "terrain")
        terrain_cfg.num_envs = self.scene.cfg.num_envs
        terrain_cfg.env_spacing = self.scene.cfg.env_spacing
        self._terrain = terrain_cfg.class_type(terrain_cfg)
        self.scene.clone_environments(copy_from_source=False)
        self.scene.filter_collisions(global_prim_paths=[terrain_cfg.prim_path])
        light_cfg = sim_utils.DomeLightCfg(intensity=2000.0, color=(0.75, 0.75, 0.75))
        light_cfg.func("/World/Light", light_cfg)

    def _get_anymal_fallen(self):
        agent_dones = []
        robot = self.robots["robot_0"]
        anymal_min_z_pos = getattr(self.cfg, 'anymal_min_z_pos', 0.3)
        died = robot.data.body_com_pos_w[:, 0, 2].view(-1) < anymal_min_z_pos
        agent_dones.append(died)

        robot = self.robots["robot_1"]
        g1_min_z_pos = getattr(self.cfg, 'g1_min_z_pos', 0.6)
        died = robot.data.body_com_pos_w[:, 0, 2].view(-1) < g1_min_z_pos
        agent_dones.append(died)

        return torch.any(torch.stack(agent_dones), dim=0)

    def _apply_action(self):
        for robot_id in ["robot_0", "robot_1"]:
            actions = []
            for env_idx in range(self.num_envs):
                action = self.processed_actions[(env_idx, robot_id)]
                

                
                if isinstance(action, np.ndarray):
                    action = torch.from_numpy(action).to(device=self.device, dtype=torch.float32)
                if action.shape[-1] < 29:
                    pad = torch.zeros(29 - action.shape[-1], device=action.device, dtype=action.dtype)
                    action = torch.cat([action, pad], dim=-1)
                elif action.shape[-1] > 29:
                    action = action[..., :29]
                actions.append(action)
            actions_tensor = torch.stack(actions, dim=0)
            self.robots[robot_id].set_joint_position_target(actions_tensor)
            
            joint_names = self.robots[robot_id].data.joint_names
            left_wrist_roll_idx = None
            right_wrist_roll_idx = None
            for i, name in enumerate(joint_names):
                if name == "left_wrist_roll_joint":
                    left_wrist_roll_idx = i
                elif name == "right_wrist_roll_joint":
                    right_wrist_roll_idx = i
            
            if left_wrist_roll_idx is not None and right_wrist_roll_idx is not None:
                wrist_targets = torch.zeros(actions_tensor.shape[0], 2, device=actions_tensor.device, dtype=actions_tensor.dtype)
                
wrist_targets[:, 0] = 0.0
wrist_targets[:, 1] = 0.0
                
                self.robots[robot_id].set_joint_position_target(wrist_targets, joint_ids=[left_wrist_roll_idx, right_wrist_roll_idx])

            if getattr(self.cfg, 'wrist_roll_enable', False) or getattr(self.cfg, 'shoulder_yaw_enable', False) or getattr(self.cfg, 'shoulder_roll_enable', False):
                joint_names = self.robots[robot_id].data.joint_names
                left_wrist_roll_idx = None
                right_wrist_roll_idx = None
                left_shoulder_yaw_idx = None
                right_shoulder_yaw_idx = None
                left_shoulder_roll_idx = None
                right_shoulder_roll_idx = None
                for i, name in enumerate(joint_names):
                    if name == "left_wrist_roll_joint":
                        left_wrist_roll_idx = i
                    elif name == "right_wrist_roll_joint":
                        right_wrist_roll_idx = i
                    elif name == "left_shoulder_yaw_joint":
                        left_shoulder_yaw_idx = i
                    elif name == "right_shoulder_yaw_joint":
                        right_shoulder_yaw_idx = i
                    elif name == "left_shoulder_roll_joint":
                        left_shoulder_roll_idx = i
                    elif name == "right_shoulder_roll_joint":
                        right_shoulder_roll_idx = i
                
                joint_ids = []
                joint_targets = []
                
                if getattr(self.cfg, 'wrist_roll_enable', False):
                    if left_wrist_roll_idx is not None and right_wrist_roll_idx is not None:
                        joint_ids.extend([left_wrist_roll_idx, right_wrist_roll_idx])
                        joint_targets.extend([
                            float(getattr(self.cfg, 'wrist_roll_left_target', 0.0)),
                            float(getattr(self.cfg, 'wrist_roll_right_target', 0.0))
                        ])
                
                if getattr(self.cfg, 'shoulder_yaw_enable', False):
                    if left_shoulder_yaw_idx is not None and right_shoulder_yaw_idx is not None:
                        joint_ids.extend([left_shoulder_yaw_idx, right_shoulder_yaw_idx])
                        joint_targets.extend([
                            float(getattr(self.cfg, 'shoulder_yaw_left_target', 0.0)),
                            float(getattr(self.cfg, 'shoulder_yaw_right_target', 0.0))
                        ])
                
                if getattr(self.cfg, 'shoulder_roll_enable', False):
                    if left_shoulder_roll_idx is not None and right_shoulder_roll_idx is not None:
                        joint_ids.extend([left_shoulder_roll_idx, right_shoulder_roll_idx])
                        joint_targets.extend([
                            float(getattr(self.cfg, 'shoulder_roll_left_target', 0.0)),
                            float(getattr(self.cfg, 'shoulder_roll_right_target', 0.0))
                        ])
                
                if joint_ids:
                    targets = torch.zeros(actions_tensor.shape[0], len(joint_ids), device=actions_tensor.device, dtype=actions_tensor.dtype)
                    for i, target_val in enumerate(joint_targets):
                        targets[:, i] = target_val
                    self.robots[robot_id].set_joint_position_target(targets, joint_ids=joint_ids)


    def _get_observations(self) -> dict[str, torch.Tensor]:
        obs_dict: dict[str, torch.Tensor] = {}

        pos_0 = self.robots["robot_0"].data.root_state_w[:, :3]
        pos_1 = self.robots["robot_1"].data.root_state_w[:, :3]
        vel_0 = self.robots["robot_0"].data.root_com_lin_vel_w[:, :3]
        vel_1 = self.robots["robot_1"].data.root_com_lin_vel_w[:, :3]
        quat_0 = self.robots["robot_0"].data.root_link_quat_w
        quat_1 = self.robots["robot_1"].data.root_link_quat_w

        ypr_0 = quat_to_euler_angles_torch(quat_0)
        ypr_1 = quat_to_euler_angles_torch(quat_1)
        yaw_0 = ypr_0[:, 2]
        yaw_1 = ypr_1[:, 2]

        box_pos = self.object.data.root_com_pos_w
        box_vel = self.object.data.root_com_lin_vel_w
        box_quat = self.object.data.root_com_quat_w
        
        stick_length = 2.0
        box_length, box_width, box_height = 0.22, 2.0, 0.05
        
        local_corners = torch.tensor([
            [box_length/2, box_width/2, box_height/2],
            [box_length/2, -box_width/2, box_height/2],
            [-box_length/2, -box_width/2, box_height/2],
            [-box_length/2, box_width/2, box_height/2],
        ], device=self.device, dtype=torch.float32)
        
        w, x, y, z = box_quat[:, 0], box_quat[:, 1], box_quat[:, 2], box_quat[:, 3]
        rot_matrix = torch.stack([
            torch.stack([1 - 2*y*y - 2*z*z, 2*x*y - 2*w*z, 2*x*z + 2*w*y], dim=1),
            torch.stack([2*x*y + 2*w*z, 1 - 2*x*x - 2*z*z, 2*y*z - 2*w*x], dim=1),
            torch.stack([2*x*z - 2*w*y, 2*y*z + 2*w*x, 1 - 2*x*x - 2*y*y], dim=1)
        ], dim=1)
        
        world_corners = []
        for i in range(4):
            corner_world = torch.bmm(rot_matrix, local_corners[i].unsqueeze(1).expand(self.num_envs, 3, 1)).squeeze(-1) + box_pos
            world_corners.append(corner_world)
        world_corners = torch.stack(world_corners, dim=1)

        if not hasattr(self, '_observation_history'):
            self._observation_history = {robot_id: deque([torch.zeros(52, device=self.device) for _ in range(3)], maxlen=3) for robot_id in ["robot_0", "robot_1"]}

        for robot_id in ["robot_0", "robot_1"]:
            if robot_id == "robot_0":
                self_pos, self_vel, self_yaw = pos_0, vel_0, yaw_0
                other_pos, other_vel, other_yaw = pos_1, vel_1, yaw_1
            else:
                self_pos, self_vel, self_yaw = pos_1, vel_1, yaw_1
                other_pos, other_vel, other_yaw = pos_0, vel_0, yaw_0

            cos_yaw = torch.cos(self_yaw)
            sin_yaw = torch.sin(self_yaw)
            rot_to_ego = torch.stack([
                torch.stack([cos_yaw, sin_yaw], dim=1),
                torch.stack([-sin_yaw, cos_yaw], dim=1)
            ], dim=1)

            waypoints = torch.zeros(self.num_envs, 10, device=self.device)
            if hasattr(self, '_astar_path') and self._astar_path is not None:
                for i in range(5):
                    waypoint_world = self._astar_path[:, i, :2]
                    waypoint_rel = waypoint_world - self_pos[:, :2]
                    waypoint_ego = torch.bmm(rot_to_ego, waypoint_rel.unsqueeze(-1)).squeeze(-1)
                    waypoints[:, i*2:(i+1)*2] = waypoint_ego

            self_proprio = torch.cat([
                self_pos[:, :2],
                self_vel[:, :2],
                self_yaw.unsqueeze(1),
                self_pos[:, 2:3],
                ypr_0[:, 1:2] if robot_id == "robot_0" else ypr_1[:, 1:2],
                torch.zeros(self.num_envs, 3, device=self.device),
            ], dim=1)[:, :11]

            other_rel_pos = other_pos[:, :2] - self_pos[:, :2]
            other_rel_vel = other_vel[:, :2] - self_vel[:, :2]
            other_rel_pos_ego = torch.bmm(rot_to_ego, other_rel_pos.unsqueeze(-1)).squeeze(-1)
            other_rel_vel_ego = torch.bmm(rot_to_ego, other_rel_vel.unsqueeze(-1)).squeeze(-1)
            other_yaw_rel = other_yaw - self_yaw
            other_yaw_rel = torch.remainder(other_yaw_rel + torch.pi, 2 * torch.pi) - torch.pi
            
            partner_obs = torch.cat([
                other_rel_pos_ego,
                other_rel_vel_ego,
                other_yaw_rel.unsqueeze(1),
                other_pos[:, 2:3],
                ypr_1[:, 1:2] if robot_id == "robot_0" else ypr_0[:, 1:2],
                torch.zeros(self.num_envs, 3, device=self.device),
            ], dim=1)[:, :11]

            box_rel_pos = box_pos[:, :2] - self_pos[:, :2]
            box_rel_vel = box_vel[:, :2] - self_vel[:, :2]
            box_rel_pos_ego = torch.bmm(rot_to_ego, box_rel_pos.unsqueeze(-1)).squeeze(-1)
            box_rel_vel_ego = torch.bmm(rot_to_ego, box_rel_vel.unsqueeze(-1)).squeeze(-1)
            
            corners_rel = world_corners[:, :, :2] - self_pos[:, None, :2]
            corners_ego = torch.bmm(rot_to_ego.unsqueeze(1).expand(-1, 4, -1, -1), corners_rel.unsqueeze(-1)).squeeze(-1)
            
            object_geom = torch.cat([
                corners_ego.reshape(self.num_envs, -1),
                box_rel_pos_ego,
                box_pos[:, 2:3],
                box_rel_vel_ego,
                box_vel[:, 2:3],
            ], dim=1)[:, :18]

            contact = torch.zeros(self.num_envs, 2, device=self.device)
            if hasattr(self, 'contact_sensors') and robot_id in self.contact_sensors:
                contact_forces = self.contact_sensors[robot_id].data.net_forces_w
                try:
                    left_idx, _ = self.robots[robot_id].find_bodies("left_rubber_hand")
                    right_idx, _ = self.robots[robot_id].find_bodies("right_rubber_hand")
                    if len(left_idx) > 0:
                        contact[:, 0] = (torch.norm(contact_forces[:, left_idx[0], :], dim=-1) > 0.1).float()
                    if len(right_idx) > 0:
                        contact[:, 1] = (torch.norm(contact_forces[:, right_idx[0], :], dim=-1) > 0.1).float()
                except:
                    pass

            lidar_distances = torch.ones(self.num_envs, 36, device=self.device) * 5.0

            snapshot = torch.cat([
                self_proprio,
                partner_obs,
                object_geom,
                contact,
                lidar_distances,
            ], dim=1)[:, :52]

            self._observation_history[robot_id].append(snapshot)
            hist_tensor = torch.stack(list(self._observation_history[robot_id]), dim=1).reshape(self.num_envs, -1)

            obs = torch.cat([
                waypoints,
                snapshot,
                hist_tensor,
            ], dim=1)[:, :192]

            obs_dict[robot_id] = obs.to(device=self.device, dtype=torch.float32)

        return obs_dict

    def _get_states(self) -> torch.Tensor:
        
        obs = self._get_observations()["robot_0"]
        return obs

    def get_y_euler_from_quat(self, quaternion):
        w, x, y, z = quaternion[:, 0], quaternion[:, 1], quaternion[:, 2], quaternion[:, 3]
        y_euler_angle = torch.arcsin(2 * (w * y - z * x))
        return y_euler_angle

    def _draw_markers(self, step=None):
        from isaaclab_tasks.utils.custom_trajectory import get_long_goal, get_short_term_goal

        box_pos = self.object.data.root_com_pos_w.clone()
        env_origins = self.scene.env_origins
        
        step_val = step if step is not None else 0
        long_goal = get_long_goal(box_pos, env_origins, step=step_val, device=self.device)
        short_goal = get_short_term_goal(box_pos, long_goal, distance=1.8)

        box_marker_pos = box_pos.clone()
box_marker_pos[:, 2] += 0.2
        marker_locations = torch.cat(
            [
box_marker_pos,
short_goal,
            ],
            dim=0,
        )

        marker_ids = torch.cat(
            [
torch.zeros(self.num_envs, dtype=torch.int64, device=self.device),
torch.ones(self.num_envs, dtype=torch.int64, device=self.device),
            ],
            dim=0,
        )
        num_markers = marker_locations.shape[0]
        orientations = torch.tensor([1, 0, 0, 1], device=marker_locations.device, dtype=marker_locations.dtype).repeat(
            num_markers, 1
        )
        desired_scale = 0.25
        scales = torch.tensor([desired_scale, desired_scale, desired_scale], device=self.device, dtype=torch.float32).repeat(num_markers, 1)

        self.my_visualizer.visualize(marker_locations, orientations, scales, marker_ids)

    def _draw_markers_with_fixed_goals(self):
        if not hasattr(self, '_current_short_goals') or not hasattr(self, '_target_angles') or not hasattr(self, '_fixed_long_goals'):
            return
            
        box_pos = self.object.data.root_com_pos_w.clone()
        box_quat = self.object.data.root_com_quat_w
        
        stick_length = 2.0
        
        local_vertex1 = torch.tensor([stick_length/2, 0, 0], device=self.device, dtype=torch.float32)
        local_vertex2 = torch.tensor([-stick_length/2, 0, 0], device=self.device, dtype=torch.float32)
        
        w, x, y, z = box_quat[:, 0], box_quat[:, 1], box_quat[:, 2], box_quat[:, 3]
        rot_matrix = torch.stack([
            torch.stack([1 - 2*y*y - 2*z*z, 2*x*y - 2*w*z, 2*x*z + 2*w*y], dim=1),
            torch.stack([2*x*y + 2*w*z, 1 - 2*x*x - 2*z*z, 2*y*z - 2*w*x], dim=1),
            torch.stack([2*x*z - 2*w*y, 2*y*z + 2*w*x, 1 - 2*x*x - 2*y*y], dim=1)
        ], dim=1)
        
        world_vertex1 = torch.bmm(rot_matrix, local_vertex1.unsqueeze(1).expand(self.num_envs, 3, 1)).squeeze(-1) + box_pos
        world_vertex2 = torch.bmm(rot_matrix, local_vertex2.unsqueeze(1).expand(self.num_envs, 3, 1)).squeeze(-1) + box_pos
        
        stick_center = (world_vertex1 + world_vertex2) / 2
stick_center[:, 2] += 0.4
        
        short_goal = self._current_short_goals.clone()
short_goal[:, 2] += 0.4
        
        long_goals = self._fixed_long_goals
        target_angles = self._target_angles
        
        cos_angle = torch.cos(target_angles)
        sin_angle = torch.sin(target_angles)
        target_vertex1 = torch.stack([
            long_goals[:, 0] + stick_length/2 * cos_angle,
            long_goals[:, 1] + stick_length/2 * sin_angle,
long_goals[:, 2] + 0.4
        ], dim=1)
        target_vertex2 = torch.stack([
            long_goals[:, 0] - stick_length/2 * cos_angle,
            long_goals[:, 1] - stick_length/2 * sin_angle,
long_goals[:, 2] + 0.4
        ], dim=1)
        
        marker_locations = torch.cat(
            [
stick_center,
short_goal,
target_vertex1,
target_vertex2,
            ],
            dim=0,
        )

        marker_ids = torch.cat(
            [
torch.zeros(self.num_envs, dtype=torch.int64, device=self.device),
torch.ones(self.num_envs, dtype=torch.int64, device=self.device),
torch.full((self.num_envs,), 2, dtype=torch.int64, device=self.device),
torch.full((self.num_envs,), 2, dtype=torch.int64, device=self.device),
            ],
            dim=0,
        )
        
        num_markers = marker_locations.shape[0]
        orientations = torch.tensor([1, 0, 0, 1], device=marker_locations.device, dtype=marker_locations.dtype).repeat(
            num_markers, 1
        )
        desired_scale = 0.25
        scales = torch.tensor([desired_scale, desired_scale, desired_scale], device=self.device, dtype=torch.float32).repeat(num_markers, 1)

        self.my_visualizer.visualize(marker_locations, orientations, scales, marker_ids)



    def _get_rewards(self) -> dict:
        reward = {}

        if not hasattr(self, '_episode_sums'):
            self._episode_sums = {}

        box_pos = self.object.data.root_com_pos_w
        box_quat = self.object.data.root_com_quat_w
        
        box_length, box_width, box_height = 0.22, 2.0, 0.05
        local_corners = torch.tensor([
            [box_length/2, box_width/2, box_height/2],
            [box_length/2, -box_width/2, box_height/2],
            [-box_length/2, -box_width/2, box_height/2],
            [-box_length/2, box_width/2, box_height/2],
        ], device=self.device, dtype=torch.float32)
        
        w, x, y, z = box_quat[:, 0], box_quat[:, 1], box_quat[:, 2], box_quat[:, 3]
        rot_matrix = torch.stack([
            torch.stack([1 - 2*y*y - 2*z*z, 2*x*y - 2*w*z, 2*x*z + 2*w*y], dim=1),
            torch.stack([2*x*y + 2*w*z, 1 - 2*x*x - 2*z*z, 2*y*z - 2*w*x], dim=1),
            torch.stack([2*x*z - 2*w*y, 2*y*z + 2*w*x, 1 - 2*x*x - 2*y*y], dim=1)
        ], dim=1)
        
        world_corners_z = []
        for i in range(4):
            corner_world = torch.bmm(rot_matrix, local_corners[i].unsqueeze(1).expand(self.num_envs, 3, 1)).squeeze(-1) + box_pos
            world_corners_z.append(corner_world[:, 2])
        corners_z = torch.stack(world_corners_z, dim=1)
        z_mean = torch.mean(corners_z, dim=1, keepdim=True)
        tilt_penalty = torch.sum(torch.abs(corners_z - z_mean), dim=1)

        if not hasattr(self, '_prev_box_pos'):
            self._prev_box_pos = box_pos.clone()
        if not hasattr(self, '_path_length_traversed'):
            self._path_length_traversed = torch.zeros(self.num_envs, device=self.device)
        if not hasattr(self, '_path_length_total'):
            self._path_length_total = torch.zeros(self.num_envs, device=self.device)

        if hasattr(self, '_astar_path') and self._astar_path is not None:
            path_points = self._astar_path
            path_segments = path_points[:, 1:, :] - path_points[:, :-1, :]
            path_lengths = torch.norm(path_segments, dim=2)
            self._path_length_total = torch.sum(path_lengths, dim=1)
            
            box_to_path = box_pos[:, None, :2] - path_points
            min_dist_idx = torch.argmin(torch.norm(box_to_path, dim=2), dim=1)
            segment_progress = torch.zeros(self.num_envs, device=self.device)
            for env_idx in range(self.num_envs):
                idx = min_dist_idx[env_idx].item()
                if idx > 0:
                    segment_progress[env_idx] = torch.sum(path_lengths[env_idx, :idx])
                if idx < path_points.shape[1] - 1:
                    seg_start = path_points[env_idx, idx, :]
                    seg_end = path_points[env_idx, idx + 1, :]
                    seg_vec = seg_end - seg_start
                    box_proj = box_pos[env_idx, :2] - seg_start
                    seg_len = torch.norm(seg_vec)
                    if seg_len > 1e-6:
                        proj_frac = torch.clamp(torch.dot(box_proj, seg_vec) / (seg_len * seg_len), 0, 1)
                        segment_progress[env_idx] += proj_frac * path_lengths[env_idx, idx].item()
            self._path_length_traversed = segment_progress

        geodesic_penalty = -(self._path_length_total - self._path_length_traversed)

        delta_d_traj = torch.norm(box_pos[:, :2] - self._prev_box_pos[:, :2], dim=1)
        if hasattr(self, '_astar_path') and self._astar_path is not None:
            path_dir = self._astar_path[:, -1, :] - self._astar_path[:, 0, :]
            path_dir_norm = torch.norm(path_dir, dim=1, keepdim=True) + 1e-8
            path_dir_unit = path_dir / path_dir_norm
            box_movement = box_pos[:, :2] - self._prev_box_pos[:, :2]
            box_movement_norm = torch.norm(box_movement, dim=1, keepdim=True) + 1e-8
            box_movement_unit = box_movement / box_movement_norm
            signed_progress = torch.sum(box_movement_unit * path_dir_unit, dim=1) * box_movement_norm.squeeze(1)
            delta_d_traj = signed_progress
        self._prev_box_pos = box_pos.clone()

        drop_penalty = torch.zeros(self.num_envs, device=self.device)
        if hasattr(self, 'contact_sensors'):
            for robot_id in ["robot_0", "robot_1"]:
                if robot_id in self.contact_sensors:
                    contact_forces = self.contact_sensors[robot_id].data.net_forces_w
                    try:
                        left_idx, _ = self.robots[robot_id].find_bodies("left_rubber_hand")
                        right_idx, _ = self.robots[robot_id].find_bodies("right_rubber_hand")
                        left_contact = torch.norm(contact_forces[:, left_idx[0], :], dim=-1) < 0.1 if len(left_idx) > 0 else torch.ones(self.num_envs, device=self.device, dtype=torch.bool)
                        right_contact = torch.norm(contact_forces[:, right_idx[0], :], dim=-1) < 0.1 if len(right_idx) > 0 else torch.ones(self.num_envs, device=self.device, dtype=torch.bool)
                        drop_penalty += (left_contact & right_contact).float()
                    except:
                        pass

        alpha = 0.5
        beta = 2.0
        gamma = 2.0
        delta = 10.0

        R_t = -alpha * geodesic_penalty + beta * delta_d_traj - gamma * tilt_penalty - delta * drop_penalty

        if hasattr(self, '_fixed_long_goals'):
            long_goals = self._fixed_long_goals
            goal_distance = torch.norm(box_pos[:, :2] - long_goals[:, :2], dim=1)
            success_bonus = torch.where(goal_distance < 0.3, 10.0, 0.0)
            R_t = R_t + success_bonus

        for robot_id in self.robots.keys():
            reward[robot_id] = R_t

        return reward



    def _compute_leg_box_contact_penalty(self, robot_id: str) -> torch.Tensor:
        leg_body_names = [
"left_knee_link", "right_knee_link",
"left_ankle_pitch_link", "left_ankle_roll_link",
"right_ankle_pitch_link", "right_ankle_roll_link",
        ]
        
        contact_penalty = torch.zeros(self.num_envs, device=self.device)
        
        if hasattr(self, 'contact_sensors') and robot_id in self.contact_sensors:
            contact_forces = self.contact_sensors[robot_id].data.net_forces_w
            
            for leg_body in leg_body_names:
                try:
                    body_indices, _ = self.robots[robot_id].find_bodies(leg_body)
                    if len(body_indices) > 0:
                        leg_contact_force = torch.norm(contact_forces[:, body_indices[0], :], dim=-1)
                        contact_penalty += torch.where(leg_contact_force > 0.1, 1.0, 0.0)
                except:
pass
        
        return contact_penalty

    def _compute_robot_box_distance_penalty(self, robot_id: str) -> torch.Tensor:
        distance_penalty = torch.zeros(self.num_envs, device=self.device)
        
        robot_pos = self.robots[robot_id].data.root_state_w[:, :3]
        
        box_pos = self.object.data.root_state_w[:, :3]
        
        distance_xy = torch.norm(robot_pos[:, :2] - box_pos[:, :2], dim=1)
        
        is_contacting_box = torch.zeros(self.num_envs, device=self.device, dtype=torch.bool)
        
        if hasattr(self, 'contact_sensors') and robot_id in self.contact_sensors:
            contact_forces = self.contact_sensors[robot_id].data.net_forces_w
            
            contact_body_names = [
"left_rubber_hand", "right_rubber_hand",
"left_knee_link", "right_knee_link",
"left_ankle_pitch_link", "left_ankle_roll_link",
                "right_ankle_pitch_link", "right_ankle_roll_link"
            ]
            
            for body_name in contact_body_names:
                try:
                    body_indices, _ = self.robots[robot_id].find_bodies(body_name)
                    if len(body_indices) > 0:
                        contact_force = torch.norm(contact_forces[:, body_indices[0], :], dim=-1)
                        is_contacting_box |= (contact_force > 0.1)
                except:
                    pass
        
        position_multiplier = torch.ones(self.num_envs, device=self.device)
        
        if hasattr(self, '_current_short_goals'):
            short_goals = self._current_short_goals[:, :2]
            
            direction_to_goal = short_goals - box_pos[:, :2]
            direction_norm = torch.norm(direction_to_goal, dim=1, keepdim=True)
            direction_unit = direction_to_goal / (direction_norm + 1e-8)
            
backend_offset = -0.2
            backend_point = box_pos[:, :2] + backend_offset * direction_unit
            
            robot_to_backend = robot_pos[:, :2] - backend_point
            projection = torch.sum(robot_to_backend * direction_unit, dim=1)
            
            is_behind_box = projection > 0.0
            
            position_multiplier = torch.where(is_behind_box, 3.0, 1.0)
            

        
        distance_penalty = torch.where(
            is_contacting_box, 
0.0,
distance_xy * position_multiplier
        )
        
        return distance_penalty


    def _get_dones(self) -> tuple[dict, dict]:
        time_out = self.episode_length_buf >= self._max_episode_length
        
        robot_0_com_height = self.robots["robot_0"].data.root_state_w[:, 2]
        robot_1_com_height = self.robots["robot_1"].data.root_state_w[:, 2]
        
        term_height = getattr(self.cfg, 'termination_height', 0.25)
        g1_0_died = robot_0_com_height < term_height
        g1_1_died = robot_1_com_height < term_height
        
        g1_died = torch.logical_or(g1_0_died, g1_1_died)
        too_far = self._get_too_far_away()
        
        angle_aligned = torch.ones(self.num_envs, device=self.device, dtype=torch.bool)
        robot_0_pos = None
        robot_1_pos = None
        if hasattr(self, '_target_angles'):
            target_angles = self._target_angles
            robot_0_pos = self.robots["robot_0"].data.root_state_w[:, :2]
            robot_1_pos = self.robots["robot_1"].data.root_state_w[:, :2]
            robot_diff = robot_1_pos - robot_0_pos
            current_angles = torch.atan2(robot_diff[:, 1], robot_diff[:, 0])
            angle_diff = torch.abs(current_angles - target_angles)
            angle_diff = torch.remainder(angle_diff + torch.pi, 2 * torch.pi) - torch.pi
            angle_aligned = torch.abs(angle_diff) < (30.0 * torch.pi / 180.0)
        
        goal_reached = torch.ones(self.num_envs, device=self.device, dtype=torch.bool)
        if hasattr(self, '_fixed_long_goals') and robot_0_pos is not None and robot_1_pos is not None:
            long_goals = self._fixed_long_goals
            board_center = 0.5 * (robot_0_pos + robot_1_pos)
            goal_distance = torch.norm(board_center - long_goals[:, :2], dim=1)
goal_reached = goal_distance < 0.3
        
        min_steps_required = 600
        steps_requirement = self.episode_length_buf >= min_steps_required
        task_success = angle_aligned & goal_reached & steps_requirement
        
        dones = torch.logical_or(g1_died, too_far)

        
        dones_or_timeouts = dones | time_out
        
        self.extras["log"] = dict()
        
        if torch.any(dones_or_timeouts):
            total_episode_reward = torch.zeros(self.num_envs, device=self.device)
            
            for key, value in self._episode_sums.items():
                finished_env_rewards = value[dones_or_timeouts]
                if len(finished_env_rewards) > 0:
                    self.extras["log"][key] = finished_env_rewards.mean().item()
                else:
                    self.extras["log"][key] = 0.0
                
                total_episode_reward += value
                self._episode_sums[key][dones_or_timeouts] = 0.0
            
            finished_total_rewards = total_episode_reward[dones_or_timeouts]
            if len(finished_total_rewards) > 0:
                self.extras["log"]["total_reward"] = finished_total_rewards.mean().item()
            else:
                self.extras["log"]["total_reward"] = 0.0
            
            finished_task_success = task_success[dones_or_timeouts]
            if len(finished_task_success) > 0:
                self.extras["log"]["successes"] = finished_task_success.float().mean().item()
            else:
                self.extras["log"]["successes"] = 0.0
                
            ep_return = self.extras["log"].get("total_reward", None)
            if ep_return is not None:
                num_finished = torch.sum(dones_or_timeouts).item()
                finished_env_indices = torch.where(dones_or_timeouts)[0]
                if len(finished_env_indices) > 0:
                    avg_episode_length = self.episode_length_buf[finished_env_indices].float().mean().item()
                    print(f"[Episode End] [{num_finished} Envs] [Avg Step {avg_episode_length:.0f}] Total Episode Return: {ep_return:.4f}")
                    
                    print(f"  Main Rewards (Avg of {num_finished} finished envs):")
                    main_rewards = ["track_lin_vel_xy_exp", "track_ang_vel_z_exp", "robot_0_hand_box_contact_reward", "robot_1_hand_box_contact_reward"]
                    for reward_name in main_rewards:
                        if reward_name in self.extras["log"]:
                            print(f"    {reward_name}: {self.extras['log'][reward_name]:.4f}")
                    print("  " + "-"*50)

        return {key: dones for key in self.robots.keys()}, {key: time_out for key in self.robots.keys()}



    def _get_too_far_away(self):
        g1_0_pos = self.robots["robot_0"].data.body_com_pos_w[:, 0, :]
        g1_1_pos = self.robots["robot_1"].data.body_com_pos_w[:, 0, :]

        box_pos = self.object.data.body_com_pos_w[:, 0, :]

        g1_0_too_far = (
torch.sqrt(torch.square(g1_0_pos[:, 0] - box_pos[:, 0]) + torch.square(g1_0_pos[:, 1] - box_pos[:, 1])) > 1.5
        )
        g1_1_too_far = (
            torch.sqrt(torch.square(g1_1_pos[:, 0] - box_pos[:, 0]) + torch.square(g1_1_pos[:, 1] - box_pos[:, 1])) > 1.5
        )

        box_length, box_width, box_height = 0.22, 2.0, 0.05
        local_vertices = torch.tensor([
[box_length/2, box_width/2, box_height/2],
[box_length/2, -box_width/2, box_height/2],
[-box_length/2, -box_width/2, box_height/2],
[-box_length/2, box_width/2, box_height/2],
        ], device=self.device, dtype=torch.float32)
        
        box_quat = self.object.data.root_com_quat_w
        w, x, y, z = box_quat[:, 0], box_quat[:, 1], box_quat[:, 2], box_quat[:, 3]
        rotation_matrix = torch.stack([
            torch.stack([1-2*y*y-2*z*z, 2*x*y-2*w*z, 2*x*z+2*w*y], dim=1),
            torch.stack([2*x*y+2*w*z, 1-2*x*x-2*z*z, 2*y*z-2*w*x], dim=1),
            torch.stack([2*x*z-2*w*y, 2*y*z+2*w*x, 1-2*x*x-2*y*y], dim=1)
        ], dim=1)
        
        world_vertices_z = []
        for i in range(4):
            rotated_vertex = torch.bmm(rotation_matrix, local_vertices[i].unsqueeze(1).expand(self.num_envs, 3, 1)).squeeze(-1)
            world_vertex = rotated_vertex + box_pos
            world_vertices_z.append(world_vertex[:, 2])
        
        vertices_z = torch.stack(world_vertices_z, dim=1)
        box_landed = torch.any(vertices_z < 0.2, dim=1)

        return torch.logical_or(torch.logical_or(g1_0_too_far, g1_1_too_far), box_landed)

    def _compute_box_vertex_z_variance(self) -> torch.Tensor:
        box_pos = self.object.data.root_com_pos_w
        box_quat = self.object.data.root_com_quat_w
        
        box_length, box_width, box_height = 0.22, 2.0, 0.05
        
        local_vertices = torch.tensor([
[box_length/2, box_width/2, box_height/2],
[box_length/2, -box_width/2, box_height/2],
[-box_length/2, -box_width/2, box_height/2],
[-box_length/2, box_width/2, box_height/2],
        ], device=self.device, dtype=torch.float32)
        
        w, x, y, z = box_quat[:, 0], box_quat[:, 1], box_quat[:, 2], box_quat[:, 3]
        rotation_matrix = torch.stack([
            torch.stack([1-2*y*y-2*z*z, 2*x*y-2*w*z, 2*x*z+2*w*y], dim=1),
            torch.stack([2*x*y+2*w*z, 1-2*x*x-2*z*z, 2*y*z-2*w*x], dim=1),
            torch.stack([2*x*z-2*w*y, 2*y*z+2*w*x, 1-2*x*x-2*y*y], dim=1)
        ], dim=1)
        
        world_vertices_z = []
        for i in range(4):
            rotated_vertex = torch.bmm(rotation_matrix, local_vertices[i].unsqueeze(1).expand(self.num_envs, 3, 1)).squeeze(-1)
            world_vertex = rotated_vertex + box_pos
            world_vertices_z.append(world_vertex[:, 2])
        
        vertices_z = torch.stack(world_vertices_z, dim=1)
        z_variance = torch.var(vertices_z, dim=1)
        
        return z_variance

    def _compute_box_goal_alignment_reward(self) -> torch.Tensor:
        box_pos = self.object.data.root_com_pos_w
        
        if hasattr(self, '_fixed_long_goals'):
            long_goal = self._fixed_long_goals
        else:
            return torch.zeros(self.num_envs, device=self.device)
        
        distance = torch.norm(box_pos - long_goal, dim=1)
        
alignment_reward = torch.exp(-distance / 0.2)
        
        return alignment_reward

    def _compute_box_vertices_height_reward(self) -> torch.Tensor:
        box_pos = self.object.data.root_com_pos_w
        box_quat = self.object.data.root_com_quat_w
        
        box_length, box_width, box_height = 0.22, 2.0, 0.05
        
        local_vertices = torch.tensor([
[box_length/2, box_width/2, box_height/2],
[box_length/2, -box_width/2, box_height/2],
[-box_length/2, -box_width/2, box_height/2],
[-box_length/2, box_width/2, box_height/2],
        ], device=self.device, dtype=torch.float32)
        
        w, x, y, z = box_quat[:, 0], box_quat[:, 1], box_quat[:, 2], box_quat[:, 3]
        rotation_matrix = torch.stack([
            torch.stack([1-2*y*y-2*z*z, 2*x*y-2*w*z, 2*x*z+2*w*y], dim=1),
            torch.stack([2*x*y+2*w*z, 1-2*x*x-2*z*z, 2*y*z-2*w*x], dim=1),
            torch.stack([2*x*z-2*w*y, 2*y*z+2*w*x, 1-2*x*x-2*y*y], dim=1)
        ], dim=1)
        
        world_vertices_z = []
        for i in range(4):
            rotated_vertex = torch.bmm(rotation_matrix, local_vertices[i].unsqueeze(1).expand(self.num_envs, 3, 1)).squeeze(-1)
            world_vertex = rotated_vertex + box_pos
            world_vertices_z.append(world_vertex[:, 2])
        
        vertices_z = torch.stack(world_vertices_z, dim=1)
        
        target_height = 0.9
        
        height_penalties = torch.zeros_like(vertices_z)
        
        below_target = vertices_z < target_height
        height_penalties = torch.where(below_target, (target_height - vertices_z) ** 2, 0.0)
        
        total_penalty = torch.sum(height_penalties, dim=1)
        
        return total_penalty

    def _get_curriculum_scale(self) -> float:
        curriculum_enabled = getattr(self.cfg, 'curriculum_enabled', False)
        if not curriculum_enabled:
            return 1.0
        
        current_steps = self.halpo_control_step
        start_steps = getattr(self.cfg, 'curriculum_start_steps', 0.0)
        end_steps = getattr(self.cfg, 'curriculum_end_steps', 1.0)
        start_scale = getattr(self.cfg, 'curriculum_start_scale', 1.0)
        end_scale = getattr(self.cfg, 'curriculum_end_scale', 1.0)
        
        if current_steps < start_steps:
            return start_scale
        
        if current_steps >= end_steps:
            return end_scale
        
        progress = (current_steps - start_steps) / max(1e-8, (end_steps - start_steps))
        current_scale = start_scale + progress * (end_scale - start_scale)
        
        return current_scale

    def _compute_box_ground_contact_penalty(self) -> torch.Tensor:
        box_pos = self.object.data.root_com_pos_w
        box_quat = self.object.data.root_com_quat_w
        
        box_length, box_width, box_height = 0.22, 2.0, 0.05
        
        local_vertices = torch.tensor([
[box_length/2, box_width/2, box_height/2],
[box_length/2, -box_width/2, box_height/2],
[-box_length/2, -box_width/2, box_height/2],
[-box_length/2, box_width/2, box_height/2],
        ], device=self.device, dtype=torch.float32)
        
        w, x, y, z = box_quat[:, 0], box_quat[:, 1], box_quat[:, 2], box_quat[:, 3]
        rotation_matrix = torch.stack([
            torch.stack([1-2*y*y-2*z*z, 2*x*y-2*w*z, 2*x*z+2*w*y], dim=1),
            torch.stack([2*x*y+2*w*z, 1-2*x*x-2*z*z, 2*y*z-2*w*x], dim=1),
            torch.stack([2*x*z-2*w*y, 2*y*z+2*w*x, 1-2*x*x-2*y*y], dim=1)
        ], dim=1)
        
        world_vertices_z = []
        for i in range(4):
            rotated_vertex = torch.bmm(rotation_matrix, local_vertices[i].unsqueeze(1).expand(self.num_envs, 3, 1)).squeeze(-1)
            world_vertex = rotated_vertex + box_pos
            world_vertices_z.append(world_vertex[:, 2])
        
        vertices_z = torch.stack(world_vertices_z, dim=1)
        
        any_vertex_low = torch.any(vertices_z < 0.3, dim=1)
        
        return torch.where(any_vertex_low, 1.0, 0.0)

    def _compute_robot_box_center_proximity_reward(self, robot_id: str) -> torch.Tensor:
        robot_pos = self.robots[robot_id].data.root_state_w[:, :2]
        
        box_pos = self.object.data.root_com_pos_w
        box_quat = self.object.data.root_com_quat_w
        
        box_length, box_width, box_height = 0.22, 2.0, 0.05
        
local_midpoint_1 = torch.tensor([box_length/2, 0.0, box_height/2], device=self.device, dtype=torch.float32)
local_midpoint_2 = torch.tensor([-box_length/2, 0.0, box_height/2], device=self.device, dtype=torch.float32)
        
        w, x, y, z = box_quat[:, 0], box_quat[:, 1], box_quat[:, 2], box_quat[:, 3]
        rotation_matrix = torch.stack([
            torch.stack([1-2*y*y-2*z*z, 2*x*y-2*w*z, 2*x*z+2*w*y], dim=1),
            torch.stack([2*x*y+2*w*z, 1-2*x*x-2*z*z, 2*y*z-2*w*x], dim=1),
            torch.stack([2*x*z-2*w*y, 2*y*z+2*w*x, 1-2*x*x-2*y*y], dim=1)
        ], dim=1)
        
        world_midpoints = []
        for local_midpoint in [local_midpoint_1, local_midpoint_2]:
            rotated_midpoint = torch.bmm(rotation_matrix, local_midpoint.unsqueeze(1).expand(self.num_envs, 3, 1)).squeeze(-1)
            world_midpoint = rotated_midpoint + box_pos
world_midpoints.append(world_midpoint[:, :2])
        
        distances = []
        for world_midpoint in world_midpoints:
            distance = torch.norm(robot_pos - world_midpoint, dim=1)
            distances.append(distance)
        
        proximity_rewards = []
        for distance in distances:
            proximity_reward = 1.0 / (distance * distance + 1e-6)
            proximity_rewards.append(proximity_reward)
        
        return torch.stack(proximity_rewards, dim=1).mean(dim=1)

    def _compute_height_control(self, env_idx, robot_id):
        box_pos = self.object.data.root_com_pos_w[env_idx]
        box_quat = self.object.data.root_com_quat_w[env_idx]
        
        stick_length = 2.0
        
        local_vertex1 = torch.tensor([stick_length/2, 0, 0], device=self.device, dtype=torch.float32)
        local_vertex2 = torch.tensor([-stick_length/2, 0, 0], device=self.device, dtype=torch.float32)
        
        w, x, y, z = box_quat[0], box_quat[1], box_quat[2], box_quat[3]
        rot_matrix = torch.tensor([
            [1 - 2*y*y - 2*z*z, 2*x*y - 2*w*z, 2*x*z + 2*w*y],
            [2*x*y + 2*w*z, 1 - 2*x*x - 2*z*z, 2*y*z - 2*w*x],
            [2*x*z - 2*w*y, 2*y*z + 2*w*x, 1 - 2*x*x - 2*y*y]
        ], device=self.device, dtype=torch.float32)
        
        world_vertex1 = torch.matmul(rot_matrix, local_vertex1) + box_pos
        world_vertex2 = torch.matmul(rot_matrix, local_vertex2) + box_pos
        
        vertex1_height = world_vertex1[2]
        vertex2_height = world_vertex2[2]
        
        target_height = 0.9
        
        current_height = torch.minimum(vertex1_height, vertex2_height)
        height_error = target_height - current_height
        
        height_control = 0.5 * height_error
        
        return torch.tensor([0.0, height_control.item() * 0.1, 0.0], device=self.device)






@torch.jit.script
def compute_intermediate_values(
    targets: torch.Tensor,
    torso_position: torch.Tensor,
    torso_rotation: torch.Tensor,
    velocity: torch.Tensor,
    ang_velocity: torch.Tensor,
    dof_pos: torch.Tensor,
    dof_lower_limits: torch.Tensor,
    dof_upper_limits: torch.Tensor,
    inv_start_rot: torch.Tensor,
    basis_vec0: torch.Tensor,
    basis_vec1: torch.Tensor,
    potentials: torch.Tensor,
    prev_potentials: torch.Tensor,
    dt: float,
):
    to_target = targets - torso_position
    to_target[:, 2] = 0.0
    torso_quat, up_proj, heading_proj, up_vec, heading_vec = compute_heading_and_up(
        torso_rotation, inv_start_rot, to_target, basis_vec0, basis_vec1, 2
    )

    vel_loc, angvel_loc, roll, pitch, yaw, angle_to_target = compute_rot(
        torso_quat, velocity, ang_velocity, targets, torso_position
    )

    dof_pos_scaled = torch_utils.maths.unscale(dof_pos, dof_lower_limits, dof_upper_limits)

    to_target = targets - torso_position
    to_target[:, 2] = 0.0
    prev_potentials[:] = potentials
    potentials = -torch.norm(to_target, p=2, dim=-1) / dt

    return (
        up_proj,
        heading_proj,
        up_vec,
        heading_vec,
        vel_loc,
        angvel_loc,
        roll,
        pitch,
        yaw,
        angle_to_target,
        dof_pos_scaled,
        prev_potentials,
        potentials,
    )

