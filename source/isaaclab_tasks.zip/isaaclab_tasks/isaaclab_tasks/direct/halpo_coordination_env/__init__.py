import gymnasium as gym

from .halpo_coordination_env_sample_1 import (
    HalpoCoordination,
    HalpoCoordinationEnvCfg,
)

gym.register(
    id="Isaac-Halpo-Coordination-Direct-v0",
    entry_point="isaaclab_tasks.direct.halpo_coordination_env:HalpoCoordination",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": HalpoCoordinationEnvCfg,
        "halpo_cfg_entry_point": "isaaclab_tasks.direct.halpo_coordination_env.agents:halpo_cfg.yaml",
    },
)
