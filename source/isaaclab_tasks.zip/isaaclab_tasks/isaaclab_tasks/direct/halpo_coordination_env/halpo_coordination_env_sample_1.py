from __future__ import annotations

import copy
import torch
import numpy as np
import sys
import math
import os

_extra_paths = os.environ.get("WBC_INTEGRATION_PATHS", "")
for _p in [p for p in _extra_paths.split(os.pathsep) if p]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

try:
    from proper_wbc_controller import ProperWbcController
except Exception:
    ProperWbcController = None

import isaacsim.core.utils.torch as torch_utils
from isaacsim.core.utils.torch.rotations import compute_heading_and_up, compute_rot, quat_conjugate

import isaaclab.envs.mdp as mdp
import isaaclab.sim as sim_utils
from isaaclab.assets import Articulation, ArticulationCfg, RigidObject, RigidObjectCfg
from isaaclab.envs import DirectMARLEnv, DirectMARLEnvCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.markers import VisualizationMarkers, VisualizationMarkersCfg
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.sensors import ContactSensor, ContactSensorCfg, RayCasterCfg, patterns
from isaaclab.sim import SimulationCfg
from isaaclab.terrains import TerrainImporterCfg
from isaaclab.utils import configclass
from isaaclab.utils.assets import ISAAC_NUCLEUS_DIR
from isaaclab.utils.math import quat_from_angle_axis
import collections
from collections import deque
from copy import deepcopy
from typing import Optional, Dict, Any

from isaaclab_assets.robots.anymal import ANYMAL_C_CFG
from isaaclab_assets.robots.g1_29dof import G1_29DOF_CFG
from isaaclab.terrains.config.rough import ROUGH_TERRAINS_CFG

from isaaclab_tasks.utils.custom_trajectory import get_short_term_goal
from .lead_follow_controller import LeadFollowController



def normalize_angle(x):
    return torch.atan2(torch.sin(x), torch.cos(x))

def quat_to_euler_angles_torch(q: torch.Tensor) -> torch.Tensor:
    w, x, y, z = q[..., 0], q[..., 1], q[..., 2], q[..., 3]
    t0 = +2.0 * (w * x + y * z)
    t1 = +1.0 - 2.0 * (x * x + y * y)
    roll = torch.atan2(t0, t1)
    t2 = +2.0 * (w * y - z * x)
    t2 = torch.clamp(t2, -1.0, 1.0)
    pitch = torch.asin(t2)
    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (y * y + z * z)
    yaw = torch.atan2(t3, t4)
    return torch.stack((roll, pitch, yaw), dim=-1)


                           
def randomize_rigid_body_material_0(env, env_ids, asset_cfg, static_friction_range, dynamic_friction_range, restitution_range, num_buckets):
    return mdp.randomize_rigid_body_material(
        EventTerm(
            params={
                "asset_cfg": asset_cfg,
                "static_friction_range": static_friction_range,
                "dynamic_friction_range": dynamic_friction_range,
                "restitution_range": restitution_range,
                "num_buckets": num_buckets,
            }
        ),
        env,
    ).__call__(env, env_ids, asset_cfg=asset_cfg, static_friction_range=static_friction_range, dynamic_friction_range=dynamic_friction_range, restitution_range=restitution_range, num_buckets=num_buckets)

def randomize_rigid_body_material_1(env, env_ids, asset_cfg, static_friction_range, dynamic_friction_range, restitution_range, num_buckets):
    return mdp.randomize_rigid_body_material(
        EventTerm(
            params={
                "asset_cfg": asset_cfg,
                "static_friction_range": static_friction_range,
                "dynamic_friction_range": dynamic_friction_range,
                "restitution_range": restitution_range,
                "num_buckets": num_buckets,
            }
        ),
        env,
    ).__call__(env, env_ids, asset_cfg=asset_cfg, static_friction_range=static_friction_range, dynamic_friction_range=dynamic_friction_range, restitution_range=restitution_range, num_buckets=num_buckets)


@configclass
class EventCfg:


    physics_material_0 = EventTerm(
        func=randomize_rigid_body_material_0,
        mode="startup",
        params={
            "asset_cfg": SceneEntityCfg("robot_0", body_names=".*"),
            "static_friction_range": (0.8, 0.8),
            "dynamic_friction_range": (0.6, 0.6),
            "restitution_range": (0.0, 0.0),
            "num_buckets": 64,
        },
    )

    physics_material_1 = EventTerm(
        func=randomize_rigid_body_material_1,
        mode="startup",
        params={
            "asset_cfg": SceneEntityCfg("robot_1", body_names=".*"),
            "static_friction_range": (0.8, 0.8),
            "dynamic_friction_range": (0.6, 0.6),
            "restitution_range": (0.0, 0.0),
            "num_buckets": 64,
        },
    )

    add_base_mass_0 = EventTerm(
        func=mdp.randomize_rigid_body_mass,
        mode="startup",
        params={
            "asset_cfg": SceneEntityCfg("robot_0", body_names="pelvis"),
            "mass_distribution_params": (0.0, 5.0),
            "operation": "add",
        },
    )

    add_base_mass_1 = EventTerm(
        func=mdp.randomize_rigid_body_mass,
        mode="startup",
        params={
            "asset_cfg": SceneEntityCfg("robot_1", body_names="torso_link"),
            "mass_distribution_params": (0.0, 5.0),
            "operation": "add",
        },
    )


@configclass
class HeterogeneousPushMultiAgentFlatEnvCfg(DirectMARLEnvCfg):
         
    episode_length_s = 5000.0
    decimation = 4
                               
    action_space = 11
    action_spaces = {"robot_0": 11, "robot_1": 11}

    observation_spaces = {"robot_0": 210, "robot_1": 210}
    state_space = 210
    state_spaces = {f"robot_{i}": 210 for i in range(2)}
    possible_agents = ["robot_0", "robot_1"]

                
    sim: SimulationCfg = SimulationCfg(
        dt=1 / 200,
        render_interval=decimation,
        physics_material=sim_utils.RigidBodyMaterialCfg(
            friction_combine_mode="multiply",
            restitution_combine_mode="multiply",
            static_friction=1.0,
            dynamic_friction=1.0,
            restitution=0.0,
        ),
    )
    terrain = TerrainImporterCfg(
        prim_path="/World/ground",
        terrain_type="plane",
        collision_group=-1,
        physics_material=sim_utils.RigidBodyMaterialCfg(
            friction_combine_mode="multiply",
            restitution_combine_mode="multiply",
            static_friction=1.0,
            dynamic_friction=1.0,
            restitution=0.0,
        ),
        debug_vis=False,
    )

           
    scene: InteractiveSceneCfg = InteractiveSceneCfg(num_envs=256, env_spacing=9.0, replicate_physics=True)

            
    events: EventCfg = EventCfg()

           
    robot_0: ArticulationCfg = deepcopy(G1_29DOF_CFG)
    robot_0.prim_path = "/World/envs/env_.*/Robot_0"
    contact_sensor_0: ContactSensorCfg = ContactSensorCfg(
        prim_path="/World/envs/env_.*/Robot_0/.*", history_length=3, update_period=0.005, track_air_time=True
    )
    robot_0.init_state.rot = (1, 0.0, 0.0, 0)                                  
    robot_0.init_state.pos = (0.0, 0.5, 0.795)                  

    robot_1: ArticulationCfg = deepcopy(G1_29DOF_CFG)
    robot_1.prim_path = "/World/envs/env_.*/Robot_1"
    robot_1.init_state.rot = (1, 0.0, 0.0, 0)                  
    robot_1.init_state.pos = (0.0, -0.5, 0.795)                 

               
                  
    circle_radius = 5.0
    robot_pos = (0.0, 1.0, 1.0)
    circle_center = (robot_pos[0], robot_pos[1] + 3.0, robot_pos[2])
    box_init_pos = (circle_center[0], circle_center[1] + circle_radius, 0.6)
                  
    cfg_rec_prism = RigidObjectCfg(
        prim_path="/World/envs/env_.*/Object",
        spawn=sim_utils.CuboidCfg(
                                                   
            size=(0.22, 2.0, 0.05),              
            rigid_props=sim_utils.RigidBodyPropertiesCfg(),
            mass_props=sim_utils.MassPropertiesCfg(mass=2.0),         
            collision_props=sim_utils.CollisionPropertiesCfg(),
        physics_material=sim_utils.RigidBodyMaterialCfg(
            friction_combine_mode="multiply",
            restitution_combine_mode="multiply",
            static_friction=1.5,            
            dynamic_friction=1.2,              
            restitution=0.0,
        ),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.6, 0.4, 0.2)),      
        ),
        init_state=RigidObjectCfg.InitialStateCfg(pos=(0.15, -0.03, 0.92), rot=(1.0, 0.0, 0.0, 0.0)),
    )                      

                          
                                         
    wall_1: RigidObjectCfg = RigidObjectCfg(
        prim_path="/World/envs/env_.*/Wall_1",
        spawn=sim_utils.CuboidCfg(
            size=(3.0, 0.2, 0.8),                                
            rigid_props=sim_utils.RigidBodyPropertiesCfg(kinematic_enabled=True),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.0),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            physics_material=sim_utils.RigidBodyMaterialCfg(
                friction_combine_mode="multiply",
                restitution_combine_mode="multiply",
                static_friction=1.0,
                dynamic_friction=1.0,
                restitution=0.0,
            ),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.5, 0.5, 0.5)),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(
            pos=(-0.5, 1.5, 0.4),                            
            rot=(1.0, 0.0, 0.0, 0.0)
        ),
    )
    
                                           
    wall_2: RigidObjectCfg = RigidObjectCfg(
        prim_path="/World/envs/env_.*/Wall_2",
        spawn=sim_utils.CuboidCfg(
            size=(0.2, 5.0, 0.8),                                
            rigid_props=sim_utils.RigidBodyPropertiesCfg(kinematic_enabled=True),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.0),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            physics_material=sim_utils.RigidBodyMaterialCfg(
                friction_combine_mode="multiply",
                restitution_combine_mode="multiply",
                static_friction=1.0,
                dynamic_friction=1.0,
                restitution=0.0,
            ),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.5, 0.5, 0.5)),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(
            pos=(-2.0, -1.0, 0.4),                              
            rot=(1.0, 0.0, 0.0, 0.0)
        ),
    )
    
                                          
    wall_3: RigidObjectCfg = RigidObjectCfg(
        prim_path="/World/envs/env_.*/Wall_3",
        spawn=sim_utils.CuboidCfg(
            size=(0.2, 1.5, 0.8),                                  
            rigid_props=sim_utils.RigidBodyPropertiesCfg(kinematic_enabled=True),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.0),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            physics_material=sim_utils.RigidBodyMaterialCfg(
                friction_combine_mode="multiply",
                restitution_combine_mode="multiply",
                static_friction=1.0,
                dynamic_friction=1.0,
                restitution=0.0,
            ),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.5, 0.5, 0.5)),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(
            pos=(1.0, -2.75, 0.4),                            
            rot=(1.0, 0.0, 0.0, 0.0)
        ),
    )
    
                                              
    wall_11: RigidObjectCfg = RigidObjectCfg(
        prim_path="/World/envs/env_.*/Wall_11",
        spawn=sim_utils.CuboidCfg(
            size=(3.5, 0.2, 0.8),                                  
            rigid_props=sim_utils.RigidBodyPropertiesCfg(kinematic_enabled=True),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.0),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            physics_material=sim_utils.RigidBodyMaterialCfg(
                friction_combine_mode="multiply",
                restitution_combine_mode="multiply",
                static_friction=1.0,
                dynamic_friction=1.0,
                restitution=0.0,
            ),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.5, 0.5, 0.5)),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(
            pos=(-0.5, -3.5, 0.4),                                                
            rot=(1.0, 0.0, 0.0, 0.0)
        ),
    )
    
                                      
    wall_4: RigidObjectCfg = RigidObjectCfg(
        prim_path="/World/envs/env_.*/Wall_4",
        spawn=sim_utils.CuboidCfg(
            size=(3.0, 0.2, 0.8),
            rigid_props=sim_utils.RigidBodyPropertiesCfg(kinematic_enabled=True),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.0),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            physics_material=sim_utils.RigidBodyMaterialCfg(
                friction_combine_mode="multiply",
                restitution_combine_mode="multiply",
                static_friction=1.0,
                dynamic_friction=1.0,
                restitution=0.0,
            ),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.5, 0.5, 0.5)),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(
            pos=(2.5, -2.0, 0.4),                          
            rot=(1.0, 0.0, 0.0, 0.0)
        ),
    )
    
                                          
    wall_5: RigidObjectCfg = RigidObjectCfg(
        prim_path="/World/envs/env_.*/Wall_5",
        spawn=sim_utils.CuboidCfg(
            size=(0.2, 1.5, 0.8),
            rigid_props=sim_utils.RigidBodyPropertiesCfg(kinematic_enabled=True),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.0),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            physics_material=sim_utils.RigidBodyMaterialCfg(
                friction_combine_mode="multiply",
                restitution_combine_mode="multiply",
                static_friction=1.0,
                dynamic_friction=1.0,
                restitution=0.0,
            ),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.5, 0.5, 0.5)),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(
            pos=(4.0, -2.75, 0.4),                            
            rot=(1.0, 0.0, 0.0, 0.0)
        ),
    )
    
                                      
    wall_6: RigidObjectCfg = RigidObjectCfg(
        prim_path="/World/envs/env_.*/Wall_6",
        spawn=sim_utils.CuboidCfg(
            size=(5.0, 0.2, 0.8),
            rigid_props=sim_utils.RigidBodyPropertiesCfg(kinematic_enabled=True),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.0),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            physics_material=sim_utils.RigidBodyMaterialCfg(
                friction_combine_mode="multiply",
                restitution_combine_mode="multiply",
                static_friction=1.0,
                dynamic_friction=1.0,
                restitution=0.0,
            ),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.5, 0.5, 0.5)),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(
            pos=(3.5, -1.0, 0.4),                                             
            rot=(1.0, 0.0, 0.0, 0.0)
        ),
    )
    
                                          
    wall_10: RigidObjectCfg = RigidObjectCfg(
        prim_path="/World/envs/env_.*/Wall_10",
        spawn=sim_utils.CuboidCfg(
            size=(0.2, 2.5, 0.8),                                  
            rigid_props=sim_utils.RigidBodyPropertiesCfg(kinematic_enabled=True),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.0),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            physics_material=sim_utils.RigidBodyMaterialCfg(
                friction_combine_mode="multiply",
                restitution_combine_mode="multiply",
                static_friction=1.0,
                dynamic_friction=1.0,
                restitution=0.0,
            ),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.5, 0.5, 0.5)),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(
            pos=(1.0, 0.25, 0.4),                                             
            rot=(1.0, 0.0, 0.0, 0.0)
        ),
    )
    
                                           
    wall_12: RigidObjectCfg = RigidObjectCfg(
        prim_path="/World/envs/env_.*/Wall_12",
        spawn=sim_utils.CuboidCfg(
            size=(0.2, 2.5, 0.8),                                  
            rigid_props=sim_utils.RigidBodyPropertiesCfg(kinematic_enabled=True),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.0),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            physics_material=sim_utils.RigidBodyMaterialCfg(
                friction_combine_mode="multiply",
                restitution_combine_mode="multiply",
                static_friction=1.0,
                dynamic_friction=1.0,
                restitution=0.0,
            ),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.5, 0.5, 0.5)),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(
            pos=(6.0, -2.25, 0.4),                                              
            rot=(1.0, 0.0, 0.0, 0.0)
        ),
    )
    
                                             
    table: RigidObjectCfg = RigidObjectCfg(
        prim_path="/World/envs/env_.*/Table",
        spawn=sim_utils.CuboidCfg(
            size=(0.5, 0.5, 0.6),                                  
            rigid_props=sim_utils.RigidBodyPropertiesCfg(kinematic_enabled=True),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.0),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            physics_material=sim_utils.RigidBodyMaterialCfg(
                friction_combine_mode="multiply",
                restitution_combine_mode="multiply",
                static_friction=1.0,
                dynamic_friction=1.0,
                restitution=0.0,
            ),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.5, 0.5, 0.5)),            
        ),
        init_state=RigidObjectCfg.InitialStateCfg(
            pos=(5.0, -3.5, 0.3),                                        
            rot=(1.0, 0.0, 0.0, 0.0)
        ),
    )                              
    flat_orientation_reward_scale = 0.0                              
    formation_consistency_reward_scale = 2.0             
    height_maintenance_reward_scale = 1.0                
    goal_reaching_reward_scale = 0.0                    
    curriculum_enabled = False
    curriculum_start_scale = 0.5
    curriculum_end_scale = 1.0
    curriculum_start_steps = 2000000000/24
    curriculum_end_steps = 2000000000/24
    termination_height = 0.15
    angular_velocity_scale: float = 0.25
    dof_vel_scale: float = 0.1
    g1_action_scale = 1.0                                
    anymal_min_z_pos = 0.3
    g1_min_z_pos = 0.6                          
    wrist_roll_enable = True
    wrist_roll_left_target = -1.57079632679                        
    wrist_roll_right_target = 1.57079632679                                               
    shoulder_yaw_enable = True
    shoulder_yaw_left_target = 0.25                 
    shoulder_yaw_right_target = -0.25                
    shoulder_roll_enable = True
    shoulder_roll_left_target = 0.2                           
    shoulder_roll_right_target = -0.2                          
    joint_gears: list = [
                          
        50.0
        for _ in range(29)
    ]                  


@configclass
class HeterogeneousPushMultiAgentRoughEnvCfg(HeterogeneousPushMultiAgentFlatEnvCfg):
         
    observation_space = 235

    terrain = TerrainImporterCfg(
        prim_path="/World/ground",
        terrain_type="generator",
        terrain_generator=ROUGH_TERRAINS_CFG,
        max_init_terrain_level=9,
        collision_group=-1,
        physics_material=sim_utils.RigidBodyMaterialCfg(
            friction_combine_mode="multiply",
            restitution_combine_mode="multiply",
            static_friction=1.0,
            dynamic_friction=1.0,
        ),
        visual_material=sim_utils.MdlFileCfg(
            mdl_path="{NVIDIA_NUCLEUS_DIR}/Materials/Base/Architecture/Shingles_01.mdl",
            project_uvw=True,
        ),
        debug_vis=False,
    )

                                                       
    height_scanner_0 = RayCasterCfg(
        prim_path="/World/envs/env_.*/Robot_0/base",
        offset=RayCasterCfg.OffsetCfg(pos=(0.0, 0.0, 20.0)),
        attach_yaw_only=True,
        pattern_cfg=patterns.GridPatternCfg(resolution=0.1, size=(1.6, 1.0)),
        debug_vis=False,
        mesh_prim_paths=["/World/ground"],
    )

    height_scanner_1 = RayCasterCfg(
        prim_path="/World/envs/env_.*/Robot_1/base",
        offset=RayCasterCfg.OffsetCfg(pos=(0.0, 0.0, 20.0)),
        attach_yaw_only=True,
        pattern_cfg=patterns.GridPatternCfg(resolution=0.1, size=(1.6, 1.0)),
        debug_vis=False,
        mesh_prim_paths=["/World/ground"],
    )

    height_scanner_2 = RayCasterCfg(
        prim_path="/World/envs/env_.*/Robot_2/pelvis",
        offset=RayCasterCfg.OffsetCfg(pos=(0.0, 0.0, 20.0)),
        attach_yaw_only=True,
        pattern_cfg=patterns.GridPatternCfg(resolution=0.1, size=(1.6, 1.0)),
        debug_vis=False,
        mesh_prim_paths=["/World/ground"],
    )

                                               
                                         


def define_markers() -> VisualizationMarkers:
    marker_cfg = VisualizationMarkersCfg(
        prim_path="/Visuals/myMarkers",
        markers={
            "sphere1": sim_utils.SphereCfg(
                radius=0.15,
                visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(1.0, 0.0, 0.0)),             
            ),
        },
    )
    return VisualizationMarkers(marker_cfg)


def quat_to_euler(quat):

    w, x, y, z = quat
    roll = math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
    pitch = math.asin(2 * (w * y - z * x))
    yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))
    return np.array([roll, pitch, yaw], dtype=np.float32)


                          
class HeterogeneousPushMultiAgent(DirectMARLEnv):
                              
    def __init__(self, cfg: HeterogeneousPushMultiAgentFlatEnvCfg, render_mode: str | None = None, **kwargs):
                     
        super().__init__(cfg, render_mode, **kwargs)
        
                    
        self._device = self.device

                            
        _wbc_assets_dir = os.environ.get("WBC_ASSETS_DIR", "")
        self.wbc_adapter = torch.jit.load(os.path.join(_wbc_assets_dir, "adapter_jit.pt"), map_location=self._device)
        self.wbc_policy_0 = torch.jit.load(os.path.join(_wbc_assets_dir, "wbc_jit.pt")).to(self.device)
        self.wbc_policy_1 = torch.jit.load(os.path.join(_wbc_assets_dir, "wbc_jit.pt")).to(self.device)
        self.wbc_adapter.eval()
        for param in self.wbc_adapter.parameters():
            param.requires_grad = False
        
        norm_stats = torch.load(os.path.join(_wbc_assets_dir, "adapter_norm_stats.pt"))
        
        self.input_mean = torch.tensor(norm_stats["input_mean"], device=self._device, dtype=torch.float32)
        self.input_std = torch.tensor(norm_stats["input_std"], device=self._device, dtype=torch.float32)
        self.output_mean = torch.tensor(norm_stats["output_mean"], device=self._device, dtype=torch.float32)
        self.output_std = torch.tensor(norm_stats["output_std"], device=self._device, dtype=torch.float32)
        
        self.lead_follow_controller = LeadFollowController(self.num_envs, self.device)
        self.policy_action_interval = 25 
                       
        self.clip_ranges = torch.tensor([
            (3, 3), (3, 3), (3, 3), (3, 3), (3, 3),
            (3, 3), (3, 3), (3, 3), (3, 3)
        ], device=self._device, dtype=torch.float32)                 
                                   
        self.high_level_cmd = {}
        for env_idx in range(self.num_envs):
            self.high_level_cmd[(env_idx, "robot_0")] = np.zeros(11, dtype=np.float64)
            self.high_level_cmd[(env_idx, "robot_1")] = np.zeros(11, dtype=np.float64)
                                         
        from collections import deque
        self.wbc_n_proprio = 93
        self.extra_history_len = 25
        self.history_len = 10

        self.proprio_history_buf = {}
        self.extra_history_buf = {}
        for env_idx in range(self.num_envs):
            for robot_id in ["robot_0", "robot_1"]:
                self.proprio_history_buf[(env_idx, robot_id)] = deque([np.zeros(self.wbc_n_proprio) for _ in range(self.history_len)], maxlen=self.history_len)
                self.extra_history_buf[(env_idx, robot_id)] = deque([np.zeros(self.wbc_n_proprio) for _ in range(self.extra_history_len)], maxlen=self.extra_history_len)
        
                                                       
        self.last_action = {}
        for env_idx in range(self.num_envs):
            for robot_id in ["robot_0", "robot_1"]:
                self.last_action[(env_idx, robot_id)] = np.zeros(23, dtype=np.float32)
        
                                    
        self.gait_cycle = {}
        for env_idx in range(self.num_envs):
            for robot_id in ["robot_0", "robot_1"]:
                self.gait_cycle[(env_idx, robot_id)] = np.array([0.25, 0.25])
        
                                          
        self.in_place_stand_flag = {}
        for env_idx in range(self.num_envs):
            for robot_id in ["robot_0", "robot_1"]:
                self.in_place_stand_flag[(env_idx, robot_id)] = True
        
                                           
        self.last_action_buffer = {}
        for env_idx in range(self.num_envs):
            for robot_id in ["robot_0", "robot_1"]:
                self.last_action_buffer[(env_idx, robot_id)] = np.zeros(23, dtype=np.float32)

                              
        self.MUJOCO_PHYS_NAMES = ["left_hip_pitch_joint", "left_hip_roll_joint", "left_hip_yaw_joint", "left_knee_joint", "left_ankle_pitch_joint", "left_ankle_roll_joint", "right_hip_pitch_joint", "right_hip_roll_joint", "right_hip_yaw_joint", "right_knee_joint", "right_ankle_pitch_joint", "right_ankle_roll_joint", "waist_yaw_joint", "waist_roll_joint", "waist_pitch_joint", "left_shoulder_pitch_joint", "left_shoulder_roll_joint", "left_shoulder_yaw_joint", "left_elbow_joint", "right_shoulder_pitch_joint", "right_shoulder_roll_joint", "right_shoulder_yaw_joint", "right_elbow_joint"]
        self.PHYS_23_NAMES = ["left_hip_pitch_joint", "right_hip_pitch_joint", "waist_yaw_joint", "left_hip_roll_joint", "right_hip_roll_joint", "waist_roll_joint", "left_hip_yaw_joint", "right_hip_yaw_joint", "waist_pitch_joint", "left_knee_joint", "right_knee_joint", "left_shoulder_pitch_joint", "right_shoulder_pitch_joint", "left_ankle_pitch_joint", "right_ankle_pitch_joint", "left_shoulder_roll_joint", "right_shoulder_roll_joint", "left_ankle_roll_joint", "right_ankle_roll_joint", "left_shoulder_yaw_joint", "right_shoulder_yaw_joint", "left_elbow_joint", "right_elbow_joint"]
        self.WBC_23_NAMES = self.MUJOCO_PHYS_NAMES
        
                
        self.isaac_to_mujoco_idx = [self.PHYS_23_NAMES.index(name) for name in self.MUJOCO_PHYS_NAMES]
        mujoco_to_isaac_map = {name: i for i, name in enumerate(self.MUJOCO_PHYS_NAMES)}
        self.mujoco_to_isaac_idx = [mujoco_to_isaac_map.get(name) for name in self.PHYS_23_NAMES]

                                               
        self.old_last_action = {}
        self.old_proprio_history_buf = {}
        self.old_extra_history_buf = {}
        self.old_gait_cycle = {}
        self.old_high_level_cmd = {}
        self.old_in_place_stand_flag = {}
        for env_idx in range(self.num_envs):
            for robot_id in ["robot_0", "robot_1"]:
                self.old_last_action[(env_idx, robot_id)] = np.zeros(23, dtype=np.float32)
                self.old_proprio_history_buf[(env_idx, robot_id)] = deque([np.zeros(self.wbc_n_proprio) for _ in range(self.history_len)], maxlen=self.history_len)
                self.old_extra_history_buf[(env_idx, robot_id)] = deque([np.zeros(self.wbc_n_proprio) for _ in range(self.extra_history_len)], maxlen=self.extra_history_len)
                self.old_gait_cycle[(env_idx, robot_id)] = np.array([0.25, 0.25])
                self.old_high_level_cmd[(env_idx, robot_id)] = self.high_level_cmd[(env_idx, robot_id)].copy()
                self.old_in_place_stand_flag[(env_idx, robot_id)] = True

                            
        self._setup_old_wbc_system()

    def _compute_formation_control(self, env_idx, robot_id, p0, p1, yaw0, yaw1, world_vertex1, world_vertex2):

                                    
        return torch.zeros(3, device=self.device)
    
    def _compute_goal_control(self, env_idx, robot_id, p0, p1, world_vertex1, world_vertex2):

                                    
        return torch.zeros(3, device=self.device)

    def _setup_old_wbc_system(self):

                                   
        self.old_MUJOCO_PHYS_NAMES = [
            "left_hip_pitch_joint", "left_hip_roll_joint", "left_hip_yaw_joint", "left_knee_joint", "left_ankle_pitch_joint", "left_ankle_roll_joint",
            "right_hip_pitch_joint", "right_hip_roll_joint", "right_hip_yaw_joint", "right_knee_joint", "right_ankle_pitch_joint", "right_ankle_roll_joint",
            "waist_yaw_joint", "waist_roll_joint", "waist_pitch_joint",
            "left_shoulder_pitch_joint", "left_shoulder_roll_joint", "left_shoulder_yaw_joint", "left_elbow_joint",
            "right_shoulder_pitch_joint", "right_shoulder_roll_joint", "right_shoulder_yaw_joint", "right_elbow_joint"
        ]
        self.old_PHYS_23_NAMES = [
            "left_hip_pitch_joint", "right_hip_pitch_joint", "waist_yaw_joint",
            "left_hip_roll_joint", "right_hip_roll_joint", "waist_roll_joint",
            "left_hip_yaw_joint", "right_hip_yaw_joint", "waist_pitch_joint",
            "left_knee_joint", "right_knee_joint", "left_shoulder_pitch_joint",
            "right_shoulder_pitch_joint", "left_ankle_pitch_joint", "right_ankle_pitch_joint",
            "left_shoulder_roll_joint", "right_shoulder_roll_joint", "left_ankle_roll_joint",
            "right_ankle_roll_joint", "left_shoulder_yaw_joint", "right_shoulder_yaw_joint",
            "left_elbow_joint", "right_elbow_joint"
        ]
        self.old_isaac_to_mujoco_idx = [self.old_PHYS_23_NAMES.index(name) for name in self.old_MUJOCO_PHYS_NAMES]
        self.old_WBC_23_NAMES = self.old_MUJOCO_PHYS_NAMES
        self.old_WBC_23_DEFAULT = np.array([
            -0.1, 0.0, 0.0, 0.3, -0.2, 0.0,
            -0.1, 0.0, 0.0, 0.3, -0.2, 0.0,
            0.0, 0.0, 0.0,
            0.5, 0.0, 0.2, 0.3,
            0.5, 0.0, -0.2, 0.3,
        ], dtype=np.float32)
        self.old_wbc_dict = {name: val for name, val in zip(self.old_WBC_23_NAMES, self.old_WBC_23_DEFAULT)}
        self.old_default_dof_pos = np.array([self.old_wbc_dict[name] for name in self.old_PHYS_23_NAMES], dtype=np.float32)
        self.WBC_23_DEFAULT = np.array([-0.1, 0.0, 0.0, 0.3, -0.2, 0.0, -0.1, 0.0, 0.0, 0.3, -0.2, 0.0, 0.0, 0.0, 0.0, 0.5, 0.0, 0.462, 0.65, 0.5, 0.0, -0.462, 0.65], dtype=np.float32)
        self.wbc_dict = {name: val for name, val in zip(self.WBC_23_NAMES, self.WBC_23_DEFAULT)}
        self.default_dof_pos = np.array([self.wbc_dict[name] for name in self.PHYS_23_NAMES], dtype=np.float32)
        self.action_scale = 0.25
        self.scales_ang_vel = 0.25
        self.scales_dof_vel = 0.05
        self._n_demo_dof = 8
        self.n_priv = 3
                                    
        self.gait_freq = 1.3*2
                            
        self.demo_obs_template = np.zeros((8 + 3 + 3 + 3,))
        self.demo_obs_template[: self._n_demo_dof] = self.default_dof_pos[15:23]
        self.demo_obs_template[self._n_demo_dof + 6 : self._n_demo_dof + 9] = 0.75
        self._commands = torch.zeros(self.num_envs, 3, device=self._device, dtype=torch.float32)
        self.targets = torch.zeros(self.num_envs, 3, device=self._device, dtype=torch.float32)
        self.potentials = torch.zeros(self.num_envs, device=self._device, dtype=torch.float32)
        self.prev_potentials = torch.zeros(self.num_envs, device=self._device, dtype=torch.float32)
        self.inv_start_rot = torch.zeros(self.num_envs, 4, device=self._device, dtype=torch.float32)
        self.basis_vec0 = torch.zeros(self.num_envs, 3, device=self._device, dtype=torch.float32)
        self.basis_vec1 = torch.zeros(self.num_envs, 3, device=self._device, dtype=torch.float32)
        self._episode_sums = {}
        self.previous_actions = {}
        for robot_id in ["robot_0", "robot_1"]:
            self.previous_actions[robot_id] = torch.zeros((self.num_envs, 3), device=self._device, dtype=torch.float32)
        self.wbc_control_step = 0
        self.processed_actions = {}
        for env_idx in range(self.num_envs):
            for robot_id in ["robot_0", "robot_1"]:
                self.processed_actions[(env_idx, robot_id)] = np.zeros(23, dtype=np.float32)
        max_len = getattr(self.cfg, 'max_episode_length', None)
        if max_len is not None:
            self._max_episode_length = max_len
        else:
            seconds_per_env_step_val = self.cfg.sim.dt * self.cfg.decimation
            self._max_episode_length = math.ceil(self.cfg.episode_length_s / seconds_per_env_step_val)

                               
    def to_numpy(self, x):
        if isinstance(x, torch.Tensor):
            return x.detach().cpu().numpy()
        return x
            
                                                                       
    def get_wbc_observation(self, robot_id, env_idx=0):
        self._update_dynamic_short_goals()
        self_pos_w = self.robots[robot_id].data.root_pos_w[env_idx].cpu().numpy()
        self_lin_vel_w = self.robots[robot_id].data.root_com_lin_vel_w[env_idx].cpu().numpy()
        self_quat_w = self.robots[robot_id].data.root_link_quat_w[env_idx].cpu().numpy()
        self_rpy = quat_to_euler_angles_torch(torch.tensor(self_quat_w, dtype=torch.float32).unsqueeze(0)).cpu().numpy()[0]
        self_yaw = self_rpy[2]

                         
        other_id = "robot_1" if robot_id == "robot_0" else "robot_0"
        other_pos_w = self.robots[other_id].data.root_pos_w[env_idx].cpu().numpy()
        other_lin_vel_w = self.robots[other_id].data.root_com_lin_vel_w[env_idx].cpu().numpy()
        other_quat_w = self.robots[other_id].data.root_link_quat_w[env_idx].cpu().numpy()
        other_rpy = quat_to_euler_angles_torch(torch.tensor(other_quat_w, dtype=torch.float32).unsqueeze(0)).cpu().numpy()[0]
        other_yaw = other_rpy[2]
           
        box_pos_w = self.object.data.root_com_pos_w[env_idx].cpu().numpy()
        box_quat_w = self.object.data.root_com_quat_w[env_idx].cpu().numpy()
          
        stick_length = 2.0
        stick_width = 0.06
        stick_height = 0.06
        
        local_vertex1 = np.array([stick_length/2, 0, 0], dtype=np.float32)      
        local_vertex2 = np.array([-stick_length/2, 0, 0], dtype=np.float32)       
        
                  
        w, x, y, z = box_quat_w
        rot_matrix = np.array([
            [1 - 2*y*y - 2*z*z, 2*x*y - 2*w*z, 2*x*z + 2*w*y],
            [2*x*y + 2*w*z, 1 - 2*x*x - 2*z*z, 2*y*z - 2*w*x],
            [2*x*z - 2*w*y, 2*y*z + 2*w*x, 1 - 2*x*x - 2*y*y],
        ], dtype=np.float32)
        
                       
        world_vertex1 = rot_matrix @ local_vertex1 + box_pos_w
        world_vertex2 = rot_matrix @ local_vertex2 + box_pos_w

                                      
        if hasattr(self, '_fixed_long_goals') and hasattr(self, '_target_angles'):
            target_pos = self._fixed_long_goals[env_idx].cpu().numpy()
            target_angle = self._target_angles[env_idx].cpu().numpy()
            
                               
            cos_angle = np.cos(target_angle)
            sin_angle = np.sin(target_angle)
            target_vertex1 = np.array([
                target_pos[0] + stick_length/2 * cos_angle,
                target_pos[1] + stick_length/2 * sin_angle,
                0.0
            ], dtype=np.float32)
            target_vertex2 = np.array([
                target_pos[0] - stick_length/2 * cos_angle,
                target_pos[1] - stick_length/2 * sin_angle,
                0.0
            ], dtype=np.float32)
        else:
                             
            target_vertex1 = world_vertex1.copy()
            target_vertex2 = world_vertex2.copy()

        obs_list = [
                       
            self_pos_w[0], self_pos_w[1],          
            self_lin_vel_w[0], self_lin_vel_w[1],          
        
            self_yaw,       
               
            other_pos_w[0], other_pos_w[1],          
            other_lin_vel_w[0], other_lin_vel_w[1],          
          
            other_yaw,       
           
            world_vertex1[0], world_vertex1[1],          
            world_vertex2[0], world_vertex2[1],          
                       
            target_vertex1[0], target_vertex1[1],            
            target_vertex2[0], target_vertex2[1],            
        ]

        obs = np.asarray(obs_list, dtype=np.float32)
        return obs, None
                               
                                                                       
    def get_wbc_observation_old_complete(self, robot_id, env_idx=0):

        def to_cpu_numpy(x):
            if isinstance(x, torch.Tensor):
                return x.detach().cpu().numpy()
            return x
                                 
        dof_pos = to_cpu_numpy(self.robots[robot_id].data.joint_pos[env_idx, :23])
        dof_vel = to_cpu_numpy(self.robots[robot_id].data.joint_vel[env_idx, :23])
        root_quat = to_cpu_numpy(self.robots[robot_id].data.root_link_quat_w[env_idx])
        root_ang_vel = to_cpu_numpy(self.robots[robot_id].data.root_com_ang_vel_w[env_idx])

                              
        def quat_to_euler_original(quat):
            w, x, y, z = quat
            roll = math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
            pitch = math.asin(2 * (w * y - z * x))
            yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))
            return np.array([roll, pitch, yaw])

        rpy = quat_to_euler_original(root_quat)
        high_level_cmd = self.old_high_level_cmd[(env_idx, robot_id)]                   
        target_yaw = high_level_cmd[1]

                                            
        self.old_in_place_stand_flag[(env_idx, robot_id)] = (np.abs(high_level_cmd[0]) < 0.1) and (np.abs(high_level_cmd[2]) < 0.1)

        dyaw = rpy[2] - target_yaw
        dyaw = np.remainder(dyaw + np.pi, 2 * np.pi) - np.pi
        if self.old_in_place_stand_flag[(env_idx, robot_id)]:
                                             
            target_yaw = rpy[2]
                           
        if robot_id == "robot_0":
                            
            dyaw = np.clip(dyaw, -0.05, 0.05)                         
        elif robot_id == "robot_1":
                            
            dyaw = np.clip(dyaw, -0.15, 0.15)                         

        gait_obs = np.sin(self.old_gait_cycle[(env_idx, robot_id)] * 2 * np.pi)

        dof_pos_mujoco_order = dof_pos[self.old_isaac_to_mujoco_idx]
        adapter_input = np.concatenate([np.zeros(4), dof_pos_mujoco_order[15:]])
        adapter_input[0] = 0.75 + high_level_cmd[3]
        adapter_input[1] = high_level_cmd[4]
        adapter_input[2] = high_level_cmd[5]
        adapter_input[3] = high_level_cmd[6]
        adapter_input_tensor = torch.tensor(adapter_input, device=self.device, dtype=torch.float32).unsqueeze(0)
        adapter_input_tensor = (adapter_input_tensor - self.input_mean) / (self.input_std + 1e-8)
        with torch.no_grad():
            adapter_output = self.wbc_adapter(adapter_input_tensor.view(1, -1))
            adapter_output = adapter_output * self.output_std + self.output_mean

        dof_pos_error = dof_pos - self.old_default_dof_pos[:23]
        dof_pos_error_mujoco_order = dof_pos_error[self.old_isaac_to_mujoco_idx]
        dof_vel_mujoco_order = dof_vel[self.old_isaac_to_mujoco_idx]
        last_action_mujoco_order = self.old_last_action[(env_idx, robot_id)][self.old_isaac_to_mujoco_idx]

        obs_prop = np.concatenate([
            root_ang_vel * self.scales_ang_vel,
            rpy[:2],
            np.array([np.sin(dyaw), np.cos(dyaw)]),
            dof_pos_error_mujoco_order,
            dof_vel_mujoco_order * self.scales_dof_vel,
            last_action_mujoco_order,
            gait_obs,
            adapter_output.cpu().numpy().squeeze(),
        ])

        obs_demo = np.zeros(17, dtype=np.float32)
        obs_demo[:self._n_demo_dof] = dof_pos_mujoco_order[15:]
        obs_demo[self._n_demo_dof] = high_level_cmd[0]
        obs_demo[self._n_demo_dof+1] = high_level_cmd[2]
        obs_demo[self._n_demo_dof+3] = high_level_cmd[4]
        obs_demo[self._n_demo_dof+4] = high_level_cmd[5]
        obs_demo[self._n_demo_dof+5] = high_level_cmd[6]
        obs_demo[self._n_demo_dof+6:self._n_demo_dof+9] = 0.75 + high_level_cmd[3]

        obs_priv = np.zeros((self.n_priv,), dtype=np.float32)

                        
        self.old_proprio_history_buf[(env_idx, robot_id)].append(obs_prop.astype(np.float64))
        obs_hist = np.array(self.old_proprio_history_buf[(env_idx, robot_id)]).flatten()
        self.old_extra_history_buf[(env_idx, robot_id)].append(obs_prop.astype(np.float64))

        obs = np.concatenate((obs_prop, obs_demo, obs_priv, obs_hist))
        return obs, obs_prop

    def update_old_last_action(self, robot_id, wbc_action_15, env_idx=0):

        if not hasattr(self, 'old_last_action'):
            self.old_last_action = {(e, rid): np.zeros(23, dtype=np.float32) for e in range(self.num_envs) for rid in ["robot_0", "robot_1"]}
        dof_pos = self.to_numpy(self.robots[robot_id].data.joint_pos[env_idx, :23])
        dof_pos_mujoco_order = dof_pos[self.old_isaac_to_mujoco_idx]
        default_dof_pos_mujoco_order = self.old_default_dof_pos[self.old_isaac_to_mujoco_idx]
        arm_pos_delta_scaled = (dof_pos_mujoco_order[15:] - default_dof_pos_mujoco_order[15:]) / self.action_scale
        last_action_23_mujoco_order = np.concatenate([wbc_action_15, arm_pos_delta_scaled])
        mujoco_to_isaac_map = {name: i for i, name in enumerate(self.old_MUJOCO_PHYS_NAMES)}
        self.old_last_action[(env_idx, robot_id)] = np.array([last_action_23_mujoco_order[mujoco_to_isaac_map.get(name)] for name in self.old_PHYS_23_NAMES])

    def _old_pre_physics_step(self, robot_id, env_idx=0, update_gait=False):

        if not hasattr(self, 'old_wbc_control_step'):
            self.old_wbc_control_step = 0
        self.old_wbc_control_step += 1
        
        high_level_cmd = self.old_high_level_cmd[(env_idx, robot_id)]
                
        if self.old_in_place_stand_flag[(env_idx, robot_id)]:
                                         
                                       
            self.old_gait_cycle[(env_idx, robot_id)] = np.array([0.25, 0.25])
        else:
                                   
            self.old_gait_cycle[(env_idx, robot_id)] = np.remainder(self.old_gait_cycle[(env_idx, robot_id)] + self.cfg.sim.dt * self.cfg.decimation * self.gait_freq, 1.0)
                      
            if (np.abs(self.old_gait_cycle[(env_idx, robot_id)][0] - 0.25) < 0.05) and (np.abs(self.old_gait_cycle[(env_idx, robot_id)][1] - 0.25) < 0.05):
                self.old_gait_cycle[(env_idx, robot_id)] = np.array([0.25, 0.75])
        obs_old, obs_prop_old = self.get_wbc_observation_old_complete(robot_id, env_idx)
        obs_old_tensor = torch.from_numpy(obs_old).float().unsqueeze(0).to(self.device)
        extra_hist_old = np.array(self.old_extra_history_buf[(env_idx, robot_id)]).flatten()
        extra_hist_old_tensor = torch.from_numpy(extra_hist_old).float().unsqueeze(0).to(self.device)
        with torch.no_grad():
            policy_to_use = self.wbc_policy_0 if robot_id == "robot_0" else self.wbc_policy_1
            wbc_action_15_old = policy_to_use(obs_old_tensor, extra_hist_old_tensor).cpu().numpy().squeeze()
        self.update_old_last_action(robot_id, wbc_action_15_old, env_idx)
        wbc_action_23_delta = np.concatenate([wbc_action_15_old, np.zeros(8, dtype=wbc_action_15_old.dtype)])
        old_wbc_dict = {name: val for name, val in zip(self.old_WBC_23_NAMES, wbc_action_23_delta)}
        wbc_action_23_delta_phys = np.array([old_wbc_dict.get(name) for name in self.old_PHYS_23_NAMES], dtype=np.float32)
        base = self.old_default_dof_pos.copy()
        wbc_action_23_final_old = base + wbc_action_23_delta_phys * self.action_scale
        left_shoulder_pitch = np.clip(self.old_high_level_cmd[(env_idx, robot_id)][7], -1.6, 0)
        right_shoulder_pitch = np.clip(self.old_high_level_cmd[(env_idx, robot_id)][8], -1.6, 0)
        l_idx = self.old_PHYS_23_NAMES.index('left_shoulder_pitch_joint')
        r_idx = self.old_PHYS_23_NAMES.index('right_shoulder_pitch_joint')
        wbc_action_23_final_old[l_idx] = self.old_default_dof_pos[l_idx] + left_shoulder_pitch
        wbc_action_23_final_old[r_idx] = self.old_default_dof_pos[r_idx] + right_shoulder_pitch
        if update_gait:
            self.gait_cycle[(env_idx, robot_id)] = self.old_gait_cycle[(env_idx, robot_id)].copy()
            self.last_action[(env_idx, robot_id)] = self.old_last_action[(env_idx, robot_id)].copy()
            self.processed_actions[(env_idx, robot_id)] = wbc_action_23_final_old.copy()
        return wbc_action_15_old, wbc_action_23_final_old
                                                      
    def _pre_physics_step(self, actions: Optional[dict[str, Any]] = None):
                                                                                                    
        self.wbc_control_step += 1
        
                       
        if hasattr(self, '_reset_step_counters'):
            self._reset_step_counters += 1
        
                                             
        self._update_dynamic_short_goals()
        
                                                                                           
        if actions is not None and not self.manual_high_level_cmd_mode:
            self.set_high_level_cmd_from_policy(actions)
                                
            for robot_id in self.robots.keys():
                self.previous_actions[robot_id] = actions[robot_id].clone()
        
        for env_idx in range(self.num_envs):
            for robot_id in self.robots.keys():
                                                                                 
                wbc_action_15_old, wbc_action_23_final_old = self._old_pre_physics_step(robot_id, env_idx, update_gait=True)
                                            
                self.gait_cycle[(env_idx, robot_id)] = self.old_gait_cycle[(env_idx, robot_id)].copy() if hasattr(self, 'old_gait_cycle') and (env_idx, robot_id) in self.old_gait_cycle else np.array([0.25, 0.25])
                self.last_action[(env_idx, robot_id)] = self.old_last_action[(env_idx, robot_id)].copy() if hasattr(self, 'old_last_action') and (env_idx, robot_id) in self.old_last_action else np.zeros(23, dtype=np.float32)
                self.processed_actions[(env_idx, robot_id)] = wbc_action_23_final_old.copy()
        
                                                    
        self._draw_markers_with_fixed_goals()

    def _reset_idx(self, env_ids: torch.Tensor):
                                                    
        if env_ids is None:
            env_ids = torch.arange(self.num_envs, device=self.device)

                                        
        for robot in self.robots.values():
            default_root_state = robot.data.default_root_state[env_ids].clone()
            default_root_state[:, :3] += self._terrain.env_origins[env_ids]
            robot.write_root_state_to_sim(default_root_state, env_ids)
            joint_pos = robot.data.default_joint_pos[env_ids]
            joint_vel = robot.data.default_joint_vel[env_ids]
            robot.write_joint_state_to_sim(joint_pos, joint_vel, None, env_ids)
        
        if hasattr(self, "object"):
            default_root_state_obj = self.object.data.default_root_state[env_ids].clone()
            default_root_state_obj[:, :3] += self._terrain.env_origins[env_ids]
                                 
            self.object.write_root_state_to_sim(default_root_state_obj, env_ids)                
        
                                                            
                           
        env_ids_list = env_ids.tolist() if isinstance(env_ids, torch.Tensor) else env_ids

        for env_idx in env_ids_list:
            for robot_id in self.robots.keys():
                                   
                                     
                self.gait_cycle[(env_idx, robot_id)] = np.array([0.25, 0.25])
                                               
                if hasattr(self, '_pending_policy_cmd') and (env_idx, robot_id) in self._pending_policy_cmd:
                    cmd = self._pending_policy_cmd[(env_idx, robot_id)]
                    self.high_level_cmd[(env_idx, robot_id)] = cmd
                    self.old_high_level_cmd[(env_idx, robot_id)] = cmd.copy()
                                                             
                high_level_cmd = self.high_level_cmd[(env_idx, robot_id)]
                self.in_place_stand_flag[(env_idx, robot_id)] = (np.abs(high_level_cmd[0]) < 0.1) and (np.abs(high_level_cmd[2]) < 0.1)
                                      
                self.last_action[(env_idx, robot_id)] = np.zeros(23, dtype=np.float32)
                self.last_action_buffer[(env_idx, robot_id)] = np.zeros(23, dtype=np.float32)
                                
                self.proprio_history_buf[(env_idx, robot_id)] = deque([np.zeros(self.wbc_n_proprio) for _ in range(self.history_len)], maxlen=self.history_len)
                self.extra_history_buf[(env_idx, robot_id)] = deque([np.zeros(self.wbc_n_proprio) for _ in range(self.extra_history_len)], maxlen=self.extra_history_len)
                                            
                if not hasattr(self, 'processed_actions'):
                    self.processed_actions = {}
                self.processed_actions[(env_idx, robot_id)] = np.zeros(23, dtype=np.float32)

                                 
        if not hasattr(self, 'potentials'):
            self.potentials = torch.zeros(self.num_envs, device=self.device, dtype=torch.float32)
        if not hasattr(self, 'prev_potentials'):
            self.prev_potentials = torch.zeros(self.num_envs, device=self.device, dtype=torch.float32)
        if not hasattr(self, '_episode_sums'):
            self._episode_sums = {}
        
        self.potentials[env_ids] = 0.0
        self.prev_potentials[env_ids] = 0.0
        
                                  
        for key in self._episode_sums.keys():
            self._episode_sums[key][env_ids] = 0.0
        
        self.episode_length_buf[env_ids] = 0
        self.wbc_control_step = 0
        
                        
        if not hasattr(self, '_reset_step_counters'):
            self._reset_step_counters = torch.zeros(self.num_envs, device=self.device, dtype=torch.int32)
        self._reset_step_counters[env_ids] = 0

                            
        for robot_id in self.robots.keys():
            self.previous_actions[robot_id][env_ids] = 0.0

                                           
        self._generate_fixed_target_goals(env_ids)


    def _generate_fixed_target_goals(self, env_ids: torch.Tensor):

                                                       
        if not hasattr(self, '_target_angles'):
            self._target_angles = torch.zeros(self.num_envs, device=self.device)
        
                                                                                         
        if not hasattr(self, '_fixed_long_goals'):
                                        
            box_pos = self.object.data.body_com_pos_w.squeeze(1).clone()
            self._fixed_long_goals = box_pos.clone()
        else:
                                          
            box_pos = self.object.data.body_com_pos_w.squeeze(1).clone()
            self._fixed_long_goals[env_ids] = box_pos[env_ids]

    def _update_dynamic_short_goals(self):

        from isaaclab_tasks.utils.custom_trajectory import get_long_goal, get_target_angle, get_short_term_goal
        
                       
        box_pos = self.object.data.body_com_pos_w.squeeze(1).clone()
        env_origins = self.scene.env_origins
        
                                                                
        if hasattr(self, '_reset_step_counters'):
                          
            current_times = self._reset_step_counters.float() * 0.02            
        else:
            current_times = torch.zeros(self.num_envs, device=self.device)
        
                                      
        long_goal = get_long_goal(
            box_pos, 
            env_origins, 
            step=0,                    
            device=self.device,
            current_times=current_times               
        )
        
                                    
        if not hasattr(self, '_fixed_long_goals'):
            self._fixed_long_goals = torch.zeros((self.num_envs, 3), device=self.device)
        self._fixed_long_goals[:] = long_goal
        
                                      
        target_angle = get_target_angle(
            box_pos, long_goal, env_origins, device=self.device, current_times=current_times
        )
        
                
        if not hasattr(self, '_target_angles'):
            self._target_angles = torch.zeros(self.num_envs, device=self.device)
        self._target_angles[:] = target_angle
        
                                                  
        short_goal = get_short_term_goal(box_pos, long_goal, distance=0.5)
        
                   
        if not hasattr(self, '_current_short_goals'):
            self._current_short_goals = torch.zeros((self.num_envs, 3), device=self.device)
        if not hasattr(self, '_current_commands'):
            self._current_commands = torch.zeros((self.num_envs, 3), device=self.device)
        
                        
        self._current_short_goals[:] = short_goal
        
                              
        box_to_goal = self._current_short_goals - box_pos
        push_direction = box_to_goal[:, :2]            
        
                        
        push_direction_norm = torch.norm(push_direction, dim=1, keepdim=True)
        push_direction = push_direction / (push_direction_norm + 1e-8)
        push_speed = torch.clamp(push_direction_norm, 0.1, 1.0)
        push_direction = push_direction * push_speed
        
                  
        self._current_commands[:, 0] = push_direction[:, 0]         
        self._current_commands[:, 1] = push_direction[:, 1]         
        self._current_commands[:, 2] = 0.0       


    def set_high_level_cmd_from_policy(self, actions: dict[str, Any]):
        if not hasattr(self, '_pending_policy_cmd') or self._pending_policy_cmd is None:
            self._pending_policy_cmd = {}
        
                
        box_pos = self.object.data.root_com_pos_w.cpu().numpy()                 
        
                          
        for env_idx in range(self.num_envs):
            robot1_pos = self.robots["robot_1"].data.root_pos_w[env_idx, :2]
            self.lead_follow_controller.robot1_positions[env_idx] = robot1_pos
        
                                    
        for robot_id in ["robot_0", "robot_1"]:
            act = actions[robot_id]
            if isinstance(act, torch.Tensor):
                act = act.detach().cpu().numpy()
            for env_idx in range(self.num_envs):
                a = act[env_idx] if getattr(act, "ndim", 0) > 1 else act
                a = np.asarray(a, dtype=np.float32).reshape(-1)
                if a.shape[0] != 11:
                    a = np.zeros(11, dtype=np.float32)
                cmd = a.astype(np.float64, copy=False)
                self.high_level_cmd[(env_idx, robot_id)] = cmd
                self.old_high_level_cmd[(env_idx, robot_id)] = cmd.copy()
                self._pending_policy_cmd[(env_idx, robot_id)] = cmd.copy()

    def _setup_scene(self):
        self.num_robots = sum(1 for key in self.cfg.__dict__.keys() if "robot_" in key)
        self.robots = {}
        self.contact_sensors = {}
        self.height_scanners = {}
        self.my_visualizer = define_markers()
        self.object = RigidObject(getattr(self.cfg, "cfg_rec_prism"))

        self.scene.rigid_objects["object"] = self.object
        
                                 
        for i in range(1, 13):
            wall_attr = f'wall_{i}'
            if hasattr(self.cfg, wall_attr):
                wall_obj = RigidObject(getattr(self.cfg, wall_attr))
                self.scene.rigid_objects[f"wall_{i}"] = wall_obj
        
              
        if hasattr(self.cfg, 'table'):
            table_obj = RigidObject(getattr(self.cfg, 'table'))
            self.scene.rigid_objects["table"] = table_obj

        for i in range(self.num_robots):
            robot_id = f"robot_{i}"
            if robot_id in self.cfg.__dict__:
                self.robots[f"robot_{i}"] = Articulation(self.cfg.__dict__["robot_" + str(i)])
                self.scene.articulations[f"robot_{i}"] = self.robots[f"robot_{i}"]

            contact_sensor_id = "contact_sensor_" + str(i)

            if contact_sensor_id in self.cfg.__dict__:
                self.contact_sensors[f"robot_{i}"] = ContactSensor(self.cfg.__dict__["contact_sensor_" + str(i)])
                self.scene.sensors[f"robot_{i}"] = self.contact_sensors[f"robot_{i}"]

                                                            
                                                        
                                                                                                               
                                                                                       

        terrain_cfg = getattr(self.cfg, "terrain")
        terrain_cfg.num_envs = self.scene.cfg.num_envs
        terrain_cfg.env_spacing = self.scene.cfg.env_spacing
        self._terrain = terrain_cfg.class_type(terrain_cfg)
                                      
        self.scene.clone_environments(copy_from_source=False)
        self.scene.filter_collisions(global_prim_paths=[terrain_cfg.prim_path])
                    
        light_cfg = sim_utils.DomeLightCfg(intensity=2000.0, color=(0.75, 0.75, 0.75))
        light_cfg.func("/World/Light", light_cfg)

    def _get_anymal_fallen(self):
        agent_dones = []
        robot = self.robots["robot_0"]
        anymal_min_z_pos = getattr(self.cfg, 'anymal_min_z_pos', 0.3)
        died = robot.data.body_com_pos_w[:, 0, 2].view(-1) < anymal_min_z_pos
        agent_dones.append(died)

        robot = self.robots["robot_1"]
        g1_min_z_pos = getattr(self.cfg, 'g1_min_z_pos', 0.6)
        died = robot.data.body_com_pos_w[:, 0, 2].view(-1) < g1_min_z_pos
        agent_dones.append(died)

        return torch.any(torch.stack(agent_dones), dim=0)

    def _apply_action(self):
        for robot_id in ["robot_0", "robot_1"]:
            actions = []
            for env_idx in range(self.num_envs):
                action = self.processed_actions[(env_idx, robot_id)]
                

                
                                                        
                if isinstance(action, np.ndarray):
                    action = torch.from_numpy(action).to(device=self.device, dtype=torch.float32)
                if action.shape[-1] < 29:
                    pad = torch.zeros(29 - action.shape[-1], device=action.device, dtype=action.dtype)
                    action = torch.cat([action, pad], dim=-1)
                elif action.shape[-1] > 29:
                    action = action[..., :29]
                actions.append(action)
            actions_tensor = torch.stack(actions, dim=0)
            self.robots[robot_id].set_joint_position_target(actions_tensor)
            
                         
                        
            joint_names = self.robots[robot_id].data.joint_names
                       
            left_wrist_roll_idx = None
            right_wrist_roll_idx = None
            for i, name in enumerate(joint_names):
                if name == "left_wrist_roll_joint":
                    left_wrist_roll_idx = i
                elif name == "right_wrist_roll_joint":
                    right_wrist_roll_idx = i
            
                               
            if left_wrist_roll_idx is not None and right_wrist_roll_idx is not None:
                                     
                wrist_targets = torch.zeros(actions_tensor.shape[0], 2, device=actions_tensor.device, dtype=actions_tensor.dtype)
                
                              
                wrist_targets[:, 0] = 0.0           
                wrist_targets[:, 1] = 0.0           
                
                          
                self.robots[robot_id].set_joint_position_target(wrist_targets, joint_ids=[left_wrist_roll_idx, right_wrist_roll_idx])

                         
            if getattr(self.cfg, 'wrist_roll_enable', False) or getattr(self.cfg, 'shoulder_yaw_enable', False) or getattr(self.cfg, 'shoulder_roll_enable', False):
                joint_names = self.robots[robot_id].data.joint_names
                left_wrist_roll_idx = None
                right_wrist_roll_idx = None
                left_shoulder_yaw_idx = None
                right_shoulder_yaw_idx = None
                left_shoulder_roll_idx = None
                right_shoulder_roll_idx = None
                for i, name in enumerate(joint_names):
                    if name == "left_wrist_roll_joint":
                        left_wrist_roll_idx = i
                    elif name == "right_wrist_roll_joint":
                        right_wrist_roll_idx = i
                    elif name == "left_shoulder_yaw_joint":
                        left_shoulder_yaw_idx = i
                    elif name == "right_shoulder_yaw_joint":
                        right_shoulder_yaw_idx = i
                    elif name == "left_shoulder_roll_joint":
                        left_shoulder_roll_idx = i
                    elif name == "right_shoulder_roll_joint":
                        right_shoulder_roll_idx = i
                
                           
                joint_ids = []
                joint_targets = []
                
                if getattr(self.cfg, 'wrist_roll_enable', False):
                    if left_wrist_roll_idx is not None and right_wrist_roll_idx is not None:
                        joint_ids.extend([left_wrist_roll_idx, right_wrist_roll_idx])
                        joint_targets.extend([
                            float(getattr(self.cfg, 'wrist_roll_left_target', 0.0)),
                            float(getattr(self.cfg, 'wrist_roll_right_target', 0.0))
                        ])
                
                if getattr(self.cfg, 'shoulder_yaw_enable', False):
                    if left_shoulder_yaw_idx is not None and right_shoulder_yaw_idx is not None:
                        joint_ids.extend([left_shoulder_yaw_idx, right_shoulder_yaw_idx])
                        joint_targets.extend([
                            float(getattr(self.cfg, 'shoulder_yaw_left_target', 0.0)),
                            float(getattr(self.cfg, 'shoulder_yaw_right_target', 0.0))
                        ])
                
                if getattr(self.cfg, 'shoulder_roll_enable', False):
                    if left_shoulder_roll_idx is not None and right_shoulder_roll_idx is not None:
                        joint_ids.extend([left_shoulder_roll_idx, right_shoulder_roll_idx])
                        joint_targets.extend([
                            float(getattr(self.cfg, 'shoulder_roll_left_target', 0.0)),
                            float(getattr(self.cfg, 'shoulder_roll_right_target', 0.0))
                        ])
                
                if joint_ids:
                    targets = torch.zeros(actions_tensor.shape[0], len(joint_ids), device=actions_tensor.device, dtype=actions_tensor.dtype)
                    for i, target_val in enumerate(joint_targets):
                        targets[:, i] = target_val
                    self.robots[robot_id].set_joint_position_target(targets, joint_ids=joint_ids)


    def _get_observations(self) -> dict[str, torch.Tensor]:



        obs_dict: dict[str, torch.Tensor] = {}

        if not hasattr(self, "_snapshot_buf"):
            self._snapshot_buf = torch.zeros((self.num_envs, 2, 3, 58), device=self.device, dtype=torch.float32)

        pos_0 = self.robots["robot_0"].data.root_state_w[:, :3]
        pos_1 = self.robots["robot_1"].data.root_state_w[:, :3]
        vel_0 = self.robots["robot_0"].data.root_com_lin_vel_w[:, :3]
        vel_1 = self.robots["robot_1"].data.root_com_lin_vel_w[:, :3]
        quat_0 = self.robots["robot_0"].data.root_link_quat_w
        quat_1 = self.robots["robot_1"].data.root_link_quat_w
        ypr_0 = quat_to_euler_angles_torch(quat_0)
        ypr_1 = quat_to_euler_angles_torch(quat_1)
        yaw_0 = ypr_0[:, 2]
        yaw_1 = ypr_1[:, 2]

        box_state = self.object.data.root_state_w
        box_pos = box_state[:, :3]
        box_vel = box_state[:, 7:10] if box_state.shape[1] >= 10 else torch.zeros_like(box_pos)
        box_quat = self.object.data.root_com_quat_w

        stick_length = 2.0
        stick_width = 0.06
        local_vertex_xy = torch.tensor(
            [
                [stick_length / 2, stick_width / 2],
                [stick_length / 2, -stick_width / 2],
                [-stick_length / 2, -stick_width / 2],
                [-stick_length / 2, stick_width / 2],
            ],
            device=self.device,
            dtype=torch.float32,
        )

        w, x, y, z = box_quat[:, 0], box_quat[:, 1], box_quat[:, 2], box_quat[:, 3]
        rot_matrix = torch.stack(
            [
                torch.stack([1 - 2 * y * y - 2 * z * z, 2 * x * y - 2 * w * z], dim=1),
                torch.stack([2 * x * y + 2 * w * z, 1 - 2 * x * x - 2 * z * z], dim=1),
            ],
            dim=1,
        )
        world_corners_xy = torch.einsum("bij,kj->bki", rot_matrix, local_vertex_xy) + box_pos[:, :2].unsqueeze(1)
        world_corners = torch.cat([world_corners_xy, box_pos[:, 2:3].unsqueeze(1).expand(-1, 4, -1)], dim=2)

        if hasattr(self, "_fixed_long_goals"):
            long_goals_xy = self._fixed_long_goals[:, :2]
        else:
            long_goals_xy = box_pos[:, :2]

        def to_egocentric_xy(points_xy: torch.Tensor, robot_pos_xy: torch.Tensor, robot_yaw: torch.Tensor) -> torch.Tensor:
            d = points_xy - robot_pos_xy.unsqueeze(1)
            cy = torch.cos(robot_yaw).unsqueeze(1)
            sy = torch.sin(robot_yaw).unsqueeze(1)
            x_local = cy * d[..., 0:1] + sy * d[..., 1:2]
            y_local = -sy * d[..., 0:1] + cy * d[..., 1:2]
            return torch.cat([x_local, y_local], dim=-1)

        def make_waypoints(robot_pos_xy: torch.Tensor, robot_yaw: torch.Tensor) -> torch.Tensor:
            dir_vec = long_goals_xy - robot_pos_xy
            dir_norm = torch.norm(dir_vec, dim=1, keepdim=True)
            dir_unit = dir_vec / (dir_norm + 1e-8)
            steps = torch.tensor([1.0, 2.0, 3.0, 4.0, 5.0], device=self.device, dtype=torch.float32).view(1, 5, 1)
            wps_xy = robot_pos_xy.unsqueeze(1) + dir_unit.unsqueeze(1) * steps
            wps_local = to_egocentric_xy(wps_xy, robot_pos_xy, robot_yaw)
            return wps_local.reshape(self.num_envs, 10)

        waypoints_0 = make_waypoints(pos_0[:, :2], yaw_0)
        waypoints_1 = make_waypoints(pos_1[:, :2], yaw_1)

        def make_contact_vec(robot_id: str) -> torch.Tensor:
            out = torch.zeros((self.num_envs, 2), device=self.device, dtype=torch.float32)
            if hasattr(self, "contact_sensors") and robot_id in self.contact_sensors:
                forces = self.contact_sensors[robot_id].data.net_forces_w
                for idx, body_name in enumerate(["left_rubber_hand", "right_rubber_hand"]):
                    try:
                        body_indices, _ = self.robots[robot_id].find_bodies(body_name)
                        if len(body_indices) > 0:
                            f = torch.norm(forces[:, body_indices[0], :], dim=-1)
                            out[:, idx] = (f > 0.1).to(dtype=torch.float32)
                    except Exception:
                        pass
            return out

        contact_0 = make_contact_vec("robot_0")
        contact_1 = make_contact_vec("robot_1")

        def make_static58(
            self_pos: torch.Tensor,
            self_vel: torch.Tensor,
            self_yaw: torch.Tensor,
            partner_pos: torch.Tensor,
            partner_vel: torch.Tensor,
            partner_yaw: torch.Tensor,
            waypoints: torch.Tensor,
            self_contact: torch.Tensor,
            partner_contact: torch.Tensor,
        ) -> torch.Tensor:
            self_prop = torch.cat(
                [
                    self_pos[:, :2],
                    self_vel[:, :2],
                    self_yaw.unsqueeze(1),
                    self_pos[:, 2:3],
                    torch.zeros((self.num_envs, 1), device=self.device, dtype=torch.float32),
                    torch.zeros((self.num_envs, 6), device=self.device, dtype=torch.float32),
                ],
                dim=1,
            )
            partner_prop = torch.cat(
                [
                    (partner_pos[:, :2] - self_pos[:, :2]),
                    (partner_vel[:, :2] - self_vel[:, :2]),
                    (partner_yaw - self_yaw).unsqueeze(1),
                    partner_pos[:, 2:3],
                    torch.zeros((self.num_envs, 1), device=self.device, dtype=torch.float32),
                    torch.zeros((self.num_envs, 6), device=self.device, dtype=torch.float32),
                ],
                dim=1,
            )
            obj_geom = torch.cat(
                [
                    world_corners.reshape(self.num_envs, 12),
                    box_pos,
                    box_vel,
                ],
                dim=1,
            )
            contact = torch.cat([self_contact, partner_contact], dim=1)
            return torch.cat([waypoints, self_prop, partner_prop, obj_geom, contact], dim=1)

        static_0 = make_static58(pos_0, vel_0, yaw_0, pos_1, vel_1, yaw_1, waypoints_0, contact_0, contact_1)
        static_1 = make_static58(pos_1, vel_1, yaw_1, pos_0, vel_0, yaw_0, waypoints_1, contact_1, contact_0)

        self._snapshot_buf = torch.roll(self._snapshot_buf, shifts=1, dims=2)
        self._snapshot_buf[:, 0, 0, :] = static_0
        self._snapshot_buf[:, 1, 0, :] = static_1

        rays_0 = torch.zeros((self.num_envs, 36), device=self.device, dtype=torch.float32)
        rays_1 = torch.zeros((self.num_envs, 36), device=self.device, dtype=torch.float32)

        obs_0 = torch.cat([self._snapshot_buf[:, 0].reshape(self.num_envs, 174), rays_0], dim=1)
        obs_1 = torch.cat([self._snapshot_buf[:, 1].reshape(self.num_envs, 174), rays_1], dim=1)

        assert obs_0.shape[1] == self.cfg.observation_spaces["robot_0"], f"Obs0 dim mismatch: {obs_0.shape[1]}"
        assert obs_1.shape[1] == self.cfg.observation_spaces["robot_1"], f"Obs1 dim mismatch: {obs_1.shape[1]}"

        obs_dict["robot_0"] = obs_0
        obs_dict["robot_1"] = obs_1
        return obs_dict

                                                                  
    def _get_states(self) -> torch.Tensor:



                                             
        obs = self._get_observations()["robot_0"]
        return obs
                                                         

    def get_y_euler_from_quat(self, quaternion):
        w, x, y, z = quaternion[:, 0], quaternion[:, 1], quaternion[:, 2], quaternion[:, 3]
        y_euler_angle = torch.arcsin(2 * (w * y - z * x))
        return y_euler_angle

    def _draw_markers(self, step=None):
        from isaaclab_tasks.utils.custom_trajectory import get_long_goal, get_short_term_goal

                        
        box_pos = self.object.data.root_com_pos_w.clone()
        env_origins = self.scene.env_origins
        
                       
                                                    
        step_val = step if step is not None else 0
        long_goal = get_long_goal(box_pos, env_origins, step=step_val, device=self.device)
        short_goal = get_short_term_goal(box_pos, long_goal, distance=0.5)

        box_marker_pos = box_pos.clone()
        box_marker_pos[:, 2] += 0.2              
                                                                                             
        marker_locations = torch.cat(
            [
                box_marker_pos,                 
                short_goal,                     
            ],
            dim=0,
        )

                                   
        marker_ids = torch.cat(
            [
                torch.zeros(self.num_envs, dtype=torch.int64, device=self.device),     
                torch.ones(self.num_envs, dtype=torch.int64, device=self.device),      
            ],
            dim=0,
        )
                         
        num_markers = marker_locations.shape[0]
        orientations = torch.tensor([1, 0, 0, 1], device=marker_locations.device, dtype=marker_locations.dtype).repeat(
            num_markers, 1
        )
                  
        desired_scale = 0.25
        scales = torch.tensor([desired_scale, desired_scale, desired_scale], device=self.device, dtype=torch.float32).repeat(num_markers, 1)

        self.my_visualizer.visualize(marker_locations, orientations, scales, marker_ids)

    def _draw_markers_with_fixed_goals(self):

        from isaaclab_tasks.utils.custom_trajectory import PATH_WAYPOINTS, STICK_LENGTH
        import numpy as np
        
                                      
        final_waypoint = PATH_WAYPOINTS[-1]
        final_center_x, final_center_y, final_angle_deg = final_waypoint
        
                      
        env_origins = self.scene.env_origins
        stick_length = STICK_LENGTH
        
                                         
        angle_rad = np.deg2rad(final_angle_deg)
        direction = np.array([np.sin(angle_rad), np.cos(angle_rad)])
        
                           
        final_center_local = np.array([final_center_x, final_center_y])
        final_vertex1_local = final_center_local + (stick_length / 2.0) * direction
        final_vertex2_local = final_center_local - (stick_length / 2.0) * direction
        
                  
        final_vertex1_world = torch.zeros(self.num_envs, 3, device=self.device)
        final_vertex2_world = torch.zeros(self.num_envs, 3, device=self.device)
        
                      
        table_marker_world = None
        if "table" in self.scene.rigid_objects:
            table = self.scene.rigid_objects["table"]
            table_pos = table.data.root_pos_w.clone()                 
            table_marker_world = table_pos.clone()
            table_marker_world[:, 2] += 0.3 + 0.1                                
        
        for env_idx in range(self.num_envs):
                    
            env_origin = env_origins[env_idx]
            
                    
            final_vertex1_world[env_idx, 0] = env_origin[0] + final_vertex1_local[0]
            final_vertex1_world[env_idx, 1] = env_origin[1] + final_vertex1_local[1]
            final_vertex1_world[env_idx, 2] = env_origin[2] + 0.4              
            
            final_vertex2_world[env_idx, 0] = env_origin[0] + final_vertex2_local[0]
            final_vertex2_world[env_idx, 1] = env_origin[1] + final_vertex2_local[1]
            final_vertex2_world[env_idx, 2] = env_origin[2] + 0.4              
        
                             
        marker_list = [
            final_vertex1_world,                      
            final_vertex2_world,                      
        ]
        if table_marker_world is not None:
            marker_list.append(table_marker_world)                      
        
        marker_locations = torch.cat(marker_list, dim=0)

                             
        marker_id_list = [
            torch.zeros(self.num_envs, dtype=torch.int64, device=self.device),           
            torch.zeros(self.num_envs, dtype=torch.int64, device=self.device),           
        ]
        if table_marker_world is not None:
            marker_id_list.append(torch.zeros(self.num_envs, dtype=torch.int64, device=self.device))           
        
        marker_ids = torch.cat(marker_id_list, dim=0)
        
                 
        num_markers = marker_locations.shape[0]
        orientations = torch.tensor([1, 0, 0, 1], device=marker_locations.device, dtype=marker_locations.dtype).repeat(
            num_markers, 1
        )
        desired_scale = 0.25
        scales = torch.tensor([desired_scale, desired_scale, desired_scale], device=self.device, dtype=torch.float32).repeat(num_markers, 1)

        self.my_visualizer.visualize(marker_locations, orientations, scales, marker_ids)



    def _get_rewards(self) -> dict:
        reward = {}

                                 
        if not hasattr(self, '_episode_sums'):
            self._episode_sums = {}

                      
        p0 = self.robots["robot_0"].data.root_state_w[:, :3]
        p1 = self.robots["robot_1"].data.root_state_w[:, :3]
        v0 = self.robots["robot_0"].data.root_com_lin_vel_w[:, :3]
        v1 = self.robots["robot_1"].data.root_com_lin_vel_w[:, :3]
        w0 = self.robots["robot_0"].data.root_com_ang_vel_w[:, :3]
        w1 = self.robots["robot_1"].data.root_com_ang_vel_w[:, :3]

                                    
        pair_distance_ref = getattr(self.cfg, 'pair_distance_ref', 1.6)
        pair_distance_penalty_scale = getattr(self.cfg, 'pair_distance_penalty_scale', -1500.0)
        face_alignment_reward_scale = getattr(self.cfg, 'face_alignment_reward_scale', 300.0)
        pair_move_reward_scale = getattr(self.cfg, 'pair_move_reward_scale', 120.0)
        pair_rot_reward_scale = getattr(self.cfg, 'pair_rot_reward_scale', 60.0)

                     
        
                             
        box_pos = self.object.data.root_com_pos_w
        box_quat = self.object.data.root_com_quat_w
        
              
        stick_length = 2.0
        
                            
        local_vertex1 = torch.tensor([stick_length/2, 0, 0], device=self.device, dtype=torch.float32)
        local_vertex2 = torch.tensor([-stick_length/2, 0, 0], device=self.device, dtype=torch.float32)
        
                  
        w, x, y, z = box_quat[:, 0], box_quat[:, 1], box_quat[:, 2], box_quat[:, 3]
        rot_matrix = torch.stack([
            torch.stack([1 - 2*y*y - 2*z*z, 2*x*y - 2*w*z, 2*x*z + 2*w*y], dim=1),
            torch.stack([2*x*y + 2*w*z, 1 - 2*x*x - 2*z*z, 2*y*z - 2*w*x], dim=1),
            torch.stack([2*x*z - 2*w*y, 2*y*z + 2*w*x, 1 - 2*x*x - 2*y*y], dim=1)
        ], dim=1)
        
                       
        world_vertex1 = torch.bmm(rot_matrix, local_vertex1.unsqueeze(1).expand(self.num_envs, 3, 1)).squeeze(-1) + box_pos
        world_vertex2 = torch.bmm(rot_matrix, local_vertex2.unsqueeze(1).expand(self.num_envs, 3, 1)).squeeze(-1) + box_pos
        
                                         
                 
        q0 = self.robots["robot_0"].data.root_link_quat_w
        q1 = self.robots["robot_1"].data.root_link_quat_w
        ypr0 = quat_to_euler_angles_torch(q0)
        ypr1 = quat_to_euler_angles_torch(q1)
        yaw0 = ypr0[:, 2]
        yaw1 = ypr1[:, 2]
        
                   
        robot_connection = p1[:, :2] - p0[:, :2]
        connection_angle = torch.atan2(robot_connection[:, 1], robot_connection[:, 0])
        
                
        stick_direction = world_vertex1[:, :2] - world_vertex2[:, :2]
        stick_angle = torch.atan2(stick_direction[:, 1], stick_direction[:, 0])
        
                               
        yaw_diff = torch.abs(yaw0 - yaw1)
        yaw_diff = torch.remainder(yaw_diff + torch.pi, 2 * torch.pi) - torch.pi
        yaw_alignment = torch.exp(-torch.abs(yaw_diff) * 5.0)
        
                                  
        angle_diff = torch.abs(connection_angle - stick_angle)
        angle_diff = torch.remainder(angle_diff + torch.pi, 2 * torch.pi) - torch.pi
        parallelism = torch.exp(-torch.abs(angle_diff) * 5.0)
        
                                      
                         
        yaw0_to_stick = torch.abs(yaw0 - stick_angle)
        yaw0_to_stick = torch.remainder(yaw0_to_stick + torch.pi, 2 * torch.pi) - torch.pi
        yaw1_to_stick = torch.abs(yaw1 - stick_angle)
        yaw1_to_stick = torch.remainder(yaw1_to_stick + torch.pi, 2 * torch.pi) - torch.pi
        
                          
        orthogonality0 = torch.exp(-torch.abs(torch.abs(yaw0_to_stick) - torch.pi/2) * 10.0)
        orthogonality1 = torch.exp(-torch.abs(torch.abs(yaw1_to_stick) - torch.pi/2) * 10.0)
        orthogonality = (orthogonality0 + orthogonality1) / 2.0
        
                                 
                    
        robot0_heading = torch.stack([torch.cos(yaw0), torch.sin(yaw0)], dim=1)
                          
        robot0_lateral = torch.stack([-torch.sin(yaw0), torch.cos(yaw0)], dim=1)
        
                            
        robot1_relative = p1[:, :2] - p0[:, :2]
        
                                   
        lateral_distance = torch.abs(torch.sum(robot1_relative * robot0_lateral, dim=1))
        
                                   
        longitudinal_distance = torch.abs(torch.sum(robot1_relative * robot0_heading, dim=1))
        
                          
        lateral_penalty = torch.exp(-torch.abs(lateral_distance - 1.0) * 15.0)
                          
        longitudinal_penalty = torch.exp(-torch.abs(longitudinal_distance) * 15.0)
                         
        distance_reward = lateral_penalty * longitudinal_penalty
        
                           
        formation_consistency = (yaw_alignment * 0.1 + parallelism * 0.1 + orthogonality * 0.3 + distance_reward * 0.5)
        r_formation = formation_consistency
        
                                  
        vertex1_height = world_vertex1[:, 2]
        vertex2_height = world_vertex2[:, 2]
        
                         
        height_condition = (vertex1_height > 0.9) & (vertex2_height > 0.9)
        height_maintenance = torch.where(height_condition, 1.0, 0.0)
        r_height = height_maintenance
        
                                    
        r_goal = torch.zeros(self.num_envs, device=self.device)
        
        if hasattr(self, '_fixed_long_goals') and hasattr(self, '_target_angles'):
            long_goals = self._fixed_long_goals
            target_angles = self._target_angles
            
                         
            cos_angle = torch.cos(target_angles)
            sin_angle = torch.sin(target_angles)
            target_vertex1 = torch.stack([
                long_goals[:, 0] + stick_length/2 * cos_angle,
                long_goals[:, 1] + stick_length/2 * sin_angle
            ], dim=1)
            target_vertex2 = torch.stack([
                long_goals[:, 0] - stick_length/2 * cos_angle,
                long_goals[:, 1] - stick_length/2 * sin_angle
            ], dim=1)
            
                              
            current_vertex1 = world_vertex1[:, :2]
            current_vertex2 = world_vertex2[:, :2]
            
            current_distance1 = torch.norm(current_vertex1 - target_vertex1, dim=1)
            current_distance2 = torch.norm(current_vertex2 - target_vertex2, dim=1)
            current_total_distance = current_distance1 + current_distance2
            
                             
            r_goal = torch.exp(-current_total_distance / 2.0)                
        
              
        shared_rewards = {
            "formation_consistency": r_formation * getattr(self.cfg, 'formation_consistency_reward_scale', 1.0) * self.step_dt,
            "height_maintenance": r_height * getattr(self.cfg, 'height_maintenance_reward_scale', 1.0) * self.step_dt,
            "goal_reaching": r_goal * getattr(self.cfg, 'goal_reaching_reward_scale', 0.1) * self.step_dt,
        }

                         
        for k, v in shared_rewards.items():
            if k in self._episode_sums:
                self._episode_sums[k] += v.detach()
            else:
                self._episode_sums[k] = v.detach().clone()
        
                        
        for robot_id in self.robots.keys():
            robot_specific_rewards = list(shared_rewards.values())
            reward[robot_id] = torch.sum(torch.stack(robot_specific_rewards), dim=0)


        
        return reward



    def _compute_leg_box_contact_penalty(self, robot_id: str) -> torch.Tensor:

                             
        leg_body_names = [
            "left_knee_link", "right_knee_link",      
            "left_ankle_pitch_link", "left_ankle_roll_link",       
            "right_ankle_pitch_link", "right_ankle_roll_link",      
                                
                                                               
        ]
        
        contact_penalty = torch.zeros(self.num_envs, device=self.device)
        
                             
        if hasattr(self, 'contact_sensors') and robot_id in self.contact_sensors:
                     
            contact_forces = self.contact_sensors[robot_id].data.net_forces_w
            
                           
            for leg_body in leg_body_names:
                try:
                                    
                    body_indices, _ = self.robots[robot_id].find_bodies(leg_body)
                    if len(body_indices) > 0:
                                  
                        leg_contact_force = torch.norm(contact_forces[:, body_indices[0], :], dim=-1)
                                                       
                        contact_penalty += torch.where(leg_contact_force > 0.1, 1.0, 0.0)
                except:
                    pass                
        
        return contact_penalty

    def _compute_robot_box_distance_penalty(self, robot_id: str) -> torch.Tensor:

        distance_penalty = torch.zeros(self.num_envs, device=self.device)
        
                   
        robot_pos = self.robots[robot_id].data.root_state_w[:, :3]                           
        
                
        box_pos = self.object.data.root_state_w[:, :3]                           
        
                              
        distance_xy = torch.norm(robot_pos[:, :2] - box_pos[:, :2], dim=1)              
        
                       
        is_contacting_box = torch.zeros(self.num_envs, device=self.device, dtype=torch.bool)
        
        if hasattr(self, 'contact_sensors') and robot_id in self.contact_sensors:
            contact_forces = self.contact_sensors[robot_id].data.net_forces_w
            
                           
            contact_body_names = [
                "left_rubber_hand", "right_rubber_hand",      
                "left_knee_link", "right_knee_link",          
                "left_ankle_pitch_link", "left_ankle_roll_link",      
                "right_ankle_pitch_link", "right_ankle_roll_link"
            ]
            
            for body_name in contact_body_names:
                try:
                    body_indices, _ = self.robots[robot_id].find_bodies(body_name)
                    if len(body_indices) > 0:
                        contact_force = torch.norm(contact_forces[:, body_indices[0], :], dim=-1)
                                           
                        is_contacting_box |= (contact_force > 0.1)
                except:
                    pass
        
                  
        position_multiplier = torch.ones(self.num_envs, device=self.device)
        
                              
        if hasattr(self, '_current_short_goals'):
            short_goals = self._current_short_goals[:, :2]                        
            
                                     
            direction_to_goal = short_goals - box_pos[:, :2]                 
            direction_norm = torch.norm(direction_to_goal, dim=1, keepdim=True)
            direction_unit = direction_to_goal / (direction_norm + 1e-8)                 
            
                                                  
            backend_offset = -0.2            
            backend_point = box_pos[:, :2] + backend_offset * direction_unit                 
            
                             
                                                   
            robot_to_backend = robot_pos[:, :2] - backend_point                 
            projection = torch.sum(robot_to_backend * direction_unit, dim=1)              
            
                                 
            is_behind_box = projection > 0.0
            
                              
            position_multiplier = torch.where(is_behind_box, 3.0, 1.0)
            

        
                  
                           
        distance_penalty = torch.where(
            is_contacting_box, 
            0.0,           
            distance_xy * position_multiplier                     
        )
        
        return distance_penalty

                                     
                              

    def _get_dones(self) -> tuple[dict, dict]:
                                               
        time_out = self.episode_length_buf >= self._max_episode_length
        
        robot_0_com_height = self.robots["robot_0"].data.root_state_w[:, 2]
        robot_1_com_height = self.robots["robot_1"].data.root_state_w[:, 2]
        
        term_height = getattr(self.cfg, 'termination_height', 0.25)
        g1_0_died = robot_0_com_height < term_height
        g1_1_died = robot_1_com_height < term_height
        
        g1_died = torch.logical_or(g1_0_died, g1_1_died)
        too_far = self._get_too_far_away()
        
                   
        angle_aligned = torch.ones(self.num_envs, device=self.device, dtype=torch.bool)
        robot_0_pos = None
        robot_1_pos = None
        if hasattr(self, '_target_angles'):
            target_angles = self._target_angles
            robot_0_pos = self.robots["robot_0"].data.root_state_w[:, :2]
            robot_1_pos = self.robots["robot_1"].data.root_state_w[:, :2]
            robot_diff = robot_1_pos - robot_0_pos
            current_angles = torch.atan2(robot_diff[:, 1], robot_diff[:, 0])
            angle_diff = torch.abs(current_angles - target_angles)
            angle_diff = torch.remainder(angle_diff + torch.pi, 2 * torch.pi) - torch.pi
            angle_aligned = torch.abs(angle_diff) < 0.1               
        
                   
        goal_reached = torch.ones(self.num_envs, device=self.device, dtype=torch.bool)
        if hasattr(self, '_fixed_long_goals') and robot_0_pos is not None and robot_1_pos is not None:
            long_goals = self._fixed_long_goals
            board_center = 0.5 * (robot_0_pos + robot_1_pos)
            goal_distance = torch.norm(board_center - long_goals[:, :2], dim=1)
            goal_reached = goal_distance < 0.3              
        
                        
        task_success = angle_aligned & goal_reached
        
        dones = torch.logical_or(g1_died, too_far)

                                      
                                                      
        
                                      
        dones_or_timeouts = dones | time_out
        
                                   
                                                        
        self.extras["log"] = dict()
        
                           
        if torch.any(dones_or_timeouts):
                                        
            total_episode_reward = torch.zeros(self.num_envs, device=self.device)
            
            for key, value in self._episode_sums.items():
                                         
                finished_env_rewards = value[dones_or_timeouts]
                if len(finished_env_rewards) > 0:
                    self.extras["log"][key] = finished_env_rewards.mean().item()
                else:
                    self.extras["log"][key] = 0.0
                
                        
                total_episode_reward += value
                                                 
                self._episode_sums[key][dones_or_timeouts] = 0.0
            
                          
            finished_total_rewards = total_episode_reward[dones_or_timeouts]
            if len(finished_total_rewards) > 0:
                self.extras["log"]["total_reward"] = finished_total_rewards.mean().item()
            else:
                self.extras["log"]["total_reward"] = 0.0
                
                                    
                                     
            ep_return = self.extras["log"].get("total_reward", None)
            if ep_return is not None:
                                         
                num_finished = torch.sum(dones_or_timeouts).item()
                finished_env_indices = torch.where(dones_or_timeouts)[0]
                if len(finished_env_indices) > 0:
                    avg_episode_length = self.episode_length_buf[finished_env_indices].float().mean().item()
                    print(f"[Episode End] [{num_finished} Envs] [Avg Step {avg_episode_length:.0f}] Total Episode Return: {ep_return:.4f}")
                    
                                                
                    print(f"  Main Rewards (Avg of {num_finished} finished envs):")
                    main_rewards = ["track_lin_vel_xy_exp", "track_ang_vel_z_exp", "robot_0_hand_box_contact_reward", "robot_1_hand_box_contact_reward"]
                    for reward_name in main_rewards:
                        if reward_name in self.extras["log"]:
                            print(f"    {reward_name}: {self.extras['log'][reward_name]:.4f}")
                    print("  " + "-"*50)

                                             
        return {key: dones for key in self.robots.keys()}, {key: time_out for key in self.robots.keys()}



    def _get_too_far_away(self):
        g1_0_pos = self.robots["robot_0"].data.body_com_pos_w[:, 0, :]
        g1_1_pos = self.robots["robot_1"].data.body_com_pos_w[:, 0, :]

        box_pos = self.object.data.body_com_pos_w[:, 0, :]

        g1_0_too_far = (
            torch.sqrt(torch.square(g1_0_pos[:, 0] - box_pos[:, 0]) + torch.square(g1_0_pos[:, 1] - box_pos[:, 1])) > 1.5             
        )
        g1_1_too_far = (
            torch.sqrt(torch.square(g1_1_pos[:, 0] - box_pos[:, 0]) + torch.square(g1_1_pos[:, 1] - box_pos[:, 1])) > 1.5
        )

                               
                     
        box_length, box_width, box_height = 0.22, 2.0, 0.05
        local_vertices = torch.tensor([
            [box_length/2, box_width/2, box_height/2],         
            [box_length/2, -box_width/2, box_height/2],        
            [-box_length/2, -box_width/2, box_height/2],       
            [-box_length/2, box_width/2, box_height/2],        
        ], device=self.device, dtype=torch.float32)
        
                       
        box_quat = self.object.data.root_com_quat_w
        w, x, y, z = box_quat[:, 0], box_quat[:, 1], box_quat[:, 2], box_quat[:, 3]
        rotation_matrix = torch.stack([
            torch.stack([1-2*y*y-2*z*z, 2*x*y-2*w*z, 2*x*z+2*w*y], dim=1),
            torch.stack([2*x*y+2*w*z, 1-2*x*x-2*z*z, 2*y*z-2*w*x], dim=1),
            torch.stack([2*x*z-2*w*y, 2*y*z+2*w*x, 1-2*x*x-2*y*y], dim=1)
        ], dim=1)
        
                       
        world_vertices_z = []
        for i in range(4):
            rotated_vertex = torch.bmm(rotation_matrix, local_vertices[i].unsqueeze(1).expand(self.num_envs, 3, 1)).squeeze(-1)
            world_vertex = rotated_vertex + box_pos
            world_vertices_z.append(world_vertex[:, 2])
        
        vertices_z = torch.stack(world_vertices_z, dim=1)                 
                          
        box_landed = torch.any(vertices_z < 0.2, dim=1)

                         
        return torch.logical_or(torch.logical_or(g1_0_too_far, g1_1_too_far), box_landed)

    def _compute_box_vertex_z_variance(self) -> torch.Tensor:

                   
        box_pos = self.object.data.root_com_pos_w
        box_quat = self.object.data.root_com_quat_w
        
                             
        box_length, box_width, box_height = 0.22, 2.0, 0.05
        
                                 
        local_vertices = torch.tensor([
            [box_length/2, box_width/2, box_height/2],         
            [box_length/2, -box_width/2, box_height/2],        
            [-box_length/2, -box_width/2, box_height/2],       
            [-box_length/2, box_width/2, box_height/2],        
        ], device=self.device, dtype=torch.float32)
        
                       
                 
        w, x, y, z = box_quat[:, 0], box_quat[:, 1], box_quat[:, 2], box_quat[:, 3]
        rotation_matrix = torch.stack([
            torch.stack([1-2*y*y-2*z*z, 2*x*y-2*w*z, 2*x*z+2*w*y], dim=1),
            torch.stack([2*x*y+2*w*z, 1-2*x*x-2*z*z, 2*y*z-2*w*x], dim=1),
            torch.stack([2*x*z-2*w*y, 2*y*z+2*w*x, 1-2*x*x-2*y*y], dim=1)
        ], dim=1)
        
                       
        world_vertices_z = []
        for i in range(4):
            rotated_vertex = torch.bmm(rotation_matrix, local_vertices[i].unsqueeze(1).expand(self.num_envs, 3, 1)).squeeze(-1)
            world_vertex = rotated_vertex + box_pos
            world_vertices_z.append(world_vertex[:, 2])
        
                  
        vertices_z = torch.stack(world_vertices_z, dim=1)                 
        z_variance = torch.var(vertices_z, dim=1)              
        
        return z_variance

    def _compute_box_goal_alignment_reward(self) -> torch.Tensor:

                  
        box_pos = self.object.data.root_com_pos_w
        
                       
        if hasattr(self, '_fixed_long_goals'):
            long_goal = self._fixed_long_goals
        else:
                                   
            return torch.zeros(self.num_envs, device=self.device)
        
                             
        distance = torch.norm(box_pos - long_goal, dim=1)
        
                               
                         
        alignment_reward = torch.exp(-distance / 0.2)            
        
        return alignment_reward

    def _compute_box_vertices_height_reward(self) -> torch.Tensor:

                   
        box_pos = self.object.data.root_com_pos_w
        box_quat = self.object.data.root_com_quat_w
        
               
        box_length, box_width, box_height = 0.22, 2.0, 0.05
        
                                 
        local_vertices = torch.tensor([
            [box_length/2, box_width/2, box_height/2],         
            [box_length/2, -box_width/2, box_height/2],        
            [-box_length/2, -box_width/2, box_height/2],       
            [-box_length/2, box_width/2, box_height/2],        
        ], device=self.device, dtype=torch.float32)
        
                       
        w, x, y, z = box_quat[:, 0], box_quat[:, 1], box_quat[:, 2], box_quat[:, 3]
        rotation_matrix = torch.stack([
            torch.stack([1-2*y*y-2*z*z, 2*x*y-2*w*z, 2*x*z+2*w*y], dim=1),
            torch.stack([2*x*y+2*w*z, 1-2*x*x-2*z*z, 2*y*z-2*w*x], dim=1),
            torch.stack([2*x*z-2*w*y, 2*y*z+2*w*x, 1-2*x*x-2*y*y], dim=1)
        ], dim=1)
        
                       
        world_vertices_z = []
        for i in range(4):
            rotated_vertex = torch.bmm(rotation_matrix, local_vertices[i].unsqueeze(1).expand(self.num_envs, 3, 1)).squeeze(-1)
            world_vertex = rotated_vertex + box_pos
            world_vertices_z.append(world_vertex[:, 2])
        
        vertices_z = torch.stack(world_vertices_z, dim=1)                 
        
                
        target_height = 0.9
        
                                          
        height_penalties = torch.zeros_like(vertices_z)
        
                                 
        below_target = vertices_z < target_height
        height_penalties = torch.where(below_target, (target_height - vertices_z) ** 2, 0.0)
        
                           
        total_penalty = torch.sum(height_penalties, dim=1)              
        
        return total_penalty

    def _get_curriculum_scale(self) -> float:

        curriculum_enabled = getattr(self.cfg, 'curriculum_enabled', False)
        if not curriculum_enabled:
            return 1.0
        
        current_steps = self.wbc_control_step
        start_steps = getattr(self.cfg, 'curriculum_start_steps', 0.0)
        end_steps = getattr(self.cfg, 'curriculum_end_steps', 1.0)
        start_scale = getattr(self.cfg, 'curriculum_start_scale', 1.0)
        end_scale = getattr(self.cfg, 'curriculum_end_scale', 1.0)
        
                          
        if current_steps < start_steps:
            return start_scale
        
                           
        if current_steps >= end_steps:
            return end_scale
        
                      
        progress = (current_steps - start_steps) / max(1e-8, (end_steps - start_steps))
        current_scale = start_scale + progress * (end_scale - start_scale)
        
        return current_scale

    def _compute_box_ground_contact_penalty(self) -> torch.Tensor:

                   
        box_pos = self.object.data.root_com_pos_w
        box_quat = self.object.data.root_com_quat_w
        
               
        box_length, box_width, box_height = 0.22, 2.0, 0.05
        
                                 
        local_vertices = torch.tensor([
            [box_length/2, box_width/2, box_height/2],         
            [box_length/2, -box_width/2, box_height/2],        
            [-box_length/2, -box_width/2, box_height/2],       
            [-box_length/2, box_width/2, box_height/2],        
        ], device=self.device, dtype=torch.float32)
        
                       
        w, x, y, z = box_quat[:, 0], box_quat[:, 1], box_quat[:, 2], box_quat[:, 3]
        rotation_matrix = torch.stack([
            torch.stack([1-2*y*y-2*z*z, 2*x*y-2*w*z, 2*x*z+2*w*y], dim=1),
            torch.stack([2*x*y+2*w*z, 1-2*x*x-2*z*z, 2*y*z-2*w*x], dim=1),
            torch.stack([2*x*z-2*w*y, 2*y*z+2*w*x, 1-2*x*x-2*y*y], dim=1)
        ], dim=1)
        
                       
        world_vertices_z = []
        for i in range(4):
            rotated_vertex = torch.bmm(rotation_matrix, local_vertices[i].unsqueeze(1).expand(self.num_envs, 3, 1)).squeeze(-1)
            world_vertex = rotated_vertex + box_pos
            world_vertices_z.append(world_vertex[:, 2])
        
        vertices_z = torch.stack(world_vertices_z, dim=1)                 
        
                          
        any_vertex_low = torch.any(vertices_z < 0.3, dim=1)
        
                                 
        return torch.where(any_vertex_low, 1.0, 0.0)

    def _compute_robot_box_center_proximity_reward(self, robot_id: str) -> torch.Tensor:

                         
        robot_pos = self.robots[robot_id].data.root_state_w[:, :2]                        
        
                   
        box_pos = self.object.data.root_com_pos_w
        box_quat = self.object.data.root_com_quat_w
        
               
        box_length, box_width, box_height = 0.22, 2.0, 0.05
        
                          
                                    
        local_midpoint_1 = torch.tensor([box_length/2, 0.0, box_height/2], device=self.device, dtype=torch.float32)         
        local_midpoint_2 = torch.tensor([-box_length/2, 0.0, box_height/2], device=self.device, dtype=torch.float32)        
        
                       
        w, x, y, z = box_quat[:, 0], box_quat[:, 1], box_quat[:, 2], box_quat[:, 3]
        rotation_matrix = torch.stack([
            torch.stack([1-2*y*y-2*z*z, 2*x*y-2*w*z, 2*x*z+2*w*y], dim=1),
            torch.stack([2*x*y+2*w*z, 1-2*x*x-2*z*z, 2*y*z-2*w*x], dim=1),
            torch.stack([2*x*z-2*w*y, 2*y*z+2*w*x, 1-2*x*x-2*y*y], dim=1)
        ], dim=1)
        
                      
        world_midpoints = []
        for local_midpoint in [local_midpoint_1, local_midpoint_2]:
            rotated_midpoint = torch.bmm(rotation_matrix, local_midpoint.unsqueeze(1).expand(self.num_envs, 3, 1)).squeeze(-1)
            world_midpoint = rotated_midpoint + box_pos
            world_midpoints.append(world_midpoint[:, :2])          
        
                             
        distances = []
        for world_midpoint in world_midpoints:
            distance = torch.norm(robot_pos - world_midpoint, dim=1)              
            distances.append(distance)
        
                   
        proximity_rewards = []
        for distance in distances:
                        
            proximity_reward = 1.0 / (distance * distance + 1e-6)              
            proximity_rewards.append(proximity_reward)
        
                       
        return torch.stack(proximity_rewards, dim=1).mean(dim=1)              

    def _compute_height_control(self, env_idx, robot_id):

                     
        box_pos = self.object.data.root_com_pos_w[env_idx]
        box_quat = self.object.data.root_com_quat_w[env_idx]
        
              
        stick_length = 2.0
        
                            
        local_vertex1 = torch.tensor([stick_length/2, 0, 0], device=self.device, dtype=torch.float32)
        local_vertex2 = torch.tensor([-stick_length/2, 0, 0], device=self.device, dtype=torch.float32)
        
                  
        w, x, y, z = box_quat[0], box_quat[1], box_quat[2], box_quat[3]
        rot_matrix = torch.tensor([
            [1 - 2*y*y - 2*z*z, 2*x*y - 2*w*z, 2*x*z + 2*w*y],
            [2*x*y + 2*w*z, 1 - 2*x*x - 2*z*z, 2*y*z - 2*w*x],
            [2*x*z - 2*w*y, 2*y*z + 2*w*x, 1 - 2*x*x - 2*y*y]
        ], device=self.device, dtype=torch.float32)
        
                       
        world_vertex1 = torch.matmul(rot_matrix, local_vertex1) + box_pos
        world_vertex2 = torch.matmul(rot_matrix, local_vertex2) + box_pos
        
                   
        vertex1_height = world_vertex1[2]
        vertex2_height = world_vertex2[2]
        
                      
        target_height = 0.9
        
                          
        current_height = min(vertex1_height, vertex2_height)
        height_error = target_height - current_height
        
                
                        
        height_control = 0.5 * height_error
        
                                      
        return torch.tensor([0.0, height_control.item() * 0.1, 0.0], device=self.device)






@torch.jit.script
def compute_intermediate_values(
    targets: torch.Tensor,
    torso_position: torch.Tensor,
    torso_rotation: torch.Tensor,
    velocity: torch.Tensor,
    ang_velocity: torch.Tensor,
    dof_pos: torch.Tensor,
    dof_lower_limits: torch.Tensor,
    dof_upper_limits: torch.Tensor,
    inv_start_rot: torch.Tensor,
    basis_vec0: torch.Tensor,
    basis_vec1: torch.Tensor,
    potentials: torch.Tensor,
    prev_potentials: torch.Tensor,
    dt: float,
):
    to_target = targets - torso_position
    to_target[:, 2] = 0.0
    torso_quat, up_proj, heading_proj, up_vec, heading_vec = compute_heading_and_up(
        torso_rotation, inv_start_rot, to_target, basis_vec0, basis_vec1, 2
    )

    vel_loc, angvel_loc, roll, pitch, yaw, angle_to_target = compute_rot(
        torso_quat, velocity, ang_velocity, targets, torso_position
    )

    dof_pos_scaled = torch_utils.maths.unscale(dof_pos, dof_lower_limits, dof_upper_limits)

    to_target = targets - torso_position
    to_target[:, 2] = 0.0
    prev_potentials[:] = potentials
    potentials = -torch.norm(to_target, p=2, dim=-1) / dt

    return (
        up_proj,
        heading_proj,
        up_vec,
        heading_vec,
        vel_loc,
        angvel_loc,
        roll,
        pitch,
        yaw,
        angle_to_target,
        dof_pos_scaled,
        prev_potentials,
        potentials,
    )
