import numpy as np
from isaaclab.assets.articulation import ArticulationCfg
from isaaclab.actuators import ImplicitActuatorCfg
import isaaclab.sim as sim_utils


AMO_23_JOINT_NAMES = [
    "left_hip_pitch_joint", "left_hip_roll_joint", "left_hip_yaw_joint", "left_knee_joint", "left_ankle_pitch_joint", "left_ankle_roll_joint",
    "right_hip_pitch_joint", "right_hip_roll_joint", "right_hip_yaw_joint", "right_knee_joint", "right_ankle_pitch_joint", "right_ankle_roll_joint",
    "waist_yaw_joint", "waist_roll_joint", "waist_pitch_joint",
    "left_shoulder_pitch_joint", "left_shoulder_roll_joint", "left_shoulder_yaw_joint", "left_elbow_joint",
    "right_shoulder_pitch_joint", "right_shoulder_roll_joint", "right_shoulder_yaw_joint", "right_elbow_joint"
]

AMO_23_DEFAULT_DOF_POS = {
    "left_hip_pitch_joint": -0.1, "left_hip_roll_joint": 0.0, "left_hip_yaw_joint": 0.0,
    "left_knee_joint": 0.3, "left_ankle_pitch_joint": -0.2, "left_ankle_roll_joint": 0.0,
    "right_hip_pitch_joint": -0.1, "right_hip_roll_joint": 0.0, "right_hip_yaw_joint": 0.0,
    "right_knee_joint": 0.3, "right_ankle_pitch_joint": -0.2, "right_ankle_roll_joint": 0.0,
    "waist_yaw_joint": 0.0, "waist_roll_joint": 0.0, "waist_pitch_joint": 0.0,
    "left_shoulder_pitch_joint": -0.2, "left_shoulder_roll_joint": 0.0, "left_shoulder_yaw_joint": 0.7, "left_elbow_joint": 0.5,
    "right_shoulder_pitch_joint": -0.2, "right_shoulder_roll_joint": 0.0, "right_shoulder_yaw_joint": -0.7, "right_elbow_joint": 0.5,
}

AMO_23_STIFFNESS = {
    "left_hip_pitch_joint": 150, "left_hip_roll_joint": 150, "left_hip_yaw_joint": 150,
    "left_knee_joint": 300, "left_ankle_pitch_joint": 80, "left_ankle_roll_joint": 20,
    "right_hip_pitch_joint": 150, "right_hip_roll_joint": 150, "right_hip_yaw_joint": 150,
    "right_knee_joint": 300, "right_ankle_pitch_joint": 80, "right_ankle_roll_joint": 20,
    "waist_yaw_joint": 400, "waist_roll_joint": 400, "waist_pitch_joint": 400,
    "left_shoulder_pitch_joint": 80, "left_shoulder_roll_joint": 80, "left_shoulder_yaw_joint": 40, "left_elbow_joint": 60,
    "right_shoulder_pitch_joint": 80, "right_shoulder_roll_joint": 80, "right_shoulder_yaw_joint": 40, "right_elbow_joint": 60,
}

AMO_23_DAMPING = {
    "left_hip_pitch_joint": 2, "left_hip_roll_joint": 2, "left_hip_yaw_joint": 2,
    "left_knee_joint": 4, "left_ankle_pitch_joint": 2, "left_ankle_roll_joint": 1,
    "right_hip_pitch_joint": 2, "right_hip_roll_joint": 2, "right_hip_yaw_joint": 2,
    "right_knee_joint": 4, "right_ankle_pitch_joint": 2, "right_ankle_roll_joint": 1,
    "waist_yaw_joint": 15, "waist_roll_joint": 15, "waist_pitch_joint": 15,
    "left_shoulder_pitch_joint": 2, "left_shoulder_roll_joint": 2, "left_shoulder_yaw_joint": 1, "left_elbow_joint": 1,
    "right_shoulder_pitch_joint": 2, "right_shoulder_roll_joint": 2, "right_shoulder_yaw_joint": 1, "right_elbow_joint": 1,
}



ISAACLAB_29_JOINT_NAMES = [
    'left_hip_pitch_joint', 'right_hip_pitch_joint', 'waist_yaw_joint',
    'left_hip_roll_joint', 'right_hip_roll_joint', 'waist_roll_joint',
    'left_hip_yaw_joint', 'right_hip_yaw_joint', 'waist_pitch_joint',
    'left_knee_joint', 'right_knee_joint', 'left_shoulder_pitch_joint',
    'right_shoulder_pitch_joint', 'left_ankle_pitch_joint', 'right_ankle_pitch_joint',
    'left_shoulder_roll_joint', 'right_shoulder_roll_joint', 'left_ankle_roll_joint',
    'right_ankle_roll_joint', 'left_shoulder_yaw_joint', 'right_shoulder_yaw_joint',
    'left_elbow_joint', 'right_elbow_joint',
    'left_wrist_roll_joint', 'right_wrist_roll_joint',
    'left_wrist_pitch_joint', 'right_wrist_pitch_joint',
    'left_wrist_yaw_joint', 'right_wrist_yaw_joint'
]


g1_joint_pos = {}
g1_stiffness = {}
g1_damping = {}
for name in ISAACLAB_29_JOINT_NAMES:
    if name in AMO_23_JOINT_NAMES:
        g1_joint_pos[name] = AMO_23_DEFAULT_DOF_POS[name]
        g1_stiffness[name] = AMO_23_STIFFNESS[name]
        g1_damping[name] = AMO_23_DAMPING[name]
    else:
        if "wrist" in name:
            if "pitch" in name:
g1_joint_pos[name] = 0.0  #
            elif "roll" in name:
                if "left" in name:
g1_joint_pos[name] = -1.57  #
                elif "right" in name:
g1_joint_pos[name] = 1.57   #
            elif "yaw" in name:
g1_joint_pos[name] = 0.0  #
g1_stiffness[name] = 80.0  #
g1_damping[name] = 3.0     #
        else:
            g1_joint_pos[name] = 0.0
g1_stiffness[name] = 50.0  #
g1_damping[name] = 2.0     #


G1_29DOF_CFG = ArticulationCfg(
    spawn=sim_utils.UsdFileCfg(
usd_path="/home/marl/IsaacLab-HALPO/g1/g1_29dof_modified.usd", #

        activate_contact_sensors=True,
        rigid_props=sim_utils.RigidBodyPropertiesCfg(disable_gravity=False),
        articulation_props=sim_utils.ArticulationRootPropertiesCfg(
            enabled_self_collisions=False, solver_position_iteration_count=32, solver_velocity_iteration_count=32
        ),
    ),
    init_state=ArticulationCfg.InitialStateCfg(
        pos=(0.0, 0.0, 0.795),
joint_pos=g1_joint_pos, # <--
        joint_vel={".*": 0.0},
    ),
    soft_joint_pos_limit_factor=0.9,
    actuators={
        "all": ImplicitActuatorCfg(
            joint_names_expr=[".*"],
stiffness=g1_stiffness,  # <--
damping=g1_damping,      # <--
            effort_limit=200.0,
            velocity_limit=100.0,
        ),
    },
)
