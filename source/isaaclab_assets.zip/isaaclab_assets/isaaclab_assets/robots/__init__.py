# Copyright (c) 2024, Hao Zhang, Yikai Wang, Ding Zhao, Hongtei Eric Tseng.
# All rights reserved.
#

##
# Configuration for different assets.
##

from .allegro import *
from .ant import *
from .anymal import *
from .cart_double_pendulum import *
from .cartpole import *
from .fourier import *
from .franka import *
from .humanoid import *
from .humanoid_28 import *
from .kinova import *
from .quadcopter import *
from .ridgeback_franka import *
from .sawyer import *
from .shadow_hand import *
from .spot import *
from .unitree import *
from .universal_robots import *
